import { useRef, useEffect, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, Mic, Paperclip, User, Bot, Loader2 } from 'lucide-react';
import type { ChatMessage } from '@/lib/types/intent';
import ThinkingIndicator from './ThinkingIndicator';
import ConfidenceBadge from './ConfidenceBadge';

interface ChatPanelProps {
  messages: ChatMessage[];
  isLoading: boolean;
  onSend: (message: string) => void;
  confidence?: number;
  reasoning?: string;
}

export default function ChatPanel({ messages, isLoading, onSend, confidence, reasoning }: ChatPanelProps) {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !isLoading) {
      onSend(input.trim());
      setInput('');
    }
  }, [input, isLoading, onSend]);

  const handleVoice = useCallback(() => {
    setIsListening(true);
    setTimeout(() => setIsListening(false), 3000);
  }, []);

  return (
    <div className="flex flex-col h-full border-l border-white/5">
      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && (
          <div className="flex flex-col items-center justify-center h-full text-center text-[#8a8f98] gap-3">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6366F1]/20 to-[#EC4899]/20 flex items-center justify-center">
              <Bot className="w-8 h-8 text-[#6366F1]" />
            </div>
            <div>
              <div className="text-sm font-medium text-white">NEXUS Assistant</div>
              <div className="text-xs mt-1 max-w-[240px]">
                Describe what you need and I'll generate the perfect interface for you.
              </div>
            </div>
            <div className="space-y-2 w-full max-w-[280px] mt-2">
              {[
                'Plan a business trip to Paris next week',
                'Compare flights to Tokyo',
                'Create a travel budget breakdown',
              ].map((suggestion, i) => (
                <button
                  key={i}
                  onClick={() => onSend(suggestion)}
                  className="w-full text-left px-3 py-2 text-xs rounded-lg bg-white/5 text-[#8a8f98] hover:text-white hover:bg-white/10 transition-all"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        )}

        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.role === 'assistant' && (
                <div className="w-7 h-7 rounded-lg bg-[#6366F1]/10 flex items-center justify-center flex-shrink-0 mt-1">
                  <Bot className="w-4 h-4 text-[#6366F1]" />
                </div>
              )}
              <div className={`max-w-[80%] ${msg.role === 'user' ? 'order-first' : ''}`}>
                <div
                  className={`px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed ${
                    msg.role === 'user'
                      ? 'bg-[#6366F1] text-white rounded-tr-md'
                      : 'glass-card rounded-tl-md'
                  }`}
                >
                  {msg.content}
                </div>
                {msg.role === 'assistant' && msg.metadata?.confidence && (
                  <div className="mt-1.5">
                    <ConfidenceBadge score={msg.metadata.confidence} size="sm" />
                  </div>
                )}
              </div>
              {msg.role === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-[#EC4899]/10 flex items-center justify-center flex-shrink-0 mt-1">
                  <User className="w-4 h-4 text-[#EC4899]" />
                </div>
              )}
            </motion.div>
          ))}
        </AnimatePresence>

        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex gap-3"
          >
            <div className="w-7 h-7 rounded-lg bg-[#6366F1]/10 flex items-center justify-center flex-shrink-0">
              <Bot className="w-4 h-4 text-[#6366F1]" />
            </div>
            <div className="glass-card px-4 py-2 rounded-2xl rounded-tl-md">
              <ThinkingIndicator />
            </div>
          </motion.div>
        )}
      </div>

      {/* Input */}
      <div className="p-3 border-t border-white/5">
        <form onSubmit={handleSubmit} className="relative">
          <div className="flex items-center gap-2 glass-card px-3 py-2">
            <button
              type="button"
              onClick={handleVoice}
              className={`flex-shrink-0 p-1.5 rounded-lg transition-all ${
                isListening ? 'bg-[#EF4444]/20 text-[#EF4444] animate-pulse' : 'text-[#8a8f98] hover:text-white'
              }`}
            >
              <Mic className="w-4 h-4" />
            </button>
            <button
              type="button"
              className="flex-shrink-0 p-1.5 rounded-lg text-[#8a8f98] hover:text-white transition-all"
            >
              <Paperclip className="w-4 h-4" />
            </button>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={isListening ? 'Listening...' : 'Describe your intent...'}
              className="flex-1 bg-transparent text-sm text-white placeholder-[#8a8f98]/60 outline-none"
              disabled={isLoading || isListening}
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="flex-shrink-0 p-2 rounded-lg bg-[#6366F1] text-white disabled:opacity-30 disabled:cursor-not-allowed hover:bg-[#6366F1]/80 transition-all"
            >
              {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            </button>
          </div>
        </form>
        {confidence && confidence > 0 && (
          <div className="mt-2 flex items-center justify-between">
            <ConfidenceBadge score={confidence} size="sm" />
            {reasoning && (
              <span className="text-[10px] text-[#8a8f98]/60 truncate max-w-[200px]">{reasoning}</span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
