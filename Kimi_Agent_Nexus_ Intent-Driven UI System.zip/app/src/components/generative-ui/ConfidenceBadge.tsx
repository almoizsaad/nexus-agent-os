import { memo } from 'react';
import { Shield, ShieldCheck, ShieldAlert } from 'lucide-react';

interface ConfidenceBadgeProps {
  score: number;
  showLabel?: boolean;
  size?: 'sm' | 'md' | 'lg';
}

const ConfidenceBadge = memo(function ConfidenceBadge({ score, showLabel = true, size = 'md' }: ConfidenceBadgeProps) {
  const getColor = () => {
    if (score >= 90) return 'text-emerald-400 bg-emerald-400/10 border-emerald-400/30';
    if (score >= 70) return 'text-amber-400 bg-amber-400/10 border-amber-400/30';
    return 'text-red-400 bg-red-400/10 border-red-400/30';
  };

  const getIcon = () => {
    if (score >= 90) return <ShieldCheck className={size === 'sm' ? 'w-3 h-3' : size === 'lg' ? 'w-5 h-5' : 'w-4 h-4'} />;
    if (score >= 70) return <Shield className={size === 'sm' ? 'w-3 h-3' : size === 'lg' ? 'w-5 h-5' : 'w-4 h-4'} />;
    return <ShieldAlert className={size === 'sm' ? 'w-3 h-3' : size === 'lg' ? 'w-5 h-5' : 'w-4 h-4'} />;
  };

  const sizeClasses = {
    sm: 'text-[10px] px-1.5 py-0.5 gap-1',
    md: 'text-xs px-2.5 py-1 gap-1.5',
    lg: 'text-sm px-3 py-1.5 gap-2',
  };

  return (
    <span className={`inline-flex items-center rounded-full border font-medium ${getColor()} ${sizeClasses[size]}`}>
      {getIcon()}
      <span>{score}%</span>
      {showLabel && (
        <span className="opacity-70">
          {score >= 90 ? 'High' : score >= 70 ? 'Medium' : 'Low'}
        </span>
      )}
    </span>
  );
});

export default ConfidenceBadge;
