import { memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plane, Hotel, MapPin, Calendar, DollarSign,
  Clock, Star, ArrowRight, Sun, Cloud, Wind
} from 'lucide-react';
import type { ComponentConfig, IntentType } from '@/lib/types/intent';

interface DynamicLayoutProps {
  components: ComponentConfig[];
  intent: IntentType;
}

const springTransition = {
  type: 'spring' as const,
  stiffness: 300,
  damping: 30,
};

function FlightCard({ data }: { data: Record<string, unknown> }) {
  const items = (data?.items as Array<Record<string, string>>) || [];
  return (
    <div className="space-y-3">
      {items.map((item, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ ...springTransition, delay: i * 0.1 }}
          className="glass-card p-4 flex items-center gap-4 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-lg bg-[#6366F1]/10 flex items-center justify-center">
            <Plane className="w-5 h-5 text-[#6366F1]" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium text-white">{item.airline}</div>
            <div className="text-xs text-[#8a8f98] flex items-center gap-1">
              <Clock className="w-3 h-3" /> {item.time} · {item.stops}
            </div>
          </div>
          <div className="text-right">
            <div className="text-sm font-semibold text-[#fbbf24]">{item.price}</div>
            <ArrowRight className="w-4 h-4 text-[#8a8f98] group-hover:text-[#6366F1] group-hover:translate-x-1 transition-all" />
          </div>
        </motion.div>
      ))}
    </div>
  );
}

function HotelCard({ data }: { data: Record<string, unknown> }) {
  const items = (data?.items as Array<Record<string, unknown>>) || [];
  return (
    <div className="grid grid-cols-1 gap-3">
      {items.map((item, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...springTransition, delay: i * 0.1 }}
          className="glass-card p-4 cursor-pointer group"
        >
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#EC4899]/20 to-[#6366F1]/20 flex items-center justify-center">
                <Hotel className="w-6 h-6 text-[#EC4899]" />
              </div>
              <div>
                <div className="text-sm font-medium text-white">{item.name as string}</div>
                <div className="flex items-center gap-1 mt-0.5">
                  {Array.from({ length: 5 }).map((_, j) => (
                    <Star
                      key={j}
                      className={`w-3 h-3 ${j < Math.floor((item.rating as number) || 0) ? 'text-[#fbbf24] fill-[#fbbf24]' : 'text-[#8a8f98]/30'}`}
                    />
                  ))}
                  <span className="text-xs text-[#8a8f98] ml-1">{String(item.rating ?? '')}</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm font-semibold text-[#10b981]">{item.price as string}</div>
              <div className="text-[10px] text-[#8a8f98]">per night</div>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

function TimelineView({ data }: { data: Record<string, unknown> }) {
  const days = (data?.days as Array<Record<string, unknown>>) || [];
  return (
    <div className="relative">
      <div className="absolute left-4 top-0 bottom-0 w-px bg-gradient-to-b from-[#6366F1] via-[#06B6D4] to-[#6366F1] opacity-30" />
      <div className="space-y-4">
        {days.map((day, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ ...springTransition, delay: i * 0.08 }}
            className="flex items-center gap-4 ml-2"
          >
            <div className="w-5 h-5 rounded-full bg-[#1A1A2E] border-2 border-[#6366F1] flex items-center justify-center flex-shrink-0">
              <div className="w-1.5 h-1.5 rounded-full bg-[#6366F1]" />
            </div>
            <div className="glass-card flex-1 p-3">
              <div className="flex items-center gap-2">
                <Calendar className="w-3.5 h-3.5 text-[#06B6D4]" />
                <span className="text-xs font-medium text-[#06B6D4]">Day {String(day.day ?? '')}</span>
              </div>
              <div className="text-sm text-white mt-1">{day.activity as string}</div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function BudgetChart({ data }: { data: Record<string, unknown> }) {
  const total = (data?.total as string) || '$0';
  const categories = [
    { label: 'Flights', value: (data?.flights as string) || '$0', color: '#6366F1', pct: 23 },
    { label: 'Hotel', value: (data?.hotel as string) || '$0', color: '#EC4899', pct: 54 },
    { label: 'Meals', value: (data?.meals as string) || '$0', color: '#06B6D4', pct: 13 },
    { label: 'Transport', value: (data?.transport as string) || '$0', color: '#10b981', pct: 6 },
    { label: 'Other', value: (data?.other as string) || '$0', color: '#fbbf24', pct: 4 },
  ];

  return (
    <div className="space-y-4">
      <div className="text-center">
        <div className="text-2xl font-bold text-white">{total}</div>
        <div className="text-xs text-[#8a8f98]">Estimated Total</div>
      </div>
      <div className="flex gap-1 h-4 rounded-full overflow-hidden bg-white/5">
        {categories.map((cat, i) => (
          <motion.div
            key={i}
            initial={{ width: 0 }}
            animate={{ width: `${cat.pct}%` }}
            transition={{ duration: 0.8, delay: i * 0.1, ease: 'easeOut' }}
            className="h-full"
            style={{ background: cat.color }}
          />
        ))}
      </div>
      <div className="space-y-2">
        {categories.map((cat, i) => (
          <div key={i} className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <div className="w-2.5 h-2.5 rounded-sm" style={{ background: cat.color }} />
              <span className="text-[#8a8f98]">{cat.label}</span>
            </div>
            <span className="text-white font-medium">{cat.value}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function OverviewCard({ data }: { data: Record<string, unknown> }) {
  return (
    <div className="grid grid-cols-2 gap-3">
      {[
        { icon: MapPin, label: 'Destination', value: (data?.destination as string) || 'Paris, France', color: '#6366F1' },
        { icon: Calendar, label: 'Dates', value: (data?.dates as string) || 'Mar 15-22, 2026', color: '#06B6D4' },
        { icon: Clock, label: 'Duration', value: (data?.duration as string) || '7 days', color: '#EC4899' },
        { icon: DollarSign, label: 'Budget', value: (data?.budget as string) || '$5,200 est.', color: '#10b981' },
      ].map((item, i) => (
        <motion.div
          key={i}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ ...springTransition, delay: i * 0.08 }}
          className="glass-card p-3"
        >
          <item.icon className="w-4 h-4 mb-2" style={{ color: item.color }} />
          <div className="text-xs text-[#8a8f98]">{item.label}</div>
          <div className="text-sm font-medium text-white mt-0.5">{item.value}</div>
        </motion.div>
      ))}
    </div>
  );
}

function WeatherWidget() {
  return (
    <div className="glass-card p-4">
      <div className="flex items-center gap-2 mb-3">
        <Sun className="w-4 h-4 text-[#fbbf24]" />
        <span className="text-xs font-medium text-[#8a8f98]">Weather Forecast</span>
      </div>
      <div className="grid grid-cols-4 gap-2 text-center">
        {[
          { day: 'Mon', icon: Sun, temp: '18°', color: '#fbbf24' },
          { day: 'Tue', icon: Cloud, temp: '16°', color: '#8a8f98' },
          { day: 'Wed', icon: Sun, temp: '20°', color: '#fbbf24' },
          { day: 'Thu', icon: Wind, temp: '17°', color: '#06B6D4' },
        ].map((w, i) => (
          <div key={i} className="p-2 rounded-lg bg-white/5">
            <div className="text-[10px] text-[#8a8f98]">{w.day}</div>
            <w.icon className="w-4 h-4 mx-auto my-1" style={{ color: w.color }} />
            <div className="text-xs font-medium text-white">{w.temp}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

const ComponentRenderer = memo(function ComponentRenderer({ component }: { component: ComponentConfig }) {
  switch (component.type) {
    case 'list':
      if (component.id === 'flight-search' || component.title === 'Flight Options') {
        return <FlightCard data={component.data || {}} />;
      }
      return <FlightCard data={component.data || {}} />;
    case 'gallery':
      if (component.id === 'hotel-recs' || component.title === 'Hotel Recommendations') {
        return <HotelCard data={component.data || {}} />;
      }
      return <HotelCard data={component.data || {}} />;
    case 'timeline':
      return <TimelineView data={component.data || {}} />;
    case 'chart':
      if (component.id === 'budget-tracker' || component.title === 'Budget Estimate') {
        return <BudgetChart data={component.data || {}} />;
      }
      return <BudgetChart data={component.data || {}} />;
    case 'card':
      if (component.id === 'trip-overview' || component.title === 'Trip Overview' || component.title === 'Overview') {
        return <OverviewCard data={component.data || {}} />;
      }
      if (component.id === 'weather' || component.title === 'Weather') {
        return <WeatherWidget />;
      }
      return (
        <div className="glass-card p-4">
          <h3 className="text-sm font-medium text-white mb-2">{component.title}</h3>
          <div className="text-xs text-[#8a8f98]">
            {component.data ? JSON.stringify(component.data, null, 2) : 'No data'}
          </div>
        </div>
      );
    default:
      return (
        <div className="glass-card p-4">
          <h3 className="text-sm font-medium text-white mb-2">{component.title}</h3>
          <div className="text-xs text-[#8a8f98]">Component type: {component.type}</div>
        </div>
      );
  }
});

const DynamicLayout = memo(function DynamicLayout({ components, intent }: DynamicLayoutProps) {
  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={intent}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="grid grid-cols-1 lg:grid-cols-12 gap-4 p-4"
      >
        {components.map((component, index) => {
          const colSpan = component.position?.w
            ? `lg:col-span-${Math.min(component.position.w, 12)}`
            : 'lg:col-span-6';

          return (
            <motion.div
              key={component.id}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ ...springTransition, delay: index * 0.08 }}
              className={`col-span-1 ${colSpan}`}
              style={{
                gridRow: component.position?.y ? `span ${component.position.h || 1}` : undefined,
              }}
            >
              <div className="h-full">
                <ComponentRenderer component={component} />
              </div>
            </motion.div>
          );
        })}
      </motion.div>
    </AnimatePresence>
  );
});

export default DynamicLayout;
