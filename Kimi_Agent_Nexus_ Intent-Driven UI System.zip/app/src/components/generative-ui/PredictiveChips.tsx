import { memo } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, Plus } from 'lucide-react';
import type { PredictiveSuggestion } from '@/lib/types/intent';

interface PredictiveChipsProps {
  suggestions: PredictiveSuggestion[];
  onSelect?: (suggestion: PredictiveSuggestion) => void;
}

const PredictiveChips = memo(function PredictiveChips({ suggestions, onSelect }: PredictiveChipsProps) {
  return (
    <div className="flex items-center gap-2 flex-wrap">
      <div className="flex items-center gap-1.5 text-xs text-[#6366F1]">
        <Sparkles className="w-3.5 h-3.5" />
        <span className="font-medium">Predicted:</span>
      </div>
      {suggestions.slice(0, 4).map((suggestion, i) => (
        <motion.button
          key={suggestion.id}
          initial={{ opacity: 0, scale: 0.8, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ type: 'spring', stiffness: 400, damping: 25, delay: i * 0.08 }}
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => onSelect?.(suggestion)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium
            bg-[#6366F1]/10 text-[#6366F1] border border-[#6366F1]/20
            hover:bg-[#6366F1]/20 hover:border-[#6366F1]/40 transition-all"
        >
          <Plus className="w-3 h-3" />
          {suggestion.label}
          <span className="text-[10px] opacity-60">{suggestion.confidence}%</span>
        </motion.button>
      ))}
    </div>
  );
});

export default PredictiveChips;
