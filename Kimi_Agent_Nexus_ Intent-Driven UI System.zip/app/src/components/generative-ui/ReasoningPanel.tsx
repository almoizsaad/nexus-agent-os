import { useState } from 'react';
import { ChevronDown, ChevronUp, Brain, Sparkles } from 'lucide-react';

interface ReasoningPanelProps {
  reasoning: string;
  sources?: string[];
  isThinking?: boolean;
}

export default function ReasoningPanel({ reasoning, sources, isThinking }: ReasoningPanelProps) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="w-full">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-2 text-xs text-[#8a8f98] hover:text-[#fbbf24] transition-colors"
      >
        {isThinking ? (
          <Sparkles className="w-3.5 h-3.5 animate-pulse text-[#6366F1]" />
        ) : (
          <Brain className="w-3.5 h-3.5" />
        )}
        <span>{isThinking ? 'AI is thinking...' : 'View reasoning'}</span>
        {expanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
      </button>

      {expanded && (
        <div className="mt-2 p-3 rounded-lg bg-white/5 border border-white/10 text-xs text-[#8a8f98] leading-relaxed animate-fade-in-up">
          <p>{reasoning}</p>
          {sources && sources.length > 0 && (
            <div className="mt-2 pt-2 border-t border-white/10">
              <span className="text-[10px] uppercase tracking-wider opacity-60">Sources</span>
              <ul className="mt-1 space-y-1">
                {sources.map((s, i) => (
                  <li key={i} className="text-[10px] text-[#06B6D4]">{s}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
