import { memo } from 'react';

const ThinkingIndicator = memo(function ThinkingIndicator() {
  return (
    <div className="flex items-center gap-3 py-3">
      <div className="flex gap-1">
        {[0, 1, 2].map(i => (
          <div
            key={i}
            className="w-2 h-2 rounded-full bg-[#6366F1]"
            style={{
              animation: `pulse-glow 1.4s ease-in-out ${i * 0.2}s infinite`,
            }}
          />
        ))}
      </div>
      <div className="shimmer h-3 w-32 rounded" style={{ backgroundSize: '200% 100%' }} />
    </div>
  );
});

export default ThinkingIndicator;
