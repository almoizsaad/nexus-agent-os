import { useState } from 'react';
import { Hexagon, Menu, X, Zap, Settings, HelpCircle } from 'lucide-react';

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-14">
      <div className="liquid-glass h-full flex items-center justify-between px-4 lg:px-6">
        {/* Logo */}
        <div className="flex items-center gap-2.5">
          <div className="relative w-8 h-8 flex items-center justify-center">
            <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-[#6366F1] to-[#EC4899] opacity-80" />
            <Hexagon className="relative w-5 h-5 text-white" strokeWidth={2} />
          </div>
          <span className="text-lg font-semibold tracking-tight text-white">
            NEXUS
          </span>
          <span className="hidden sm:inline-flex items-center gap-1 text-[10px] font-medium uppercase tracking-widest text-[#fbbf24] bg-[#fbbf24]/10 px-2 py-0.5 rounded-full ml-2">
            <Zap className="w-3 h-3" />
            AI Workspace
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-1">
          {['Workspace', 'Analytics', 'Memory', 'Settings'].map((item) => (
            <button
              key={item}
              className="px-3 py-1.5 text-[13px] font-medium text-[#8a8f98] hover:text-white rounded-lg hover:bg-white/5 transition-all"
            >
              {item}
            </button>
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button className="hidden sm:flex items-center justify-center w-8 h-8 rounded-lg text-[#8a8f98] hover:text-white hover:bg-white/5 transition-all">
            <HelpCircle className="w-4 h-4" />
          </button>
          <button className="hidden sm:flex items-center justify-center w-8 h-8 rounded-lg text-[#8a8f98] hover:text-white hover:bg-white/5 transition-all">
            <Settings className="w-4 h-4" />
          </button>
          <button
            className="md:hidden flex items-center justify-center w-8 h-8 rounded-lg text-[#8a8f98] hover:text-white hover:bg-white/5 transition-all"
            onClick={() => setMobileOpen(!mobileOpen)}
          >
            {mobileOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden liquid-glass border-t border-white/5 px-4 py-3 animate-fade-in-up">
          {['Workspace', 'Analytics', 'Memory', 'Settings'].map((item) => (
            <button
              key={item}
              className="block w-full text-left px-3 py-2 text-sm text-[#8a8f98] hover:text-white rounded-lg hover:bg-white/5 transition-all"
            >
              {item}
            </button>
          ))}
        </div>
      )}
    </nav>
  );
}
