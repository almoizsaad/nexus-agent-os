import { useState } from 'react';
import {
  Code2, Palette, BarChart3, Globe, MessageSquare,
  Database, Cpu, ChevronRight, Activity, CircleDot
} from 'lucide-react';

interface SidebarProps {
  activeModule?: string;
  onModuleChange?: (module: string) => void;
  systemLog?: string[];
}

const MODULES = [
  { id: 'analysis', label: 'Analysis', icon: BarChart3, color: '#6366F1' },
  { id: 'code', label: 'Code', icon: Code2, color: '#06B6D4' },
  { id: 'creative', label: 'Creative', icon: Palette, color: '#EC4899' },
  { id: 'travel', label: 'Travel', icon: Globe, color: '#10b981' },
  { id: 'chat', label: 'Chat', icon: MessageSquare, color: '#fbbf24' },
  { id: 'data', label: 'Data', icon: Database, color: '#8b5cf6' },
];

export default function Sidebar({ activeModule = 'analysis', onModuleChange, systemLog = [] }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [showLog, setShowLog] = useState(true);

  return (
    <aside
      className={`liquid-glass flex flex-col h-full transition-all duration-300 ${collapsed ? 'w-14' : 'w-60'}`}
    >
      {/* Toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="flex items-center justify-center h-10 border-b border-white/5 text-[#8a8f98] hover:text-white transition-colors"
      >
        <ChevronRight className={`w-4 h-4 transition-transform ${collapsed ? '' : 'rotate-180'}`} />
      </button>

      {/* Core Modules */}
      <div className="flex-1 overflow-y-auto py-2">
        <div className={`text-[10px] font-medium uppercase tracking-widest text-[#8a8f98]/60 mb-2 ${collapsed ? 'text-center px-0' : 'px-4'}`}>
          {collapsed ? 'Mod' : 'Core Modules'}
        </div>
        {MODULES.map((mod) => {
          const Icon = mod.icon;
          const isActive = activeModule === mod.id;
          return (
            <button
              key={mod.id}
              onClick={() => onModuleChange?.(mod.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm transition-all relative group ${collapsed ? 'justify-center' : ''} ${
                isActive
                  ? 'text-white'
                  : 'text-[#8a8f98] hover:text-white hover:bg-white/5'
              }`}
            >
              {isActive && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-0.5 h-6 rounded-r-full" style={{ background: mod.color }} />
              )}
              <Icon className="w-[18px] h-[18px] flex-shrink-0" style={{ color: isActive ? mod.color : undefined }} />
              {!collapsed && <span className="font-medium">{mod.label}</span>}
              {!collapsed && isActive && <div className="ml-auto w-1.5 h-1.5 rounded-full" style={{ background: mod.color }} />}
            </button>
          );
        })}

        {/* Divider */}
        <div className="my-3 mx-3 h-px bg-white/5" />

        {/* System Status */}
        <div className={`text-[10px] font-medium uppercase tracking-widest text-[#8a8f98]/60 mb-2 ${collapsed ? 'text-center' : 'px-4'}`}>
          {collapsed ? 'Sys' : 'System'}
        </div>
        <button className={`w-full flex items-center gap-3 px-3 py-2 text-[#8a8f98] hover:text-white hover:bg-white/5 transition-all ${collapsed ? 'justify-center' : ''}`}>
          <Cpu className="w-[18px] h-[18px]" />
          {!collapsed && <span className="text-sm">Neural Core</span>}
        </button>
        <button className={`w-full flex items-center gap-3 px-3 py-2 text-[#8a8f98] hover:text-white hover:bg-white/5 transition-all ${collapsed ? 'justify-center' : ''}`}>
          <Activity className="w-[18px] h-[18px]" />
          {!collapsed && <span className="text-sm">Live Metrics</span>}
        </button>
      </div>

      {/* System Log */}
      {!collapsed && (
        <div className="border-t border-white/5">
          <button
            onClick={() => setShowLog(!showLog)}
            className="w-full flex items-center justify-between px-4 py-2 text-[10px] font-medium uppercase tracking-widest text-[#8a8f98]/60 hover:text-[#8a8f98] transition-colors"
          >
            <span>Neural Log</span>
            <CircleDot className="w-3 h-3 text-[#10b981] animate-pulse" />
          </button>
          {showLog && (
            <div className="px-4 pb-3 h-32 overflow-y-auto font-mono text-[10px] space-y-1">
              {systemLog.length === 0 && (
                <div className="text-[#8a8f98]/40 italic">System initialized...</div>
              )}
              {systemLog.map((log, i) => (
                <div key={i} className="text-[#8a8f98]/70 flex gap-2">
                  <span className="text-[#6366F1]/50 flex-shrink-0">[{new Date().toLocaleTimeString('en-US', { hour12: false })}]</span>
                  <span>{log}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </aside>
  );
}
