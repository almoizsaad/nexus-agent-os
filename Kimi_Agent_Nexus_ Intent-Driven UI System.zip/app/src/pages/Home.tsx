import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { motion } from 'framer-motion';
import HeroSection from '@/sections/HeroSection';
import NeuralDatastream from '@/sections/NeuralDatastream';
import { Hexagon, ArrowRight, Sparkles, Zap, Brain, Globe, Shield } from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const FEATURES = [
  {
    icon: Brain,
    title: 'Intent Analysis',
    description: 'Natural language is parsed into structured intent with confidence scoring and context extraction.',
    color: '#6366F1',
  },
  {
    icon: Sparkles,
    title: 'Generative UI',
    description: 'Dynamic layouts are generated in real-time — dashboards, timelines, comparisons, and forms.',
    color: '#EC4899',
  },
  {
    icon: Zap,
    title: 'Predictive UX',
    description: 'The system anticipates your next move, showing suggestions before you even ask.',
    color: '#06B6D4',
  },
  {
    icon: Globe,
    title: 'Multimodal Input',
    description: 'Text, voice, file uploads — interact however feels natural. The AI adapts to you.',
    color: '#10b981',
  },
  {
    icon: Shield,
    title: 'Transparent AI',
    description: 'Every decision shows its reasoning. Confidence scores and source attribution build trust.',
    color: '#fbbf24',
  },
  {
    icon: Hexagon,
    title: 'Smart Travel Planner',
    description: 'Our showcase use case — plan trips with auto-generated itineraries, flights, hotels, and budgets.',
    color: '#8b5cf6',
  },
];

export default function Home() {
  const navigate = useNavigate();

  useEffect(() => {
    // Animate features on scroll
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>('.feature-card').forEach((card, i) => {
        gsap.fromTo(
          card,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 0.6,
            delay: i * 0.1,
            scrollTrigger: {
              trigger: card,
              start: 'top 85%',
              toggleActions: 'play none none none',
            },
          }
        );
      });
    });

    return () => ctx.revert();
  }, []);

  return (
    <div className="bg-[#0F0F1A] min-h-screen">
      {/* Hero Section */}
      <HeroSection />

      {/* Neural Datastream */}
      <NeuralDatastream />

      {/* Features Section */}
      <section className="py-24 px-6">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#6366F1]/10 border border-[#6366F1]/20 mb-4">
              <Sparkles className="w-3.5 h-3.5 text-[#6366F1]" />
              <span className="text-xs font-medium text-[#6366F1]">Core Capabilities</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-semibold text-white mb-4">
              Beyond the Chatbot
            </h2>
            <p className="text-[#8a8f98] max-w-xl mx-auto">
              NEXUS is not a chatbot. It's an Intent-Driven Generative UI system that creates the interface you need, when you need it.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {FEATURES.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <div
                  key={i}
                  className="feature-card glass-card p-6 group cursor-pointer"
                  style={{
                    borderLeft: `2px solid ${feature.color}20`,
                  }}
                >
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110"
                    style={{ background: `${feature.color}15` }}
                  >
                    <Icon className="w-6 h-6" style={{ color: feature.color }} />
                  </div>
                  <h3 className="text-lg font-medium text-white mb-2 group-hover:text-[#fbbf24] transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-[#8a8f98] leading-relaxed">
                    {feature.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Smart Travel Planner Showcase */}
      <section className="py-24 px-6 border-y border-white/5">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#10b981]/10 border border-[#10b981]/20 mb-4">
                <Globe className="w-3.5 h-3.5 text-[#10b981]" />
                <span className="text-xs font-medium text-[#10b981]">Featured Use Case</span>
              </div>
              <h2 className="text-3xl md:text-4xl font-semibold text-white mb-4">
                Smart Travel Planner
              </h2>
              <p className="text-[#8a8f98] mb-6 leading-relaxed">
                Say "I need to organize a business trip to Paris next week" and watch as NEXUS generates a complete trip interface — flights, hotels, itinerary timeline, budget breakdown, and weather forecast — all in real-time.
              </p>
              <ul className="space-y-3 mb-8">
                {[
                  'Auto-generated flight comparison cards',
                  'Hotel recommendations with ratings and pricing',
                  'Day-by-day itinerary timeline',
                  'Budget tracker with visual breakdown',
                  'Predictive suggestions for next steps',
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-2.5 text-sm text-[#8a8f98]">
                    <div className="w-1.5 h-1.5 rounded-full bg-[#10b981]" />
                    {item}
                  </li>
                ))}
              </ul>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => navigate('/workspace')}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-[#6366F1] to-[#EC4899] text-white font-medium hover:shadow-lg hover:shadow-[#6366F1]/25 transition-all"
              >
                Try the Demo
                <ArrowRight className="w-4 h-4" />
              </motion.button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="relative"
            >
              {/* Mock UI */}
              <div className="relative rounded-2xl overflow-hidden border border-white/10 bg-[#1A1A2E]/50 backdrop-blur-sm">
                {/* Mock Header */}
                <div className="flex items-center gap-2 px-4 py-3 border-b border-white/5">
                  <div className="flex gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-full bg-[#EF4444]/60" />
                    <div className="w-2.5 h-2.5 rounded-full bg-[#fbbf24]/60" />
                    <div className="w-2.5 h-2.5 rounded-full bg-[#10b981]/60" />
                  </div>
                  <div className="flex-1 text-center">
                    <span className="text-[10px] text-[#8a8f98]">NEXUS Workspace</span>
                  </div>
                </div>

                {/* Mock Content */}
                <div className="p-4 space-y-3">
                  {/* Intent bar */}
                  <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[#6366F1]/10 border border-[#6366F1]/20">
                    <Sparkles className="w-3.5 h-3.5 text-[#6366F1]" />
                    <span className="text-xs text-[#8a8f98]">Business trip to Paris next week</span>
                    <span className="ml-auto text-[10px] text-[#10b981] font-medium">94%</span>
                  </div>

                  {/* Mock Grid */}
                  <div className="grid grid-cols-2 gap-2">
                    <div className="p-3 rounded-lg bg-white/5 border border-white/5">
                      <div className="text-[10px] text-[#8a8f98] mb-1">Trip Overview</div>
                      <div className="text-xs text-white">Paris, France</div>
                      <div className="text-[10px] text-[#8a8f98]">Mar 15-22, 2026</div>
                    </div>
                    <div className="p-3 rounded-lg bg-white/5 border border-white/5">
                      <div className="text-[10px] text-[#8a8f98] mb-1">Budget</div>
                      <div className="text-xs text-white">$5,200</div>
                      <div className="w-full h-1 bg-white/10 rounded-full mt-1">
                        <div className="w-3/4 h-full rounded-full bg-gradient-to-r from-[#6366F1] to-[#10b981]" />
                      </div>
                    </div>
                  </div>

                  {/* Mock Flights */}
                  <div className="space-y-2">
                    {['Air France', 'Emirates'].map((airline, i) => (
                      <div key={i} className="flex items-center gap-3 p-2.5 rounded-lg bg-white/5 border border-white/5">
                        <div className="w-7 h-7 rounded bg-[#6366F1]/10 flex items-center justify-center">
                          <Zap className="w-3.5 h-3.5 text-[#6366F1]" />
                        </div>
                        <div className="flex-1">
                          <div className="text-[10px] text-white">{airline}</div>
                          <div className="text-[9px] text-[#8a8f98]">8h 30m · Direct</div>
                        </div>
                        <div className="text-xs text-[#fbbf24]">${1200 + i * 180}</div>
                      </div>
                    ))}
                  </div>

                  {/* Predictive chip */}
                  <div className="flex items-center gap-2">
                    <span className="text-[9px] text-[#6366F1]">Predicted:</span>
                    <span className="px-2 py-1 rounded-full text-[9px] bg-[#6366F1]/10 text-[#6366F1] border border-[#6366F1]/20">
                      + Book meeting room
                    </span>
                  </div>
                </div>
              </div>

              {/* Glow effects */}
              <div className="absolute -top-10 -right-10 w-40 h-40 bg-[#6366F1]/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-[#EC4899]/10 rounded-full blur-3xl pointer-events-none" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="max-w-2xl mx-auto text-center"
        >
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#6366F1] to-[#EC4899] flex items-center justify-center mx-auto mb-6">
            <Hexagon className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-3xl md:text-4xl font-semibold text-white mb-4">
            Ready to Experience the Future?
          </h2>
          <p className="text-[#8a8f98] mb-8">
            Enter the NEXUS workspace and discover how AI can generate the perfect interface for your every need.
          </p>
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={() => navigate('/workspace')}
            className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-[#6366F1] via-[#EC4899] to-[#06B6D4] text-white font-medium text-lg hover:shadow-xl hover:shadow-[#6366F1]/30 transition-all"
          >
            Enter NEXUS Workspace
            <ArrowRight className="w-5 h-5" />
          </motion.button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-6 border-t border-white/5">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-gradient-to-br from-[#6366F1] to-[#EC4899] flex items-center justify-center">
              <Hexagon className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="text-sm font-medium text-white">NEXUS</span>
            <span className="text-[10px] text-[#8a8f98]">Adaptive AI Workspace</span>
          </div>
          <div className="text-xs text-[#8a8f98]">
            DOO Builders League 2026 — Beyond the Chatbot Challenge
          </div>
        </div>
      </footer>
    </div>
  );
}
