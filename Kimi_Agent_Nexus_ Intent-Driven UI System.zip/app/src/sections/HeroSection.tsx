import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import gsap from 'gsap';
import ParticleCanvas from '@/components/generative-ui/ParticleCanvas';
import { ArrowDown, Zap } from 'lucide-react';

export default function HeroSection() {
  const containerRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLHeadingElement>(null);
  const shadowRef = useRef<HTMLDivElement>(null);
  const [particleState, setParticleState] = useState<'idle' | 'gathering' | 'orbiting' | 'exploding'>('idle');
  const [mousePos, setMousePos] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      setMousePos({ x, y });

      const xPos = (x / rect.width) - 0.5;
      const yPos = (y / rect.height) - 0.5;

      if (textRef.current) {
        gsap.to(textRef.current, {
          rotationY: xPos * 30,
          rotationX: -yPos * 30,
          x: xPos * 20,
          y: yPos * 20,
          duration: 1,
          ease: 'power2.out',
        });
      }
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const handleTextHover = () => {
    setParticleState('orbiting');
  };

  const handleTextLeave = () => {
    setParticleState('idle');
  };

  const handleTextClick = () => {
    setParticleState('exploding');
    setTimeout(() => setParticleState('idle'), 2000);
  };

  return (
    <section
      ref={containerRef}
      className="relative w-full h-screen flex items-center justify-center overflow-hidden"
      style={{ perspective: '1000px' }}
    >
      {/* Particle Background */}
      <ParticleCanvas
        className="absolute inset-0 z-0"
        state={particleState}
        mouseTarget={mousePos}
      />

      {/* Radial gradient overlay */}
      <div className="absolute inset-0 z-[1] bg-gradient-radial from-transparent via-[#0F0F1A]/50 to-[#0F0F1A]" />

      {/* 3D Typography */}
      <div
        className="relative z-10 text-center"
        style={{ animation: 'float 6s ease-in-out infinite' }}
      >
        <h1
          ref={textRef}
          className="parallax-text relative text-[70px] md:text-[120px] lg:text-[160px] font-black tracking-tighter cursor-pointer select-none"
          style={{ transformStyle: 'preserve-3d' }}
          onMouseEnter={handleTextHover}
          onMouseLeave={handleTextLeave}
          onClick={handleTextClick}
        >
          {/* 40 stacked layers for 3D extrusion */}
          {Array.from({ length: 40 }).map((_, i) => (
            <span
              key={i}
              className="absolute top-0 left-0 w-full flex justify-center text-transparent bg-gradient-to-b from-amber-300 via-white to-slate-400 bg-clip-text pointer-events-none"
              style={{
                transform: `translateZ(-${i + 1}px)`,
                opacity: 1 - (i / 50),
              }}
              aria-hidden="true"
            >
              NEXUS
            </span>
          ))}
          {/* Front face */}
          <span
            className="relative text-transparent bg-gradient-to-b from-[#fbbf24] via-white to-slate-400 bg-clip-text"
            aria-hidden="true"
          >
            NEXUS
          </span>
        </h1>

        {/* Shadow */}
        <div
          ref={shadowRef}
          className="absolute -bottom-8 left-1/2 -translate-x-1/2 w-[280px] h-[30px] rounded-full"
          style={{
            background: 'radial-gradient(closest-side, rgba(0,0,0,0.5), transparent)',
            animation: 'shadow 6s ease-in-out infinite',
            transformOrigin: 'center',
          }}
        />

        {/* Subtitle */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
          className="mt-12 flex flex-col items-center gap-4"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card">
            <Zap className="w-4 h-4 text-[#fbbf24]" />
            <span className="text-sm text-[#8a8f98]">Beyond the Chatbot — Intent-Driven Intelligence</span>
          </div>
          <p className="text-lg text-[#8a8f98] max-w-md">
            AI that doesn't just chat. It understands, generates, and adapts.
          </p>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-[#8a8f98]"
        animate={{ y: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 2, ease: 'easeInOut' }}
      >
        <span className="text-xs uppercase tracking-widest">Scroll to Explore</span>
        <ArrowDown className="w-4 h-4" />
      </motion.div>

      {/* Corner gradients */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-[#6366F1]/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-[#EC4899]/5 rounded-full blur-3xl pointer-events-none" />
    </section>
  );
}
