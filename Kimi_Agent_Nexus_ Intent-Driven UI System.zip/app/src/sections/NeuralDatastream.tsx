import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Cpu, Activity, TrendingUp, Zap, Brain, Database,
  Wifi, Server, Globe, Clock, Shield
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const MODELS = [
  { name: 'GPT-4o', status: 'active', latency: '142ms' },
  { name: 'Claude 3.5', status: 'active', latency: '198ms' },
  { name: 'Gemini Pro', status: 'standby', latency: 'off' },
  { name: 'Llama 3', status: 'active', latency: '89ms' },
];

const METRICS = [
  { label: 'Tokens/sec', value: 2847, max: 5000, icon: Zap },
  { label: 'Active Threads', value: 42, max: 64, icon: Cpu },
  { label: 'Memory Used', value: 78, max: 100, icon: Database },
  { label: 'Uptime', value: 99.9, max: 100, icon: Clock },
];

const SENTIMENT_EMOJIS = ['😠', '😐', '🙂', '😄', '🤩'];

export default function NeuralDatastream() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const [focusedIndex, setFocusedIndex] = useState<number | null>(null);

  useEffect(() => {
    if (!sectionRef.current || !trackRef.current) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        trackRef.current,
        { xPercent: 0 },
        {
          xPercent: -40,
          ease: 'sine.inOut',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top bottom',
            end: 'bottom top',
            scrub: 1.5,
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Focus zone simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setFocusedIndex(Math.floor(Math.random() * 8));
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full overflow-hidden py-16 border-y border-white/5"
      style={{ background: 'linear-gradient(180deg, #0F0F1A 0%, #0a0a14 50%, #0F0F1A 100%)' }}
    >
      {/* Section header */}
      <div className="px-6 mb-10">
        <div className="flex items-center gap-2 mb-2">
          <Activity className="w-4 h-4 text-[#6366F1]" />
          <span className="text-[10px] font-medium uppercase tracking-widest text-[#6366F1]">
            Neural Datastream
          </span>
        </div>
        <h2 className="text-2xl font-semibold text-white">Consciousness Module</h2>
        <p className="text-sm text-[#8a8f98] mt-1">Real-time AI vitals and system telemetry</p>
      </div>

      {/* Scrolling ticker */}
      <div className="relative overflow-hidden">
        {/* Focus zone indicators */}
        <div className="absolute left-1/2 -translate-x-1/2 top-0 bottom-0 w-[40%] pointer-events-none z-10">
          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-[#6366F1]/5 to-transparent" />
        </div>

        <div
          ref={trackRef}
          className="flex gap-0"
          style={{ width: 'fit-content' }}
        >
          {/* Model Status Quadrant */}
          {[...Array(3)].map((_, repeat) => (
            <div key={`models-${repeat}`} className="flex-shrink-0 border-l border-white/5 px-8 py-4 data-node"
              style={{
                opacity: focusedIndex === 0 + repeat ? 1 : 0.4,
                transform: focusedIndex === 0 + repeat ? 'scale(1.05)' : 'scale(0.95)',
                transition: 'all 0.4s cubic-bezier(0.25, 1, 0.5, 1)',
              }}
            >
              <div className="text-[10px] uppercase tracking-widest text-[#8a8f98]/60 mb-3 flex items-center gap-1.5">
                <Brain className="w-3 h-3" /> Active Models
              </div>
              <div className="space-y-2 min-w-[200px]">
                {MODELS.map((model, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <span className="text-xs text-white">{model.name}</span>
                    <div className="flex items-center gap-2">
                      <span className={`text-[10px] ${model.status === 'active' ? 'text-[#10b981]' : 'text-[#8a8f98]'}`}>
                        {model.latency}
                      </span>
                      <div className={`w-1.5 h-1.5 rounded-full ${model.status === 'active' ? 'bg-[#10b981]' : 'bg-[#8a8f98]/30'}`} />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Metrics Quadrant */}
          {[...Array(3)].map((_, repeat) => (
            <div key={`metrics-${repeat}`} className="flex-shrink-0 border-l border-white/5 px-8 py-4 data-node"
              style={{
                opacity: focusedIndex === 3 + repeat ? 1 : 0.4,
                transform: focusedIndex === 3 + repeat ? 'scale(1.05)' : 'scale(0.95)',
                transition: 'all 0.4s cubic-bezier(0.25, 1, 0.5, 1)',
              }}
            >
              <div className="text-[10px] uppercase tracking-widest text-[#8a8f98]/60 mb-3 flex items-center gap-1.5">
                <TrendingUp className="w-3 h-3" /> Performance
              </div>
              <div className="space-y-3 min-w-[220px]">
                {METRICS.map((metric, i) => {
                  const Icon = metric.icon;
                  return (
                    <div key={i}>
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-1.5">
                          <Icon className="w-3 h-3 text-[#6366F1]" />
                          <span className="text-[10px] text-[#8a8f98]">{metric.label}</span>
                        </div>
                        <span className="text-xs text-white font-mono">
                          {typeof metric.value === 'number' && metric.value > 1000
                            ? metric.value.toLocaleString()
                            : metric.value}
                          {metric.label === 'Memory Used' || metric.label === 'Uptime' ? '%' : ''}
                        </span>
                      </div>
                      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-[#6366F1] to-[#06B6D4] transition-all duration-1000"
                          style={{ width: `${(metric.value / metric.max) * 100}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}

          {/* Sentiment Quadrant */}
          {[...Array(3)].map((_, repeat) => (
            <div key={`sentiment-${repeat}`} className="flex-shrink-0 border-l border-white/5 px-8 py-4 data-node"
              style={{
                opacity: focusedIndex === 6 + repeat ? 1 : 0.4,
                transform: focusedIndex === 6 + repeat ? 'scale(1.05)' : 'scale(0.95)',
                transition: 'all 0.4s cubic-bezier(0.25, 1, 0.5, 1)',
              }}
            >
              <div className="text-[10px] uppercase tracking-widest text-[#8a8f98]/60 mb-3 flex items-center gap-1.5">
                <Shield className="w-3 h-3" /> Sentiment
              </div>
              <div className="flex gap-2 min-w-[180px]">
                {SENTIMENT_EMOJIS.map((emoji, i) => (
                  <div
                    key={i}
                    className="flex-1 flex flex-col items-center gap-1 p-2 rounded-lg bg-white/5"
                    style={{
                      border: i === 4 ? '1px solid rgba(251, 191, 36, 0.3)' : '1px solid transparent',
                    }}
                  >
                    <span className="text-lg">{emoji}</span>
                    <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${[15, 25, 35, 20, 5][i]}%`,
                          background: ['#ef4444', '#f59e0b', '#10b981', '#06B6D4', '#fbbf24'][i],
                        }}
                      />
                    </div>
                    <span className="text-[9px] text-[#8a8f98]">{[15, 25, 35, 20, 5][i]}%</span>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {/* Network Status Quadrant */}
          {[...Array(3)].map((_, repeat) => (
            <div key={`network-${repeat}`} className="flex-shrink-0 border-l border-white/5 px-8 py-4 data-node"
              style={{
                opacity: focusedIndex === 9 + repeat ? 1 : 0.4,
                transform: focusedIndex === 9 + repeat ? 'scale(1.05)' : 'scale(0.95)',
                transition: 'all 0.4s cubic-bezier(0.25, 1, 0.5, 1)',
              }}
            >
              <div className="text-[10px] uppercase tracking-widest text-[#8a8f98]/60 mb-3 flex items-center gap-1.5">
                <Wifi className="w-3 h-3" /> Network
              </div>
              <div className="space-y-2 min-w-[180px]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Globe className="w-3 h-3 text-[#10b981]" />
                    <span className="text-[10px] text-[#8a8f98]">API Latency</span>
                  </div>
                  <span className="text-xs text-[#10b981] font-mono">24ms</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Server className="w-3 h-3 text-[#6366F1]" />
                    <span className="text-[10px] text-[#8a8f98]">Nodes</span>
                  </div>
                  <span className="text-xs text-white font-mono">12/12</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Shield className="w-3 h-3 text-[#fbbf24]" />
                    <span className="text-[10px] text-[#8a8f98]">Security</span>
                  </div>
                  <span className="text-xs text-[#fbbf24] font-mono">OK</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
