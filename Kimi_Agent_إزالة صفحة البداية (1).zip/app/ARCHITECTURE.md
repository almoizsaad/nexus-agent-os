# NEXUS — System Architecture

## Overview

Nexus uses a multi-layer architecture with clear separation between UI, business logic, and external services.

## System Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           CLIENT LAYER                                  │
├─────────────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌────────────┐  │
│  │   Workspace  │  │  Chat Panel  │  │   Sidebar    │  │   Navbar   │  │
│  │    (Page)    │  │  (Component) │  │  (Component) │  │ (Component)│  │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └─────┬──────┘  │
│         │                 │                  │                 │        │
│  ┌──────┴─────────────────┴──────────────────┴─────────────────┴──────┐  │
│  │                        UI LAYER                                     │  │
│  │  DynamicLayout / ConfidenceBadge / PredictiveChips / Toast        │  │
│  └───────────────────────────┬───────────────────────────────────────┘  │
│                              │                                          │
├──────────────────────────────┼──────────────────────────────────────────┤
│                         STATE LAYER                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────────────┐   │
│  │  useIntent   │  │  useLogStore │  │      useUserStore            │   │
│  │   (Hook)     │  │  (Zustand)   │  │      (Zustand)             │   │
│  └──────┬───────┘  └──────────────┘  └──────────────────────────────┘   │
│         │                                                               │
├─────────┼───────────────────────────────────────────────────────────────┤
│         │                    API LAYER                                   │
│  ┌──────┴──────────────────────────────────────────────────────────┐    │
│  │              AI Provider Chain (Fallback System)                  │    │
│  │  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐  │    │
│  │  │OpenRouter│───▶│   Groq   │───▶│  Gemini  │───▶│  Offline │  │    │
│  │  │Primary   │    │Fallback 1│    │Fallback 2│    │  Mode    │  │    │
│  │  └──────────┘    └──────────┘    └──────────┘    └──────────┘  │    │
│  └──────────────────────────────────────────────────────────────────┘    │
│                                                                          │
│  ┌──────────────────────────────────────────────────────────────────┐    │
│  │                    Real Data APIs                                  │    │
│  │  ┌──────────────┐  ┌──────────────────┐  ┌──────────────────┐   │    │
│  │  │OpenWeatherMap│  │ExchangeRate-API  │  │   Unsplash       │   │    │
│  │  │   (Weather)  │  │(Currency Rates)  │  │  (Images)        │   │    │
│  │  └──────────────┘  └──────────────────┘  └──────────────────┘   │    │
│  └──────────────────────────────────────────────────────────────────┘    │
└──────────────────────────────────────────────────────────────────────────┘
```

## Data Flow Sequence

```
User Input
    │
    ▼
┌─────────────────────────────────────────────────┐
│  1. Intent Analysis (useIntent hook)            │
│     ├── Call AI API (OpenRouter/Groq/Gemini)    │
│     ├── Local pattern matching (fallback)        │
│     └── Calculate dynamic confidence score       │
│                                                  │
│  2. Context Extraction                           │
│     ├── Extract location, dates, budget          │
│     ├── Fetch real weather (OpenWeatherMap)      │
│     └── Fetch exchange rates (ExchangeRate-API)  │
│                                                  │
│  3. UI Generation                                │
│     ├── Select component types based on intent   │
│     ├── Generate realistic data with real APIs   │
│     └── Calculate grid layout positions          │
│                                                  │
│  4. Rendering                                    │
│     ├── AnimatePresence for transitions          │
│     ├── DynamicLayout renders component grid     │
│     └── Each component renders its own data      │
└─────────────────────────────────────────────────┘
    │
    ▼
Generated UI with Real Data + Source Attribution
```

## API Integration Diagram

```
User Request
    │
    ▼
┌──────────────────────────────────────────────────────┐
│              AI Provider Chain                        │
│                                                      │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐          │
│  │ OpenRouter│──▶│   Groq   │──▶│  Gemini  │          │
│  │ Priority 1│  │ Priority 2│  │ Priority 3│          │
│  │  (Free)   │  │  (Free)   │  │  (Free)   │          │
│  └─────┬─────┘  └─────┬─────┘  └─────┬─────┘          │
│        │              │              │                │
│        └──────────────┴──────────────┘                │
│                       │                               │
│              ┌────────▼────────┐                      │
│              │   Offline Mode  │ ◄── All fail         │
│              │  (Local Logic)  │                      │
│              └────────┬────────┘                      │
└───────────────────────┼──────────────────────────────┘
                        │
    ┌───────────────────┼───────────────────┐
    │                   │                   │
    ▼                   ▼                   ▼
┌──────────┐    ┌──────────────┐    ┌──────────┐
│ Weather  │    │  Exchange    │    │  Images  │
│   API    │    │    Rates     │    │   API    │
└──────────┘    └──────────────┘    └──────────┘
```

## Component Hierarchy

```
App
└── Workspace (page)
    ├── Navbar
    ├── Sidebar
    │   ├── Module Navigation (analysis, code, creative, travel, chat, data)
    │   └── System Log (filterable, clearable, scrollable)
    ├── Main Canvas
    │   ├── Intent Header (confidence badge, reasoning)
    │   ├── DynamicLayout (animated grid)
    │   │   ├── FlightCard
    │   │   ├── HotelCard
    │   │   ├── TimelineView
    │   │   ├── BudgetChart
    │   │   ├── OverviewCard
    │   │   ├── WeatherWidget
    │   │   ├── TableComponent
    │   │   ├── FormComponent
    │   │   ├── ListComponent
    │   │   └── AnalysisCard
    │   └── PredictiveChips
    └── Chat Panel
        ├── Messages (auto-scroll, scroll-to-bottom)
        └── Input (voice, attach, text, send)
```

## State Management

### Zustand Stores

```typescript
// Log Store
interface LogState {
  entries: LogEntry[];        // Last 200 entries
  filterLevel: LogLevel;      // all | info | warn | error | debug
  addEntry: (entry) => void;
  clearEntries: () => void;
  setFilterLevel: (level) => void;
  getFilteredEntries: () => LogEntry[];
}
```

### Hook: useIntent

```typescript
interface UseIntentReturn {
  result: IntentResult | null;      // Current analysis result
  isAnalyzing: boolean;             // Loading state
  error: string | null;             // Error message
  progress: number;                 // 0-100 progress bar
  analyzeIntent: (input) => Promise<IntentResult>;
  getPredictions: () => PredictiveSuggestion[];
}
```

## Data Models

```typescript
interface IntentResult {
  intent: IntentType;         // planning | booking | research | analysis | creation | comparison | chat
  confidence: number;         // 0-100 (dynamically calculated)
  layout: LayoutType;         // dashboard | form | timeline | comparison | chat | gallery
  components: ComponentConfig[];
  context: UserContext;       // location, dates, budget, history
  reasoning: string;          // Human-readable explanation
}

interface ComponentConfig {
  id: string;
  type: 'card' | 'table' | 'chart' | 'form' | 'timeline' | 'map' | 'gallery' | 'list';
  title: string;
  data: Record<string, unknown>;
  position: { x, y, w, h };  // Grid position
}

interface PredictiveSuggestion {
  id: string;
  label: string;
  confidence: number;         // Dynamic based on context
  action: string;
  icon: string;
}
```

## Error Handling Flow

```
API Call
    │
    ├──► Success ──► Return data ──► Render
    │
    └──► Error
         │
         ├──► Rate Limited ──► Try next provider
         │
         ├──► Timeout ──► Try next provider
         │
         ├──► Invalid Key ──► Log error, try next provider
         │
         └──► All Failed ──► Offline Mode
                              │
                              ├──► Use local pattern matching
                              ├──► Generate realistic fallback data
                              └──► Show "Offline Mode" banner
```

## Performance Optimizations

1. **Code Splitting** — `React.lazy()` for page components
2. **Memoization** — `React.memo` on DynamicLayout and ComponentRenderer
3. **Virtual Scrolling** — System log keeps only last 200 entries
4. **AbortController** — API requests timeout after 8 seconds
5. **Debouncing** — Input changes debounced for performance
6. **Tree Shaking** — Vite handles dead code elimination

## Security Considerations

1. **API Keys** — Stored in `.env`, never committed to git
2. **Client-Side Only** — No backend server, no data persistence
3. **No Sensitive Data** — Local storage only for preferences
4. **HTTPS Only** — All API calls use HTTPS
5. **Input Sanitization** — User input escaped before rendering
