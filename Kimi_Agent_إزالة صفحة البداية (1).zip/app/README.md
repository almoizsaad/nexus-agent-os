# NEXUS — Adaptive AI Workspace

> **Beyond the Chatbot** — An Intent-Driven Generative UI system that creates the interface you need, when you need it. Built for DOO Builders League 2026.

![Nexus Workspace](https://img.shields.io/badge/Nexus-AI%20Workspace-1C1917?style=flat&logoColor=white)
![React](https://img.shields.io/badge/React-18+-61DAFB?style=flat&logo=react)
![TypeScript](https://img.shields.io/badge/TypeScript-5.0+-3178C6?style=flat&logo=typescript)
![Vite](https://img.shields.io/badge/Vite-5.0+-646CFF?style=flat&logo=vite)

## What is Nexus?

Nexus is not a chatbot. It's an **Intent-Driven Generative UI** system that dynamically creates interfaces based on natural language input. Say "Plan a business trip to Paris next week" and Nexus generates a complete trip planning interface with flights, hotels, itinerary, weather, and budget — all in real-time.

The system combines **real AI APIs** (OpenRouter, Groq, Gemini) with **real-time data** (OpenWeatherMap, ExchangeRate-API) to deliver production-ready experiences. When APIs fail, it gracefully falls back to offline mode with realistic data.

### Key Features

- **Intent Analysis** — Natural language parsed into structured intent with confidence scoring
- **Generative UI** — Dynamic layouts generated in real-time (dashboards, timelines, comparisons, forms)
- **Multi-Provider AI** — OpenRouter → Groq → Gemini → Offline fallback chain
- **Real Data APIs** — OpenWeatherMap weather data, ExchangeRate-API currency conversion
- **Predictive UX** — Context-aware suggestions before you ask
- **Transparent AI** — Confidence scores, source attribution, and reasoning visible
- **Offline Mode** — Graceful degradation when all APIs fail
- **Accessibility** — WCAG 2.1 AA compliant, keyboard navigation, screen reader support

## Live Demo

**[nexus-ai-workspace.vercel.app](https://nexus-ai-workspace.vercel.app)**

## Quick Start

```bash
# Clone the repository
git clone https://github.com/almoizsaad/appy.git
cd appy

# Install dependencies
npm install

# Set up environment variables
cp .env.example .env
# Edit .env with your API keys (see Environment Variables below)

# Start development server
npm run dev

# Build for production
npm run build
```

## Environment Variables

| Variable | Required | Description | Signup |
|----------|----------|-------------|--------|
| `VITE_OPENROUTER_KEY` | **Yes** | Primary AI provider (OpenRouter) | [openrouter.ai](https://openrouter.ai/) |
| `VITE_GROQ_KEY` | No | Fallback AI provider (Groq) | [console.groq.com](https://console.groq.com/) |
| `VITE_GEMINI_KEY` | No | Fallback AI provider (Google) | [aistudio.google.com](https://aistudio.google.com/) |
| `VITE_OPENWEATHER_KEY` | No | Real weather data | [openweathermap.org](https://openweathermap.org/api) |
| `VITE_UNSPLASH_KEY` | No | Destination images | [unsplash.com/developers](https://unsplash.com/developers) |

> **Note**: The app works with just `VITE_OPENROUTER_KEY`. All other keys are optional and provide enhanced functionality.

## Tech Stack

| Technology | Purpose |
|------------|---------|
| React 18 | UI framework |
| TypeScript | Type safety |
| Vite | Build tool |
| Tailwind CSS | Styling |
| shadcn/ui | Component primitives |
| Framer Motion | Animations |
| Zustand | State management |
| TanStack Query | Data fetching |

## Project Structure

```
src/
├── components/
│   ├── generative-ui/     # Dynamic UI components
│   │   ├── DynamicLayout.tsx    # Grid layout renderer
│   │   ├── ChatPanel.tsx        # Chat interface
│   │   ├── ConfidenceBadge.tsx  # Confidence indicator
│   │   ├── PredictiveChips.tsx  # Suggestion chips
│   │   └── ...
│   ├── layout/            # Shell components
│   │   ├── Navbar.tsx
│   │   └── Sidebar.tsx
│   └── ui/                # shadcn/ui components
├── lib/
│   ├── api/
│   │   ├── aiProviders.ts     # Multi-provider AI system
│   │   └── dataApis.ts        # Weather, exchange rates
│   ├── agents/
│   │   └── intentAnalyzer.ts  # Intent analysis engine
│   └── types/
│       └── intent.ts          # TypeScript interfaces
├── hooks/
│   └── useIntent.ts       # Main intent analysis hook
├── stores/
│   ├── logStore.ts        # System log state
│   └── userStore.ts       # User preferences
├── pages/
│   └── Workspace.tsx      # Main workspace (no landing page)
└── App.tsx                # Routes (redirects / to /workspace)
```

## Architecture

See [ARCHITECTURE.md](ARCHITECTURE.md) for detailed system diagrams and data flow.

## Failure Tests

See [FAILURE_TESTS.md](FAILURE_TESTS.md) for 8 comprehensive failure scenarios with recovery paths.

## UX Principles

See [UX_PRINCIPLES.md](UX_PRINCIPLES.md) for the design system documentation.

## License

MIT License — DOO Builders League 2026
