# NEXUS — UX Principles & Design System

## Design Philosophy: "Artisan Editorial"

Nexus rejects the cold, clinical AI aesthetic. Instead, it embraces:

- **Warmth** — Paper textures, warm neutrals, human-crafted feel
- **Clarity** — Every decision is transparent and explained
- **Tactility** — Physical cards, ink progress bars, stamp badges
- **Motion** — Purposeful animations that guide, not distract

## Color System

### Primary Palette

| Token | Hex | Usage |
|-------|-----|-------|
| `--nexus-paper` | `#FDFCF8` | Page background |
| `--nexus-card` | `#FFFFFF` | Card surfaces |
| `--nexus-elevated` | `#FAF9F6` | Elevated surfaces |
| `--nexus-dark` | `#1C1917` | Primary text, buttons |
| `--nexus-charcoal` | `#292524` | Headings |
| `--nexus-stone` | `#78716C` | Secondary text |
| `--nexus-stone-light` | `#A8A29E` | Muted text, borders |

### Accent Colors

| Token | Hex | Usage |
|-------|-----|-------|
| `--nexus-crimson` | `#BE123C` | Primary accent, active states |
| `--nexus-teal` | `#0F766E` | AI indicators, success |
| `--nexus-warning` | `#B45309` | Warnings, prices |
| `--nexus-success` | `#15803D` | Success states |
| `--nexus-error` | `#991B1B` | Errors |

### Semantic Colors

| State | Background | Text |
|-------|-----------|------|
| High Confidence (90-100) | `rgba(21, 128, 61, 0.1)` | `#15803D` |
| Medium Confidence (70-89) | `rgba(180, 83, 9, 0.1)` | `#B45309` |
| Low Confidence (0-69) | `rgba(153, 27, 27, 0.1)` | `#991B1B` |

## Typography Scale

| Element | Font | Size | Weight | Line Height |
|---------|------|------|--------|-------------|
| H1 | Playfair Display | 40px | 600 | 1.2 |
| H2 | Inter | 28px | 600 | 1.3 |
| H3 | Inter | 20px | 600 | 1.3 |
| Body | Inter | 14px | 400 | 1.6 |
| Small | Inter | 12px | 400 | 1.5 |
| Label | Inter | 12px | 500 | 1.4 |
| Mono | IBM Plex Mono | 10-12px | 400 | 1.4 |

## Animation Principles

### Timing

| Type | Duration | Easing |
|------|----------|--------|
| Micro-interaction | 150ms | ease |
| Card hover | 200ms | ease |
| Layout transition | 300ms | spring (stiffness: 300, damping: 30) |
| Content reveal | 400ms | ease-out |
| Confetti | 2000-4000ms | ease-out |

### Rules

1. **Purposeful** — Every animation guides attention or provides feedback
2. **Subtle** — Never flashy or distracting
3. **Respectful** — `prefers-reduced-motion` disables all animations
4. **Consistent** — Same timing/easing for same types of actions

## Accessibility Guidelines

### Keyboard Navigation

| Key | Action |
|-----|--------|
| Tab | Navigate between interactive elements |
| Enter | Activate focused element |
| Escape | Close panels, cancel actions |
| Arrow keys | Navigate within lists/menus |

### Focus Indicators

- All interactive elements have `2px solid #BE123C` focus ring
- Focus ring offset: `2px`
- Visible on keyboard navigation only (`:focus-visible`)

### Screen Reader Support

- `aria-label` on all icon buttons
- `aria-live="polite"` on system log
- `role="log"` on log container
- `aria-current="page"` on active navigation
- `aria-expanded` on collapsible sections

### Color Contrast

| Element | Ratio | Status |
|---------|-------|--------|
| Body text on paper | 12.5:1 | Pass (AAA) |
| Secondary text on paper | 5.8:1 | Pass (AA) |
| Buttons on paper | 15.2:1 | Pass (AAA) |
| Crimson accent | 4.6:1 | Pass (AA) |

## AI-Native UX Patterns

### Intent-Driven Interface

1. User describes intent in natural language
2. System shows confidence score building
3. Interface generates in real-time
4. Every element shows its data source

### Transparent AI

- Confidence scores always visible
- Reasoning explained in header
- Data sources attributed (OpenWeatherMap, etc.)
- Offline mode clearly indicated

### Predictive UX

- Context-aware suggestions appear automatically
- Chips show confidence percentage
- Applied chips become muted/non-clickable
- Suggestions adapt to time of day/season

### Offline Grace

- Yellow banner indicates offline state
- Sample data clearly labeled
- No blocking error states
- Auto-recovery when connection returns
