/**
 * ═══════════════════════════════════════════════════
 * NEXUS Intent Analyzer — Real AI + Local Fallback
 * ═══════════════════════════════════════════════════
 */

import { streamChatCompletion, analyzeIntentWithAI } from '@/lib/api/aiProviders';

export { streamChatCompletion, analyzeIntentWithAI };

// ─── Local Intent Analysis (Offline Mode) ───
export function analyzeIntentLocal(input: string): {
  intent: string;
  confidence: number;
  reasoning: string;
} {
  const lower = input.toLowerCase();

  const patterns: Array<{
    intent: string;
    keywords: string[];
    weight: number;
  }> = [
    {
      intent: 'planning',
      keywords: ['plan', 'trip', 'travel', 'itinerary', 'schedule', 'organize', 'vacation', 'journey', 'visit', 'going to', 'flying to'],
      weight: 1.0,
    },
    {
      intent: 'booking',
      keywords: ['book', 'flight', 'hotel', 'reserve', 'ticket', 'stay', 'accommodation', 'room', 'reservation'],
      weight: 1.0,
    },
    {
      intent: 'comparison',
      keywords: ['compare', 'versus', 'vs', 'difference', 'better', 'best', 'cheaper', 'cheapest'],
      weight: 1.0,
    },
    {
      intent: 'research',
      keywords: ['research', 'weather', 'find', 'look up', 'search', 'info', 'about', 'guide', 'what is', 'how to'],
      weight: 0.9,
    },
    {
      intent: 'analysis',
      keywords: ['analyze', 'analysis', 'budget', 'cost', 'spending', 'report', 'metrics', 'data', 'breakdown'],
      weight: 1.0,
    },
    {
      intent: 'creation',
      keywords: ['create', 'make', 'build', 'generate', 'design', 'write', 'draft', 'compose'],
      weight: 1.0,
    },
  ];

  let bestIntent = 'chat';
  let bestScore = 0;
  let totalMatches = 0;

  for (const pattern of patterns) {
    const matches = pattern.keywords.filter((kw) => lower.includes(kw));
    const score = matches.length * pattern.weight;
    totalMatches += matches.length;

    if (score > bestScore) {
      bestScore = score;
      bestIntent = pattern.intent;
    }
  }

  // Calculate confidence
  const lengthFactor = Math.min(1, input.length / 20);
  const specificityBonus = /\d|(?:to\s+\w+|from\s+\w+|in\s+\w+|next\s+\w+|\$\d)/.test(input)
    ? 15
    : 0;

  const confidence = Math.round(
    Math.min(85, Math.max(30, bestScore * 25 + totalMatches * 5)) * lengthFactor +
      specificityBonus
  );

  return {
    intent: bestIntent,
    confidence,
    reasoning:
      totalMatches > 0
        ? `Detected "${bestIntent}" intent via local pattern matching (${totalMatches} keyword matches)`
        : 'Input unclear — defaulting to chat mode. Try being more specific about what you want to plan, book, research, or analyze.',
  };
}
