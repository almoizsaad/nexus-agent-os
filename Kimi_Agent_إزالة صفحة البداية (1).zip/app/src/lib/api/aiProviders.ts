/**
 * ═══════════════════════════════════════════════════
 * NEXUS AI Provider System — Multi-Provider Fallback
 * ═══════════════════════════════════════════════════
 *
 * Primary: OpenRouter (free tier, no credit card)
 * Fallback 1: Groq (fast, free tier)
 * Fallback 2: Gemini (Google, free tier)
 * Fallback 3: Offline mode (local intelligence)
 */

import { addLog } from '@/stores/logStore';

export interface AIProvider {
  name: string;
  baseUrl: string;
  key: string | undefined;
  models: string[];
  priority: number;
  headers?: Record<string, string>;
}

// ─── Provider Configuration ───
const PROVIDERS: AIProvider[] = [
  {
    name: 'openrouter',
    baseUrl: 'https://openrouter.ai/api/v1',
    key: import.meta.env.VITE_OPENROUTER_KEY,
    models: [
      'deepseek/deepseek-r1:free',
      'deepseek/deepseek-chat:free',
      'meta-llama/llama-3.3-70b-instruct:free',
      'google/gemini-2.0-flash-exp:free',
    ],
    priority: 1,
    headers: {
      'HTTP-Referer': typeof window !== 'undefined' ? window.location.origin : 'https://nexus-ai.app',
      'X-Title': 'Nexus AI Workspace',
    },
  },
  {
    name: 'groq',
    baseUrl: 'https://api.groq.com/openai/v1',
    key: import.meta.env.VITE_GROQ_KEY,
    models: ['llama-3.3-70b-versatile', 'mixtral-8x7b-32768'],
    priority: 2,
  },
  {
    name: 'gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta',
    key: import.meta.env.VITE_GEMINI_KEY,
    models: ['gemini-2.0-flash-exp', 'gemini-1.5-flash'],
    priority: 3,
  },
];

// ─── Active Provider Tracking ───
let activeProvider: AIProvider | null = null;
let offlineMode = false;

export function isOfflineMode(): boolean {
  return offlineMode;
}

export function getActiveProvider(): AIProvider | null {
  return activeProvider;
}

export function getActiveProviderName(): string {
  return activeProvider?.name || 'offline';
}

// ─── Stream Chat Completion with Fallback ───
export async function* streamChatCompletion(
  messages: Array<{ role: string; content: string }>,
  maxRetries = 2
): AsyncGenerator<string> {
  offlineMode = false;

  const sortedProviders = [...PROVIDERS]
    .filter((p) => p.key)
    .sort((a, b) => a.priority - b.priority);

  if (sortedProviders.length === 0) {
    offlineMode = true;
    addLog('warn', 'AIProvider', 'No API keys configured — entering offline mode');
    yield '\n[Offline Mode: AI features running with local intelligence]';
    return;
  }

  for (const provider of sortedProviders) {
    try {
      addLog('debug', 'AIProvider', `Trying ${provider.name} (${provider.models[0]})...`);

      if (provider.name === 'gemini') {
        yield* streamGemini(provider, messages, maxRetries);
      } else {
        yield* streamOpenAICompatible(provider, messages, maxRetries);
      }

      activeProvider = provider;
      offlineMode = false;
      addLog('info', 'AIProvider', `Response from ${provider.name} (200 OK)`);
      return;
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      addLog('warn', 'AIProvider', `${provider.name} failed: ${errMsg}`);
      console.warn(`${provider.name} failed:`, err);
      continue;
    }
  }

  // All providers failed
  offlineMode = true;
  activeProvider = null;
  addLog('error', 'AIProvider', 'All AI providers failed — entering offline mode');
  yield '\n[All AI providers unavailable — using local intelligence]';
}

// ─── OpenAI-compatible streaming (OpenRouter, Groq) ───
async function* streamOpenAICompatible(
  provider: AIProvider,
  messages: Array<{ role: string; content: string }>,
  maxRetries: number
): AsyncGenerator<string> {
  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(`${provider.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${provider.key}`,
          'Content-Type': 'application/json',
          ...(provider.headers || {}),
        },
        body: JSON.stringify({
          model: provider.models[0],
          messages: messages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
          stream: true,
          temperature: 0.7,
          max_tokens: 2000,
        }),
      });

      if (!response.ok) {
        if (response.status === 429) {
          throw new Error(`Rate limited (429) — retrying...`);
        }
        throw new Error(`HTTP ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error('No reader available');

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || trimmed === 'data: [DONE]') continue;
          if (trimmed.startsWith('data: ')) {
            try {
              const data = JSON.parse(trimmed.slice(6));
              const content = data.choices?.[0]?.delta?.content || data.choices?.[0]?.text;
              if (content) yield content;
            } catch {
              // Skip malformed JSON
            }
          }
        }
      }

      return; // Success
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
      if (attempt < maxRetries) {
        await new Promise((r) => setTimeout(r, 1000 * (attempt + 1)));
        continue;
      }
    }
  }

  throw lastError || new Error('All retries exhausted');
}

// ─── Gemini API streaming ───
async function* streamGemini(
  provider: AIProvider,
  messages: Array<{ role: string; content: string }>,
  maxRetries: number
): AsyncGenerator<string> {
  const userMessage = messages.filter((m) => m.role !== 'system').pop();
  const systemMessage = messages.find((m) => m.role === 'system');

  if (!userMessage) {
    yield 'No user message found.';
    return;
  }

  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const url = `${provider.baseUrl}/models/${provider.models[0]}:streamGenerateContent?key=${provider.key}`;

      const requestBody: Record<string, unknown> = {
        contents: [
          {
            role: 'user',
            parts: [{ text: userMessage.content }],
          },
        ],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 2000,
        },
      };

      if (systemMessage) {
        requestBody.systemInstruction = {
          parts: [{ text: systemMessage.content }],
        };
      }

      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody),
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const reader = response.body?.getReader();
      if (!reader) throw new Error('No reader available');

      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() || '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed) continue;
          try {
            const data = JSON.parse(trimmed);
            const text = data.candidates?.[0]?.content?.parts?.[0]?.text;
            if (text) yield text;
          } catch {
            // Skip malformed JSON
          }
        }
      }

      return;
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
      if (attempt < maxRetries) {
        await new Promise((r) => setTimeout(r, 1000 * (attempt + 1)));
        continue;
      }
    }
  }

  throw lastError || new Error('All retries exhausted');
}

// ─── Intent Analysis via AI ───
export async function analyzeIntentWithAI(
  input: string
): Promise<{ intent: string; confidence: number; reasoning: string }> {
  const sortedProviders = [...PROVIDERS]
    .filter((p) => p.key)
    .sort((a, b) => a.priority - b.priority);

  if (sortedProviders.length === 0) {
    addLog('warn', 'AIProvider', 'No API keys — using local intent analysis');
    return {
      intent: 'chat',
      confidence: 50,
      reasoning: 'No AI provider configured — using local analysis',
    };
  }

  for (const provider of sortedProviders) {
    try {
      addLog('debug', 'AIProvider', `Analyzing intent via ${provider.name}...`);

      let result: { intent: string; confidence: number; reasoning: string } | null = null;

      if (provider.name === 'gemini') {
        result = await analyzeIntentGemini(provider, input);
      } else {
        result = await analyzeIntentOpenAI(provider, input);
      }

      if (result) {
        activeProvider = provider;
        offlineMode = false;
        addLog(
          'info',
          'AIProvider',
          `Intent from ${provider.name}: ${result.intent} (${result.confidence}%)`
        );
        return result;
      }
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : String(err);
      addLog('warn', 'AIProvider', `${provider.name} intent analysis failed: ${errMsg}`);
      continue;
    }
  }

  // All failed
  offlineMode = true;
  addLog('error', 'AIProvider', 'All providers failed — falling back to local analysis');
  return {
    intent: 'chat',
    confidence: 50,
    reasoning: 'All AI providers failed — using local analysis',
  };
}

async function analyzeIntentOpenAI(
  provider: AIProvider,
  input: string
): Promise<{ intent: string; confidence: number; reasoning: string } | null> {
  const response = await fetch(`${provider.baseUrl}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${provider.key}`,
      'Content-Type': 'application/json',
      ...(provider.headers || {}),
    },
    body: JSON.stringify({
      model: provider.models[0],
      messages: [
        {
          role: 'system',
          content: `You are an intent analyzer for an AI workspace. Analyze user input and respond ONLY with a JSON object in this exact format:
{"intent": "planning|booking|research|analysis|creation|comparison|chat", "confidence": 0-100, "reasoning": "brief explanation"}

Intent definitions:
- planning: Trip planning, itinerary creation, scheduling
- booking: Flight/hotel booking, reservations
- research: Information lookup, weather, facts
- analysis: Data analysis, budget review, metrics
- creation: Content creation, writing, designing
- comparison: Comparing options, prices, features
- chat: General conversation, unclear intent

Respond with ONLY the JSON object, no other text.`,
        },
        {
          role: 'user',
          content: input,
        },
      ],
      temperature: 0.3,
      max_tokens: 500,
    }),
  });

  if (!response.ok) return null;

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content;
  if (!content) return null;

  // Parse JSON from response
  try {
    // Try direct parse first
    const parsed = JSON.parse(content);
    return {
      intent: parsed.intent || 'chat',
      confidence: Math.min(100, Math.max(0, parsed.confidence || 70)),
      reasoning: parsed.reasoning || `Detected ${parsed.intent || 'chat'} intent`,
    };
  } catch {
    // Try extracting JSON from text
    const jsonMatch = content.match(/\{[\s\S]*?\}/);
    if (jsonMatch) {
      try {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          intent: parsed.intent || 'chat',
          confidence: Math.min(100, Math.max(0, parsed.confidence || 70)),
          reasoning: parsed.reasoning || `Detected ${parsed.intent || 'chat'} intent`,
        };
      } catch {
        // Fall through
      }
    }
  }

  return null;
}

async function analyzeIntentGemini(
  provider: AIProvider,
  input: string
): Promise<{ intent: string; confidence: number; reasoning: string } | null> {
  const url = `${provider.baseUrl}/models/${provider.models[0]}:generateContent?key=${provider.key}`;

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: `Analyze the following user input and respond ONLY with a JSON object in this exact format:
{"intent": "planning|booking|research|analysis|creation|comparison|chat", "confidence": 0-100, "reasoning": "brief explanation"}

User input: "${input}"`,
            },
          ],
        },
      ],
      generationConfig: {
        temperature: 0.3,
        maxOutputTokens: 500,
      },
    }),
  });

  if (!response.ok) return null;

  const data = await response.json();
  const content = data.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!content) return null;

  try {
    const parsed = JSON.parse(content);
    return {
      intent: parsed.intent || 'chat',
      confidence: Math.min(100, Math.max(0, parsed.confidence || 70)),
      reasoning: parsed.reasoning || `Detected ${parsed.intent || 'chat'} intent`,
    };
  } catch {
    const jsonMatch = content.match(/\{[\s\S]*?\}/);
    if (jsonMatch) {
      try {
        const parsed = JSON.parse(jsonMatch[0]);
        return {
          intent: parsed.intent || 'chat',
          confidence: Math.min(100, Math.max(0, parsed.confidence || 70)),
          reasoning: parsed.reasoning || `Detected ${parsed.intent || 'chat'} intent`,
        };
      } catch {
        // Fall through
      }
    }
  }

  return null;
}
