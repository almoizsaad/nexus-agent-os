/**
 * ═══════════════════════════════════════════════════
 * NEXUS Real Data APIs — Weather, Exchange Rates
 * ═══════════════════════════════════════════════════
 */

import { addLog } from '@/stores/logStore';

// ─── Weather API (OpenWeatherMap) ───
const WEATHER_API_KEY = import.meta.env.VITE_OPENWEATHER_KEY;

export interface WeatherData {
  location: string;
  temperature: number;
  feelsLike: number;
  condition: string;
  description: string;
  humidity: number;
  windSpeed: number;
  icon: string;
  forecast: Array<{
    day: string;
    temp: number;
    tempMin: number;
    tempMax: number;
    condition: string;
    icon: string;
  }>;
}

export async function fetchWeather(city: string): Promise<WeatherData | null> {
  if (!WEATHER_API_KEY) {
    addLog('debug', 'WeatherAPI', 'No API key — using fallback weather data');
    return generateFallbackWeather(city);
  }

  try {
    addLog('debug', 'WeatherAPI', `Fetching weather for ${city}...`);

    // Current weather
    const currentRes = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${WEATHER_API_KEY}&units=metric`,
      { signal: AbortSignal.timeout(8000) }
    );

    if (!currentRes.ok) {
      if (currentRes.status === 404) {
        addLog('warn', 'WeatherAPI', `City "${city}" not found — using fallback`);
        return generateFallbackWeather(city);
      }
      throw new Error(`HTTP ${currentRes.status}`);
    }

    const current = await currentRes.json();

    // 5-day forecast
    const forecastRes = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?q=${encodeURIComponent(city)}&appid=${WEATHER_API_KEY}&units=metric`,
      { signal: AbortSignal.timeout(8000) }
    );

    let forecast: WeatherData['forecast'] = [];

    if (forecastRes.ok) {
      const forecastData = await forecastRes.json();
      // Group by day and get daily averages
      const dailyData: Record<string, typeof forecastData.list> = {};
      forecastData.list.forEach((item: { dt_txt: string }) => {
        const day = item.dt_txt.split(' ')[0];
        if (!dailyData[day]) dailyData[day] = [];
        dailyData[day].push(item);
      });

      forecast = Object.entries(dailyData)
        .slice(0, 5)
        .map(([date, items]) => {
          const avgTemp = items.reduce((sum: number, i: { main: { temp: number } }) => sum + i.main.temp, 0) / items.length;
          const minTemp = Math.min(...items.map((i: { main: { temp_min: number } }) => i.main.temp_min));
          const maxTemp = Math.max(...items.map((i: { main: { temp_max: number } }) => i.main.temp_max));
          const midItem = items[Math.floor(items.length / 2)];
          return {
            day: new Date(date).toLocaleDateString('en-US', { weekday: 'short' }),
            temp: Math.round(avgTemp),
            tempMin: Math.round(minTemp),
            tempMax: Math.round(maxTemp),
            condition: midItem.weather[0]?.main || 'Clear',
            icon: midItem.weather[0]?.icon || '01d',
          };
        });
    }

    addLog('info', 'WeatherAPI', `Weather loaded for ${city} (${current.main.temp}°C)`);

    return {
      location: current.name || city,
      temperature: Math.round(current.main.temp),
      feelsLike: Math.round(current.main.feels_like),
      condition: current.weather[0]?.main || 'Clear',
      description: current.weather[0]?.description || '',
      humidity: current.main.humidity,
      windSpeed: Math.round(current.wind.speed * 3.6), // Convert to km/h
      icon: current.weather[0]?.icon || '01d',
      forecast,
    };
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    addLog('warn', 'WeatherAPI', `Weather API failed: ${errMsg} — using fallback`);
    return generateFallbackWeather(city);
  }
}

function generateFallbackWeather(city: string): WeatherData {
  const conditions = ['Sunny', 'Partly Cloudy', 'Cloudy', 'Clear'];
  const baseTemp = 15 + Math.floor(Math.random() * 15);
  const now = new Date();

  return {
    location: city,
    temperature: baseTemp,
    feelsLike: baseTemp - 2,
    condition: conditions[Math.floor(Math.random() * conditions.length)],
    description: 'moderate weather',
    humidity: 50 + Math.floor(Math.random() * 30),
    windSpeed: 10 + Math.floor(Math.random() * 15),
    icon: '02d',
    forecast: Array.from({ length: 5 }).map((_, i) => {
      const date = new Date(now.getTime() + (i + 1) * 24 * 60 * 60 * 1000);
      return {
        day: date.toLocaleDateString('en-US', { weekday: 'short' }),
        temp: baseTemp + Math.floor(Math.random() * 10 - 5),
        tempMin: baseTemp - 5,
        tempMax: baseTemp + 5,
        condition: conditions[Math.floor(Math.random() * conditions.length)],
        icon: '02d',
      };
    }),
  };
}

// ─── Exchange Rate API ───
export interface ExchangeRateData {
  base: string;
  rates: Record<string, number>;
  date: string;
}

export async function fetchExchangeRates(base: string = 'USD'): Promise<ExchangeRateData | null> {
  try {
    addLog('debug', 'ExchangeAPI', `Fetching exchange rates for ${base}...`);

    const response = await fetch(
      `https://api.exchangerate-api.com/v4/latest/${base}`,
      { signal: AbortSignal.timeout(8000) }
    );

    if (!response.ok) throw new Error(`HTTP ${response.status}`);

    const data = await response.json();

    addLog('info', 'ExchangeAPI', `Exchange rates loaded (${base})`);

    return {
      base: data.base,
      rates: data.rates,
      date: data.date,
    };
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : String(err);
    addLog('warn', 'ExchangeAPI', `Exchange rate API failed: ${errMsg} — using fallback`);

    // Fallback rates (approximate)
    return {
      base,
      date: new Date().toISOString().split('T')[0],
      rates: {
        USD: 1,
        EUR: 0.92,
        GBP: 0.79,
        JPY: 150,
        AUD: 1.53,
        CAD: 1.35,
        CHF: 0.88,
        CNY: 7.19,
        INR: 83,
        AED: 3.67,
        SAR: 3.75,
      },
    };
  }
}

// ─── Currency Conversion Helper ───
export function convertCurrency(
  amount: number,
  from: string,
  to: string,
  rates: Record<string, number>
): number {
  if (from === to) return amount;
  const fromRate = rates[from] || 1;
  const toRate = rates[to] || 1;
  return Math.round((amount / fromRate) * toRate * 100) / 100;
}

// ─── Destination Image (Unsplash) ───
const UNSPLASH_KEY = import.meta.env.VITE_UNSPLASH_KEY;

export async function fetchDestinationImage(city: string): Promise<string | null> {
  if (!UNSPLASH_KEY) return null;

  try {
    const response = await fetch(
      `https://api.unsplash.com/search/photos?query=${encodeURIComponent(city)}&client_id=${UNSPLASH_KEY}&per_page=1&orientation=landscape`,
      { signal: AbortSignal.timeout(8000) }
    );

    if (!response.ok) return null;

    const data = await response.json();
    return data.results?.[0]?.urls?.regular || null;
  } catch {
    return null;
  }
}

// ─── Currency Symbol Helper ───
export function getCurrencySymbol(currency: string): string {
  const symbols: Record<string, string> = {
    USD: '$',
    EUR: '\u20AC',
    GBP: '\u00A3',
    JPY: '\u00A5',
    AUD: 'A$',
    CAD: 'C$',
    CHF: 'CHF',
    CNY: '\u00A5',
    INR: '\u20B9',
    AED: 'AED',
    SAR: 'SAR',
  };
  return symbols[currency] || currency;
}
