import { memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Plane, Hotel, MapPin, Calendar, DollarSign,
  Clock, Star, ArrowRight, Sun, Cloud, CloudRain, Wind, Pencil,
  AlertCircle, Info
} from 'lucide-react';
import type { ComponentConfig, IntentType } from '@/lib/types/intent';
import { useState } from 'react';

interface DynamicLayoutProps {
  components: ComponentConfig[];
  intent: IntentType;
  isLoading?: boolean;
  error?: string | null;
}

const springTransition = {
  type: 'spring' as const,
  stiffness: 300,
  damping: 30,
};

/* ─── Loading Skeleton ─── */
function CardSkeleton() {
  return (
    <div className="nexus-card p-4 space-y-3 animate-pulse">
      <div className="h-4 rounded w-2/3" style={{ background: '#E7E5E4' }} />
      <div className="h-20 rounded-lg" style={{ background: '#FAF9F6' }} />
      <div className="h-3 rounded w-1/2" style={{ background: '#E7E5E4' }} />
    </div>
  );
}

/* ─── Empty State ─── */
function EmptyState({ title }: { title: string }) {
  return (
    <div className="nexus-card p-6 text-center">
      <Info className="w-8 h-8 mx-auto mb-2" style={{ color: '#A8A29E' }} />
      <h3 className="text-sm font-medium mb-1" style={{ color: '#78716C' }}>{title}</h3>
      <p className="text-xs" style={{ color: '#A8A29E' }}>No data available yet</p>
    </div>
  );
}

/* ─── Error State ─── */
function ErrorState({ error, onRetry }: { error: string; onRetry?: () => void }) {
  return (
    <div className="nexus-card p-6 text-center" style={{ borderColor: '#FECACA' }}>
      <AlertCircle className="w-8 h-8 mx-auto mb-2" style={{ color: '#991B1B' }} />
      <h3 className="text-sm font-medium mb-1" style={{ color: '#991B1B' }}>Something went wrong</h3>
      <p className="text-xs mb-3" style={{ color: '#78716C' }}>{error}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="nexus-btn nexus-btn-primary text-xs"
          style={{ padding: '0.375rem 0.75rem' }}
        >
          Try Again
        </button>
      )}
    </div>
  );
}

/* ─── Editable Card Wrapper ─── */
function EditableCard({ children, title }: { children: React.ReactNode; title?: string }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(title || '');

  if (isEditing) {
    return (
      <div
        className="nexus-card p-4"
        style={{ borderColor: '#BE123C', borderWidth: '2px' }}
      >
        <textarea
          value={editValue}
          onChange={(e) => setEditValue(e.target.value)}
          className="w-full bg-transparent outline-none resize-none text-sm"
          style={{ color: '#292524', fontFamily: 'Inter, sans-serif' }}
          rows={3}
        />
        <div className="flex gap-2 mt-2">
          <button
            onClick={() => setIsEditing(false)}
            className="nexus-btn nexus-btn-primary"
            style={{ padding: '0.375rem 0.75rem', fontSize: '12px' }}
          >
            Save
          </button>
          <button
            onClick={() => setIsEditing(false)}
            className="nexus-btn nexus-btn-secondary"
            style={{ padding: '0.375rem 0.75rem', fontSize: '12px' }}
          >
            Cancel
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className="group relative"
      onClick={() => setIsEditing(true)}
      title="Click to edit"
      style={{ cursor: 'pointer' }}
    >
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
        <div
          className="w-6 h-6 rounded flex items-center justify-center"
          style={{ background: '#FAF9F6', border: '1px solid #E7E5E4' }}
        >
          <Pencil className="w-3 h-3" style={{ color: '#78716C' }} />
        </div>
      </div>
      {children}
    </div>
  );
}

/* ─── Flight Card ─── */
function FlightCard({ data }: { data: Record<string, unknown> }) {
  const items = (data?.items as Array<Record<string, string>>) || [];
  if (items.length === 0) return <EmptyState title="Flight Options" />;

  return (
    <EditableCard title="Flight Options">
      <div className="nexus-card p-4">
        <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Flight Options</h3>
        <div className="space-y-3">
          {items.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ ...springTransition, delay: i * 0.1 }}
              className="flex items-center gap-3 sm:gap-4 p-3 rounded-lg transition-colors"
              style={{ background: '#FAF9F6', border: '1px solid #E7E5E4', cursor: 'pointer' }}
              whileHover={{ borderColor: '#D6D3D1' }}
            >
              <div
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{ background: 'rgba(190, 18, 60, 0.08)' }}
              >
                <Plane className="w-4 h-4 sm:w-5 sm:h-5" style={{ color: '#BE123C' }} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate" style={{ color: '#292524' }}>{item.airline}</div>
                <div className="text-xs flex items-center gap-1 flex-wrap" style={{ color: '#78716C' }}>
                  <Clock className="w-3 h-3" /> {item.time} · {item.stops}
                </div>
              </div>
              <div className="text-right flex-shrink-0">
                <div className="text-sm font-semibold" style={{ color: '#B45309' }}>{item.price}</div>
                <ArrowRight className="w-4 h-4 ml-auto" style={{ color: '#A8A29E' }} />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </EditableCard>
  );
}

/* ─── Hotel Card ─── */
function HotelCard({ data }: { data: Record<string, unknown> }) {
  const items = (data?.items as Array<Record<string, unknown>>) || [];
  if (items.length === 0) return <EmptyState title="Hotel Recommendations" />;

  return (
    <EditableCard title="Hotel Recommendations">
      <div className="nexus-card p-4">
        <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Hotel Recommendations</h3>
        <div className="grid grid-cols-1 gap-3">
          {items.map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...springTransition, delay: i * 0.1 }}
              className="p-3 rounded-lg transition-colors"
              style={{ background: '#FAF9F6', border: '1px solid #E7E5E4', cursor: 'pointer' }}
              whileHover={{ borderColor: '#D6D3D1' }}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: 'rgba(15, 118, 110, 0.08)' }}
                  >
                    <Hotel className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: '#0F766E' }} />
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate" style={{ color: '#292524' }}>{item.name as string}</div>
                    <div className="flex items-center gap-1 mt-0.5">
                      {Array.from({ length: 5 }).map((_, j) => (
                        <Star
                          key={j}
                          className={`w-3 h-3 ${j < Math.floor((item.rating as number) || 0) ? 'fill-[#B45309]' : ''}`}
                          style={j < Math.floor((item.rating as number) || 0) ? { color: '#B45309' } : { color: '#E7E5E4' }}
                        />
                      ))}
                      <span className="text-xs ml-1" style={{ color: '#78716C' }}>{String(item.rating ?? '')}</span>
                    </div>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-sm font-semibold" style={{ color: '#15803D' }}>{item.price as string}</div>
                  <div className="text-[10px]" style={{ color: '#A8A29E' }}>per night</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </EditableCard>
  );
}

/* ─── Timeline View ─── */
function TimelineView({ data }: { data: Record<string, unknown> }) {
  const days = (data?.days as Array<Record<string, unknown>>) || [];
  if (days.length === 0) return <EmptyState title="Itinerary Timeline" />;

  return (
    <EditableCard title="Itinerary Timeline">
      <div className="nexus-card p-4">
        <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Itinerary Timeline</h3>
        <div className="relative">
          <div
            className="absolute left-3 sm:left-4 top-0 bottom-0 w-px"
            style={{ background: '#E7E5E4' }}
          />
          <div className="space-y-4">
            {days.map((day, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ ...springTransition, delay: i * 0.08 }}
                className="flex items-center gap-3 sm:gap-4 ml-1 sm:ml-2"
              >
                <div
                  className="w-4 h-4 sm:w-5 sm:h-5 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: '#FFFFFF', border: '2px solid #0F766E' }}
                >
                  <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#0F766E' }} />
                </div>
                <div
                  className="flex-1 p-3 rounded-lg min-w-0"
                  style={{ background: '#FAF9F6', border: '1px solid #E7E5E4' }}
                >
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 flex-shrink-0" style={{ color: '#0F766E' }} />
                    <span className="text-xs font-medium" style={{ color: '#0F766E' }}>Day {String(day.day ?? '')}</span>
                  </div>
                  <div className="text-sm mt-1 break-words" style={{ color: '#292524' }}>{day.activity as string}</div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </EditableCard>
  );
}

/* ─── Budget Chart ─── */
function BudgetChart({ data }: { data: Record<string, unknown> }) {
  const total = (data?.total as string) || '$0';
  const flights = (data?.flights as string) || '$0';
  const hotel = (data?.hotel as string) || '$0';
  const meals = (data?.meals as string) || '$0';
  const transport = (data?.transport as string) || '$0';
  const other = (data?.other as string) || '$0';

  // Parse amounts for percentages
  const parseAmount = (s: string) => parseInt(s.replace(/[$,]/g, '')) || 0;
  const amounts = {
    flights: parseAmount(flights),
    hotel: parseAmount(hotel),
    meals: parseAmount(meals),
    transport: parseAmount(transport),
    other: parseAmount(other),
  };
  const totalAmount = Object.values(amounts).reduce((a, b) => a + b, 1); // +1 to avoid div by zero

  const categories = [
    { label: 'Flights', value: flights, color: '#BE123C', pct: (amounts.flights / totalAmount) * 100 },
    { label: 'Hotel', value: hotel, color: '#0F766E', pct: (amounts.hotel / totalAmount) * 100 },
    { label: 'Meals', value: meals, color: '#B45309', pct: (amounts.meals / totalAmount) * 100 },
    { label: 'Transport', value: transport, color: '#15803D', pct: (amounts.transport / totalAmount) * 100 },
    { label: 'Other', value: other, color: '#78716C', pct: (amounts.other / totalAmount) * 100 },
  ];

  return (
    <EditableCard title="Budget Estimate">
      <div className="nexus-card p-4">
        <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Budget Estimate</h3>
        <div className="space-y-4">
          <div className="text-center">
            <div
              className="text-xl sm:text-2xl font-bold break-words"
              style={{ color: '#1C1917', fontFamily: 'Playfair Display, serif' }}
            >
              {total}
            </div>
            <div className="nexus-label">Estimated Total</div>
          </div>
          <div className="nexus-ink-progress">
            <div className="flex h-full rounded-full overflow-hidden">
              {categories.map((cat, i) => (
                <motion.div
                  key={i}
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.max(cat.pct, 2)}%` }}
                  transition={{ duration: 0.8, delay: i * 0.1, ease: 'easeOut' }}
                  className="h-full"
                  style={{ background: cat.color }}
                />
              ))}
            </div>
          </div>
          <div className="space-y-2">
            {categories.map((cat, i) => (
              <div key={i} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2 min-w-0">
                  <div className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: cat.color }} />
                  <span className="truncate" style={{ color: '#78716C' }}>{cat.label}</span>
                </div>
                <span className="font-medium flex-shrink-0 ml-2" style={{ color: '#292524' }}>{cat.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </EditableCard>
  );
}

/* ─── Overview Card ─── */
function OverviewCard({ data }: { data: Record<string, unknown> }) {
  return (
    <EditableCard title="Trip Overview">
      <div className="nexus-card p-4">
        <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Trip Overview</h3>
        <div className="grid grid-cols-2 gap-3">
          {[
            { icon: MapPin, label: 'Destination', value: (data?.destination as string) || 'Paris, France', color: '#BE123C' },
            { icon: Calendar, label: 'Dates', value: (data?.dates as string) || 'Select dates', color: '#0F766E' },
            { icon: Clock, label: 'Duration', value: (data?.duration as string) || '7 days', color: '#B45309' },
            { icon: DollarSign, label: 'Budget', value: (data?.budget as string) || '$5,200 est.', color: '#15803D' },
          ].map((item, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ ...springTransition, delay: i * 0.08 }}
              className="p-3 rounded-lg"
              style={{ background: '#FAF9F6', border: '1px solid #E7E5E4' }}
            >
              <item.icon className="w-4 h-4 mb-2" style={{ color: item.color }} />
              <div className="nexus-label" style={{ fontSize: 10 }}>{item.label}</div>
              <div className="text-sm font-medium mt-0.5 break-words" style={{ color: '#292524' }}>{item.value}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </EditableCard>
  );
}

/* ─── Weather Widget ─── */
function WeatherWidget({ data }: { data: Record<string, unknown> }) {
  const forecast = (data?.forecast as Array<{ day: string; temp: string; condition: string }>) || [];
  const location = (data?.location as string) || (data?.destination as string) || 'Paris, France';
  const temperature = (data?.temperature as string) || '';
  const condition = (data?.condition as string) || '';

  const getWeatherIcon = (cond: string) => {
    const c = cond.toLowerCase();
    if (c.includes('rain')) return CloudRain;
    if (c.includes('cloud')) return Cloud;
    if (c.includes('wind')) return Wind;
    return Sun;
  };

  const getWeatherColor = (cond: string) => {
    const c = cond.toLowerCase();
    if (c.includes('rain')) return '#0F766E';
    if (c.includes('cloud')) return '#78716C';
    if (c.includes('wind')) return '#0F766E';
    return '#B45309';
  };

  return (
    <div className="nexus-card p-4">
      <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Weather Forecast</h3>
      {temperature && (
        <div className="flex items-center gap-3 mb-3 p-2 rounded-lg" style={{ background: '#FAF9F6' }}>
          {(() => {
            const Icon = getWeatherIcon(condition);
            return <Icon className="w-5 h-5" style={{ color: getWeatherColor(condition) }} />;
          })()}
          <div>
            <div className="text-lg font-semibold" style={{ color: '#292524' }}>{temperature}</div>
            <div className="text-xs" style={{ color: '#78716C' }}>{condition} · {location}</div>
          </div>
        </div>
      )}
      {!temperature && (
        <div className="flex items-center gap-2 mb-3">
          <Sun className="w-4 h-4" style={{ color: '#B45309' }} />
          <span className="nexus-label">{location}</span>
        </div>
      )}
      <div className="grid grid-cols-4 gap-2 text-center">
        {forecast.map((w, i) => {
          const Icon = getWeatherIcon(w.condition);
          const color = getWeatherColor(w.condition);
          return (
            <div key={i} className="p-2 rounded-lg" style={{ background: '#FAF9F6' }}>
              <div className="text-[10px]" style={{ color: '#A8A29E' }}>{w.day}</div>
              <Icon className="w-4 h-4 mx-auto my-1" style={{ color }} />
              <div className="text-xs font-medium" style={{ color: '#292524' }}>{w.temp}</div>
            </div>
          );
        })}
        {forecast.length === 0 && (
          <>
            {[
              { day: 'Mon', icon: Sun, temp: '18°', color: '#B45309' },
              { day: 'Tue', icon: Cloud, temp: '16°', color: '#78716C' },
              { day: 'Wed', icon: Sun, temp: '20°', color: '#B45309' },
              { day: 'Thu', icon: Wind, temp: '17°', color: '#0F766E' },
            ].map((w, i) => (
              <div key={i} className="p-2 rounded-lg" style={{ background: '#FAF9F6' }}>
                <div className="text-[10px]" style={{ color: '#A8A29E' }}>{w.day}</div>
                <w.icon className="w-4 h-4 mx-auto my-1" style={{ color: w.color }} />
                <div className="text-xs font-medium" style={{ color: '#292524' }}>{w.temp}</div>
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
}

/* ─── Table Component ─── */
function TableComponent({ data }: { data: Record<string, unknown> }) {
  const headers = (data?.headers as string[]) || [];
  const rows = (data?.rows as string[][]) || [];

  if (headers.length === 0 && rows.length === 0) return <EmptyState title="Comparison Table" />;

  return (
    <div className="nexus-card p-4 overflow-x-auto">
      <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Comparison</h3>
      <table className="w-full text-xs">
        <thead>
          <tr style={{ borderBottom: '1px solid #E7E5E4' }}>
            {headers.map((h, i) => (
              <th key={i} className="text-left py-2 px-2 font-medium" style={{ color: '#78716C' }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i} style={{ borderBottom: '1px solid #F5F5F4' }}>
              {row.map((cell, j) => (
                <td key={j} className="py-2 px-2 break-words" style={{ color: j === 0 ? '#292524' : '#78716C' }}>{cell}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* ─── Form Component ─── */
function FormComponent({ data }: { data: Record<string, unknown> }) {
  const fields = (data?.fields as Array<{ label: string; value: string }>) || [];
  const message = (data?.message as string) || '';

  return (
    <div className="nexus-card p-4">
      <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Details</h3>
      {message ? (
        <p className="text-xs" style={{ color: '#78716C' }}>{message}</p>
      ) : (
        <div className="space-y-3">
          {fields.map((field, i) => (
            <div key={i}>
              <label className="nexus-label block mb-1" style={{ fontSize: 10 }}>{field.label}</label>
              <input
                type="text"
                defaultValue={field.value}
                className="w-full px-3 py-2 rounded-lg text-sm outline-none focus:ring-2 focus:ring-[#BE123C]"
                style={{ background: '#FAF9F6', border: '1px solid #E7E5E4', color: '#292524' }}
                readOnly
              />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ─── List Component ─── */
function ListComponent({ data }: { data: Record<string, unknown> }) {
  const items = (data?.items as Array<Record<string, unknown> | string>) || [];
  const insights = (data?.insights as string[]) || [];
  const recommendations = (data?.recommendations as string[]) || [];

  const allItems = items.length > 0 ? items : insights.length > 0 ? insights : recommendations;

  if (allItems.length === 0) return <EmptyState title="List" />;

  return (
    <div className="nexus-card p-4">
      <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>
        {items.length > 0 ? 'Items' : insights.length > 0 ? 'Insights' : 'Recommendations'}
      </h3>
      <div className="space-y-2">
        {allItems.map((item, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.05 }}
            className="flex items-start gap-2 p-2 rounded-lg"
            style={{ background: '#FAF9F6', border: '1px solid #E7E5E4' }}
          >
            <div className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0" style={{ background: '#0F766E' }} />
            <span className="text-xs break-words" style={{ color: '#292524' }}>
              {typeof item === 'string' ? item : (item as Record<string, string>).label || JSON.stringify(item)}
            </span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

/* ─── Analysis Card ─── */
function AnalysisCard({ data }: { data: Record<string, unknown> }) {
  const summary = (data?.summary as string) || '';
  const insights = (data?.insights as string[]) || [];
  const savings = (data?.savings as string[]) || [];

  return (
    <div className="nexus-card p-4">
      <h3 className="text-sm font-semibold mb-3" style={{ color: '#292524' }}>Analysis</h3>
      {summary && (
        <p className="text-xs mb-4 leading-relaxed" style={{ color: '#78716C' }}>{summary}</p>
      )}
      {insights.length > 0 && (
        <div className="mb-4">
          <div className="nexus-label mb-2" style={{ fontSize: 10 }}>Key Insights</div>
          <div className="space-y-1.5">
            {insights.map((insight, i) => (
              <div key={i} className="flex items-start gap-2 text-xs">
                <Star className="w-3 h-3 mt-0.5 flex-shrink-0" style={{ color: '#B45309' }} />
                <span style={{ color: '#292524' }}>{insight}</span>
              </div>
            ))}
          </div>
        </div>
      )}
      {savings.length > 0 && (
        <div>
          <div className="nexus-label mb-2" style={{ fontSize: 10 }}>Potential Savings</div>
          <div className="space-y-1.5">
            {savings.map((saving, i) => (
              <div key={i} className="flex items-start gap-2 text-xs">
                <DollarSign className="w-3 h-3 mt-0.5 flex-shrink-0" style={{ color: '#15803D' }} />
                <span style={{ color: '#15803D' }}>{saving}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ─── Component Renderer ─── */
const ComponentRenderer = memo(function ComponentRenderer({ component }: { component: ComponentConfig }) {
  switch (component.type) {
    case 'list':
      if (component.id === 'flight-search' || component.title === 'Flight Options') {
        return <FlightCard data={component.data || {}} />;
      }
      if (component.id === 'results-list' || component.title === 'Available Options') {
        return <FlightCard data={component.data || {}} />;
      }
      if (component.id === 'recommendations' || component.title === 'Recommendations') {
        return <ListComponent data={component.data || {}} />;
      }
      if (component.id === 'sources' || component.title === 'Sources') {
        return <ListComponent data={component.data || {}} />;
      }
      if (component.id === 'tips' || component.title === 'Travel Tips') {
        return <ListComponent data={component.data || {}} />;
      }
      return <ListComponent data={component.data || {}} />;
    case 'gallery':
      if (component.id === 'hotel-recs' || component.title === 'Hotel Recommendations') {
        return <HotelCard data={component.data || {}} />;
      }
      return <HotelCard data={component.data || {}} />;
    case 'timeline':
      return <TimelineView data={component.data || {}} />;
    case 'chart':
      if (component.id === 'budget-tracker' || component.title === 'Budget Estimate') {
        return <BudgetChart data={component.data || {}} />;
      }
      if (component.id === 'metrics' || component.title === 'Key Metrics') {
        return <BudgetChart data={component.data || {}} />;
      }
      return <BudgetChart data={component.data || {}} />;
    case 'card':
      if (component.id === 'trip-overview' || component.title === 'Trip Overview' || component.title === 'Overview') {
        return <OverviewCard data={component.data || {}} />;
      }
      if (component.id === 'weather' || component.title === 'Weather Forecast' || component.title === 'Weather') {
        return <WeatherWidget data={component.data || {}} />;
      }
      if (component.id === 'info-card' || component.title?.startsWith('About') || component.title === 'Research Results') {
        return <AnalysisCard data={component.data || {}} />;
      }
      if (component.id === 'breakdown' || component.title === 'Detailed Breakdown') {
        return <AnalysisCard data={component.data || {}} />;
      }
      if (component.id === 'pros-cons' || component.title === 'Analysis' || component.title === 'Analysis Summary') {
        return <AnalysisCard data={component.data || {}} />;
      }
      if (component.id === 'weather-card' || component.title === 'Current Weather') {
        return <WeatherWidget data={component.data || {}} />;
      }
      if (component.id === 'welcome') {
        return <FormComponent data={component.data || {}} />;
      }
      return (
        <div className="nexus-card p-4">
          <h3 className="text-sm font-semibold mb-2" style={{ color: '#292524' }}>{component.title}</h3>
          <div className="text-xs break-words" style={{ color: '#78716C' }}>
            {component.data ? JSON.stringify(component.data, null, 2) : 'No data'}
          </div>
        </div>
      );
    case 'table':
      return <TableComponent data={component.data || {}} />;
    case 'form':
      return <FormComponent data={component.data || {}} />;
    default:
      return (
        <div className="nexus-card p-4">
          <h3 className="text-sm font-semibold mb-2" style={{ color: '#292524' }}>{component.title}</h3>
          <div className="text-xs" style={{ color: '#78716C' }}>Component type: {component.type}</div>
        </div>
      );
  }
});

/* ─── Dynamic Layout ─── */
const DynamicLayout = memo(function DynamicLayout({ components, intent, isLoading, error }: DynamicLayoutProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4 sm:gap-6 p-4 sm:p-6">
        {[1, 2, 3].map((i) => (
          <div key={i} className="col-span-1 lg:col-span-6">
            <CardSkeleton />
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6">
        <ErrorState error={error} />
      </div>
    );
  }

  if (components.length === 0) {
    return (
      <div className="p-6">
        <EmptyState title="No Components" />
      </div>
    );
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={intent}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4 sm:gap-6 p-4 sm:p-6 auto-rows-auto"
      >
        {components.map((component, index) => {
          // Calculate responsive column span
          const w = component.position?.w || 6;
          let colSpan = 'lg:col-span-6';
          if (w <= 4) colSpan = 'lg:col-span-4';
          else if (w <= 6) colSpan = 'lg:col-span-6';
          else if (w <= 8) colSpan = 'lg:col-span-8';
          else colSpan = 'lg:col-span-12';

          return (
            <motion.div
              key={`${component.id}-${index}`}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ ...springTransition, delay: index * 0.08 }}
              className={`col-span-1 ${colSpan}`}
            >
              <div className="h-full">
                <ComponentRenderer component={component} />
              </div>
            </motion.div>
          );
        })}
      </motion.div>
    </AnimatePresence>
  );
});

export default DynamicLayout;
