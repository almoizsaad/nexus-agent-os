module.exports = {
  "extends": [
    "expo"
  ],
  "rules": {
    "react-hooks/refs": "off",
    "react-hooks/set-state-in-effect": "off",
    "react/no-unescaped-entities": "off",
    "no-unused-vars": "off",
    "no-undef": "off",
    "import/no-named-as-default-member": "off"
  }
};