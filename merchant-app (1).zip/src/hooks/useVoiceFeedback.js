import { useCallback } from 'react';
import { Platform } from 'react-native';
import * as Speech from 'expo-speech';

/**
 * نظام التغذية الصوتية المطور والآمن لـ NuqtaPay
 * يدعم الهاتف والويب، ويضمن نطق النصوص الحرة والأرقام دون كراش
 */
export function useVoiceFeedback() {
  
  // دالة النطق العامة والمباشرة
  const speak = useCallback((text) => {
    if (!text) return;

    try {
      if (Platform.OS === 'web') {
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance(text);
          utterance.lang = 'ar-SA';
          utterance.rate = 0.9;
          window.speechSynthesis.speak(utterance);
        } else {
          console.warn('Web Speech API غير مدعومة.');
        }
      } else {
        // إسقاط أي صوت معلق وبدء النطق فوراً بشكل مستقر
        Speech.stop();
        Speech.speak(text, {
          language: 'ar-SA',
          rate: 0.85, // سرعة نطق واضحة ومفهومة للفصحى
          pitch: 1.0,
        });
      }
    } catch (error) {
      console.error('فشل تشغيل التغذية الصوتية داخلياً:', error);
    }
  }, []);

  /**
   * دالة إعلان النجاح المالي المحدثة (Polymorphic):
   * - إذا مررت لها رقماً (Number): تحوله تلقائياً عبر formatAmountArabic إلى "تم استلام X جنيه"
   * - إذا مررت لها نصاً (String): تنطقه مباشرة كما هو دون تعديل
   */
  const announceSuccess = useCallback((input) => {
    if (typeof input === 'number') {
      const formatted = formatAmountArabic(input);
      const text = `تم استلام ${formatted}`;
      speak(text);
    } else if (typeof input === 'string') {
      speak(input);
    }
  }, [speak]);

  // دالة الإعلان عن التنبيهات والأخطاء
  const announceError = useCallback((reason) => {
    speak(reason || 'فشلت العملية');
  }, [speak]);

  return { speak, announceSuccess, announceError };
}

/**
 * محول الأرقام الذكي إلى "جنيه" و "قرش" لتوليد نطق سليم
 */
function formatAmountArabic(amount) {
  const sdg = Math.floor(amount);
  const qirsh = Math.round((amount - sdg) * 100);

  let text = '';
  if (sdg > 0) text += `${sdg} جنيه`;
  if (qirsh > 0) text += ` و${qirsh} قرش`;
  return text || 'صفر';
}