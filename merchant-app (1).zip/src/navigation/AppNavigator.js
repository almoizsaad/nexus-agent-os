import { MaterialCommunityIcons } from "@expo/vector-icons";
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Colors, Radii, Shadow } from '../theme';

import LoginScreen    from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import PaymentScreen  from '../screens/PaymentScreen';
import HistoryScreen  from '../screens/HistoryScreen';
import TopUpScreen    from '../screens/TopUpScreen';
import CardsScreen    from '../screens/CardsScreen';
import ProfileScreen  from '../screens/ProfileScreen';
import { useAuth }    from '../context/AuthContext';

const Stack = createNativeStackNavigator();
const Tab   = createBottomTabNavigator();

// Tab definition — 5 tabs now
const TABS = [
  { name: "Payment", component: PaymentScreen, icon: "qrcode-scan", label: "دفع" },
  { name: "Cards",   component: CardsScreen,   icon: "credit-card-multiple", label: "بطاقاتي" },
  { name: "TopUp",   component: TopUpScreen,   icon: "cash-plus", label: "شحن" },
  { name: "History", component: HistoryScreen,  icon: "history", label: "السجل" },
  { name: "Profile", component: ProfileScreen,  icon: "account-circle", label: "الحساب" },
];

function TabIcon({ icon, label, focused }) {
  return (
    <View style={tab.item}>
      <MaterialCommunityIcons
        name={icon}
        size={24}
        color={focused ? Colors.gold : Colors.textMuted}
      />
      <Text style={[tab.label, focused && tab.labelActive]}>{label}</Text>
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown: false,
        tabBarStyle: tab.bar,
        tabBarShowLabel: false,
        tabBarHideOnKeyboard: true }}
    >
      {TABS.map(({ name, component, icon, label }) => (
        <Tab.Screen
          key={name}
          name={name}
          component={component}
          options={{
            tabBarIcon: ({ focused }) => <TabIcon icon={icon} label={label} focused={focused} />,
          }}
        />
      ))}
    </Tab.Navigator>
  );
}

function AuthStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false, animation: 'slide_from_left' }}>
      <Stack.Screen name="Login"    component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  const { merchant, loading } = useAuth();
  if (loading) return null;

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false, animation: 'fade' }}>
        {merchant
          ? <Stack.Screen name="Main"     component={MainTabs} />
          : <Stack.Screen name="AuthFlow" component={AuthStack} />
        }
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const tab = StyleSheet.create({
  bar: {
    backgroundColor: Colors.surface,
    borderTopWidth: 1,
    borderTopColor: Colors.borderLight,
    height: 68,
    paddingBottom: 4,
    ...Shadow.xs,
  },
  item:          { alignItems: 'center', gap: 2, paddingTop: 5 },
  iconWrap:      { width: 34, height: 34, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  iconWrapActive:{ backgroundColor: Colors.goldPale },
  icon:          { fontSize: 18, color: Colors.textMuted },
  iconActive:    { color: Colors.gold },
  label:         { fontSize: 9, fontWeight: '500', color: Colors.textMuted },
  labelActive:   { fontWeight: '800', color: Colors.gold },
});
