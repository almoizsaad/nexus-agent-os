import { useFocusEffect } from '@react-navigation/native';
import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  TouchableOpacity, Alert, TextInput,
  StatusBar, RefreshControl, Platform,
  KeyboardAvoidingView, ScrollView, TouchableWithoutFeedback, Keyboard 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radii, Shadow } from '../theme';
import { Button, Divider, AmountDisplay } from '../components/UI';
import {
  getLinkedCards, addLinkedCard, removeLinkedCard,
  verifyCard, processTopUp,
} from '../services/api';

const VIEW = {
  LIST:    'list',
  SCAN:    'scan',
  DETAIL:  'detail',
};

export default function CardsScreen() {
  const [view, setView]           = useState(VIEW.LIST);
  const [cards, setCards]         = useState([]);
  const [selected, setSelected]   = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const [permission, requestPermission] = useCameraPermissions();
  const [scanReady, setScanReady]       = useState(false);
  const [scanLocked, setScanLocked]     = useState(false);

  const [topUpAmount, setTopUpAmount]   = useState('');
  const [topUpLoading, setTopUpLoading] = useState(false);

  const loadCards = useCallback(async () => {
    try {
      const list = await getLinkedCards();
      setCards(list);
    } catch (err) {
      console.error("Failed to load cards:", err);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadCards();
    }, [loadCards])
  );

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadCards();
    setRefreshing(false);
  };

  const openScanner = async () => {
    if (!permission?.granted) {
      const res = await requestPermission();
      if (!res.granted) {
        Alert.alert('إذن مطلوب', 'يُرجى السماح بالكاميرا من إعدادات الهاتف');
        return;
      }
    }
    setScanLocked(false);
    setScanReady(false);
    setView(VIEW.SCAN);
  };

  const handleCardScanned = useCallback(async ({ data }) => {
    if (scanLocked) return;
    
    let cardIdentifierForVerify = data;
    try {
      const p = JSON.parse(data);
      // تعديل: دعم بنية الـ QR القديمة والمحدثة معاً لتفادي الرفض الصامت
      cardIdentifierForVerify = p.cardId || p.payload?.cardId || p.cid || data;
    } catch { 
      // إذا لم يكن جيسون، نعتبر النص هو المعرف مباشرة
      cardIdentifierForVerify = data;
    }

    setScanLocked(true);
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }

    try {
      // تعديل: نمرر النص الخام أو المعرف المستخلص بناءً على معالجة السيرفر
      const card = await verifyCard(cardIdentifierForVerify);
      if (!card) throw new Error('البطاقة غير موجودة بالسيرفر');

      const updated = await addLinkedCard({
        cardId:     card.cardId,
        serial:     card.serialNumber || card.cardId.slice(-8),
        balanceSDG: card.balanceSDG || 0,
        status:     card.status,
        qrPayload:  data,
      });
      setCards(updated);
      
      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }

      Alert.alert(
        '✓ تم ربط البطاقة',
        `البطاقة ${card.cardId?.slice(-8)} مضافة. رصيدها الحالي: ${(card.balanceSDG || 0).toFixed(2)} SDG`,
        [{ text: 'حسناً', onPress: () => setView(VIEW.LIST) }]
      );
    } catch (err) {
      Alert.alert('خطأ', err.response?.data?.error || err.message || 'فشل ربط البطاقة');
      setScanLocked(false);
    }
  }, [scanLocked]);

  const handleUnlink = (card) => {
    Alert.alert(
      'إزالة البطاقة',
      `إزالة البطاقة ${card.serial} من قائمتك؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'إزالة',
          style: 'destructive',
          onPress: async () => {
            const updated = await removeLinkedCard(card.cardId);
            setCards(updated);
            if (view === VIEW.DETAIL) setView(VIEW.LIST);
          },
        },
      ]
    );
  };
const handleTopUp = async () => {
    const parsedAmount = parseFloat(topUpAmount);
    if (!parsedAmount || parsedAmount <= 0 || !selected) return;

    setTopUpLoading(true);
    try {
      if (Platform.OS !== 'web') {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
      }

      // تمرير المعرف والمبلغ بصيغة رقمية تماماً (Float) لتتوافق مع الباكيند
      const res = await processTopUp(selected.cardId, parsedAmount);
      
      // حل مشكلة الرصيد 0: قراءة الرصيد الحقيقي من السيرفر وتحويله من Paise بقسمته على 100
      const updatedCard = { 
        ...selected, 
        balanceSDG: (res.data.transaction.balanceAfterSDG || (res.data.transaction.newBalancePaise / 100)) 
      };
      
      setSelected(updatedCard);
      setCards(prev => prev.map(c => c.cardId === selected.cardId ? updatedCard : c));
      setTopUpAmount('');
      
      if (Platform.OS !== 'web') {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      Alert.alert('✓ تم الشحن', `تم شحن البطاقة بنجاح. الرصيد الجديد: ${updatedCard.balanceSDG.toFixed(2)} SDG`);
    } catch (err) {
      if (Platform.OS !== 'web') {
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      }
      Alert.alert('خطأ في الشحن', err.response?.data?.error || err.message || 'فشل الاتصال بالسيرفر');
    } finally {
      setTopUpLoading(false);
    }
  };
return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar barStyle="dark-content" />
      
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 44 : 0}
      >
        {view === VIEW.LIST ? (
          /* ─── 1. واجهة قائمة البطاقات المرتبطة ─── */
          <View style={[styles.container, { flex: 1 }]}>
            <View style={styles.topBar}>
              <View>
                <Text style={styles.title}>بطاقاتي</Text>
                <Text style={styles.subtitle}>{cards.length} بطاقة مرتبطة</Text>
              </View>
              <Button
                label="+ ربط بطاقة"
                variant="outline"
                onPress={openScanner}
                style={{ paddingHorizontal: Spacing.md }}
              />
            </View>

            <FlatList
              data={cards}
              keyExtractor={c => c.cardId}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.cardRow}
                  onPress={() => { setSelected(item); setView(VIEW.DETAIL); }}
                  activeOpacity={0.75}
                >
                  <View style={styles.cardRowLeft}>
                    <View style={styles.cardMini} />
                    <View>
                      <Text style={styles.cardRowSerial}>{item.serial}</Text>
                      <Text style={styles.cardRowDate}>
                        مرتبطة {item.linkedAt ? new Date(item.linkedAt).toLocaleDateString('ar-SD') : '—'}
                      </Text>
                    </View>
                  </View>
                  <View style={styles.cardRowRight}>
                    <Text style={styles.cardRowBalance}>{Number(item.balanceSDG || 0).toFixed(2)}</Text>
                    <Text style={styles.cardRowCur}>SDG</Text>
                  </View>
                </TouchableOpacity>
              )}
              ItemSeparatorComponent={() => <View style={{ height: 1, backgroundColor: Colors.borderLight, marginLeft: 72 }} />}
              ListEmptyComponent={
                <View style={styles.emptyState}>
                  <Text style={styles.emptyIcon}>💳</Text>
                  <Text style={styles.emptyTitle}>لا توجد بطاقات مرتبطة</Text>
                  <Text style={styles.emptySub}>{"اضغط \"+ ربط بطاقة\" لإضافة بطاقة دفع"}</Text>
                  <Button label="ربط بطاقة جديدة" onPress={openScanner} style={{ marginTop: Spacing.md }} />
                </View>
              }
              refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={Colors.gold} />}
              contentContainerStyle={{ flexGrow: 1 }}
              showsVerticalScrollIndicator={false}
            />
          </View>
        ) : (
          /* ─── المكونات التي تتطلب تفادي لوحة المفاتيح (SCAN & DETAIL) ─── */
          <ScrollView
            contentContainerStyle={{ flexGrow: 1 }}
            keyboardShouldPersistTaps="handled"
            showsVerticalScrollIndicator={false}
          >
            {view === VIEW.SCAN && (
              /* ─── 2. واجهة مسح الرمز QR والإدخال اليدوي ─── */
              <View style={styles.container}>
                <View style={styles.topBar}>
                  <Text style={styles.title}>ربط بطاقة جديدة</Text>
                  <TouchableOpacity onPress={() => setView(VIEW.LIST)} style={styles.closeBtn}>
                    <Text style={styles.closeBtnText}>✕</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.scanBox}>
                  {permission?.granted && (
                    <CameraView
                      style={StyleSheet.absoluteFillObject}
                      facing="back"
                      onCameraReady={() => setScanReady(true)}
                      onBarcodeScanned={scanReady && !scanLocked ? async (payload) => {
                        if (scanLocked) return;
                        setScanLocked(true);
                        setTimeout(async () => {
                          await handleCardScanned(payload);
                        }, 100);
                      } : undefined}
                      barcodeScannerSettings={{ barcodeTypes: ['qr'] }}
                    />
                  )}
                  <Corner pos="TL" /><Corner pos="TR" />
                  <Corner pos="BL" /><Corner pos="BR" />
                  <View style={[styles.scanInner, scanReady && { backgroundColor: 'rgba(255,255,255,0.85)', borderRadius: Radii.md, padding: Spacing.md }]}>
                    {!permission?.granted ? (
                      <>
                        <Text style={styles.scanTitle}>إذن الكاميرا مطلوب</Text>
                        <Button label="منح الإذن" onPress={requestPermission} style={{ marginTop: Spacing.md }} />
                      </>
                    ) : !scanReady ? (
                      <Text style={styles.scanTitle}>جاري تشغيل الكاميرا...</Text>
                    ) : (
                      <>
                        <View style={[styles.scanPulse, { borderColor: Colors.gold }]} />
                        <Text style={styles.scanTitle}>امسح رمز QR على البطاقة</Text>
                        <Text style={styles.scanSub}>ستُضاف البطاقة تلقائياً</Text>
                      </>
                    )}
                  </View>
                </View>

                {/* الحقل الذي يرتفع الآن بسلاسة فوق الكيبورد دون الاختفاء في الأسفل */}
                <View style={[styles.manualEntry, { marginTop: Spacing.md, paddingBottom: Spacing.xl }]}>
                  <Text style={styles.manualLabel}>أو أدخل الرقم التسلسلي يدوياً</Text>
                  <ManualLinkField onLink={async (id) => {
                    try {
                      const cardInfo = await verifyCard(id).catch(() => null);

                      const updated = await addLinkedCard({
                        cardId:     id,
                        serial:     id,
                        balanceSDG: cardInfo ? cardInfo.balanceSDG : 0,
                        status:     cardInfo ? cardInfo.status : 'active',
                        qrPayload:  null,
                      });
                      
                      setCards(updated);
                      Alert.alert('✓ تم الإضافة', 'البطاقة مضافة بنجاح', [
                        { text: 'حسناً', onPress: () => setView(VIEW.LIST) }
                      ]);
                    } catch (err) {
                      Alert.alert('خطأ', err.message);
                    }
                  }} />
                </View>
              </View>
            )}

            {view === VIEW.DETAIL && selected && (
              /* ─── 3. واجهة تفاصيل البطاقة وشحن الرصيد ─── */
              <View style={styles.container}>
                <View style={styles.topBar}>
                  <TouchableOpacity onPress={() => setView(VIEW.LIST)} style={styles.backBtn}>
                    <Text style={styles.backBtnText}>← رجوع</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => handleUnlink(selected)}>
                    <Text style={styles.unlinkBtn}>إزالة</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.detailCard}>
                  <View style={styles.detailCardTop}>
                    <View style={styles.cardChip} />
                    <View style={[styles.cardStatus, { backgroundColor: selected.status === 'active' ? Colors.leafBg : Colors.amberBg }]}>
                      <Text style={[styles.cardStatusText, { color: selected.status === 'active' ? Colors.leaf : Colors.amber }]}>
                        {selected.status === 'active' ? 'نشطة' : selected.status === 'virgin' ? 'جديدة' : selected.status}
                      </Text>
                    </View>
                  </View>
                  <Text style={styles.detailSerial}>{selected.serial}</Text>
                  <View style={styles.detailBalance}>
                    <Text style={styles.detailBalanceLabel}>الرصيد الحالي</Text>
                    <AmountDisplay value={selected.balanceSDG || 0} size="large" color={Colors.textInvert} />
                  </View>
                </View>

                <View style={styles.topUpCard}>
                  <Text style={styles.topUpTitle}>شحن الرصيد</Text>
                  <View style={styles.topUpRow}>
                    <TextInput
                      style={styles.topUpInput}
                      value={topUpAmount}
                      onChangeText={setTopUpAmount}
                      placeholder="المبلغ بالجنيه"
                      placeholderTextColor={Colors.textMuted}
                      keyboardType="decimal-pad"
                      textAlign="right"
                    />
                    <Button
                      label={topUpLoading ? '...' : 'شحن'}
                      onPress={handleTopUp}
                      loading={topUpLoading}
                      disabled={!topUpAmount}
                      style={{ minWidth: 90 }}
                    />
                  </View>
                </View>

                <Divider />
                <View style={{ paddingBottom: Spacing.xl }}>
                  <Text style={styles.cardIdLabel}>معرّف البطاقة</Text>
                  <Text style={styles.cardIdValue}>{selected.cardId}</Text>
                </View>
              </View>
            )}
          </ScrollView>
        )}
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function Corner({ pos }) {
  const s = {
    TL: { top: 16, left: 16, borderRightWidth: 0, borderBottomWidth: 0, borderTopLeftRadius: 5 },
    TR: { top: 16, right: 16, borderLeftWidth: 0, borderBottomWidth: 0, borderTopRightRadius: 5 },
    BL: { bottom: 16, left: 16, borderRightWidth: 0, borderTopWidth: 0, borderBottomLeftRadius: 5 },
    BR: { bottom: 16, right: 16, borderLeftWidth: 0, borderTopWidth: 0, borderBottomRightRadius: 5 },
  }[pos];
  return <View style={[cornerSt, s]} />;
}
const cornerSt = { position: 'absolute', width: 24, height: 24, borderColor: Colors.gold, borderWidth: 2.5, zIndex: 10 };

function ManualLinkField({ onLink }) {
  const [val, setVal] = useState('');
  return (
    <View style={styles.manualRow}>
      <TextInput
        style={styles.manualInput}
        value={val}
        onChangeText={setVal}
        placeholder="BATCH-001-000001"
        placeholderTextColor={Colors.textMuted}
        autoCapitalize="characters"
        autoCorrect={false}
      />
      <Button
        label={'إضافة'}
        onPress={() => { if (val.trim()) { onLink(val.trim()); setVal(''); } }}
        disabled={!val.trim()}
        style={{ minWidth: 80 }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  safe:      { flex: 1, backgroundColor: Colors.canvas },
  container: { flex: 1, zIndex: 1, padding: Spacing.md, gap: Spacing.md },
  topBar:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  title:    { fontSize: 22, fontWeight: '800', color: Colors.textPrimary },
  subtitle: { fontSize: 12, color: Colors.textMuted, marginTop: 2 },
  closeBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: Colors.borderLight, alignItems: 'center', justifyContent: 'center' },
  closeBtnText: { fontSize: 16, color: Colors.textSecondary, fontWeight: '700' },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: Colors.surface,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
  },
  cardRowLeft:    { flexDirection: 'row', alignItems: 'center', gap: 12 },
  cardMini:       { width: 44, height: 30, borderRadius: 6, backgroundColor: Colors.inkLight },
  cardRowSerial:  { fontSize: 15, fontWeight: '700', color: Colors.textPrimary, fontFamily: 'Courier New' },
  cardRowDate:    { fontSize: 11, color: Colors.textMuted, marginTop: 2 },
  cardRowRight:   { alignItems: 'flex-end' },
  cardRowBalance: { fontSize: 20, fontWeight: '800', color: Colors.textPrimary, ...(Platform.OS !== 'web' && { fontVariant: ['tabular-nums'] }) },
  cardRowCur:     { fontSize: 11, color: Colors.textMuted },
  backBtn:     { paddingVertical: 4 },
  backBtnText: { fontSize: 14, color: Colors.gold, fontWeight: '700' },
  unlinkBtn:   { fontSize: 13, color: Colors.clay, fontWeight: '700' },
  detailCard: {
    backgroundColor: Colors.ink,
    borderRadius: Radii.xl,
    padding: Spacing.xl,
    gap: Spacing.md,
    ...Shadow.elevated,
  },
  detailCardTop:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardChip:           { width: 36, height: 28, borderRadius: 5, backgroundColor: Colors.gold },
  cardStatus:         { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radii.full },
  cardStatusText:     { fontSize: 12, fontWeight: '700' },
  detailSerial:       { fontFamily: 'Courier New', fontSize: 13, color: 'rgba(255,255,255,0.5)', letterSpacing: 1 },
  detailBalance:      { gap: 4 },
  detailBalanceLabel: { fontSize: 11, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: 0.8 },
  topUpCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    gap: Spacing.sm,
    ...Shadow.card,
  },
  topUpTitle: { fontSize: 14, fontWeight: '700', color: Colors.textPrimary },
  topUpRow:   { flexDirection: 'row', gap: Spacing.sm, alignItems: 'center' },
  topUpInput: {
    flex: 1, height: 50,
    borderWidth: 1.5, borderColor: Colors.border,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    fontSize: 16, color: Colors.textPrimary,
    backgroundColor: Colors.canvas,
  },
  cardIdLabel: { fontSize: 10, fontWeight: '700', color: Colors.textMuted, letterSpacing: 0.8, textTransform: 'uppercase' },
  cardIdValue: { fontFamily: 'Courier New', fontSize: 12, color: Colors.textSecondary, letterSpacing: 0.3 },
  scanBox:  { flex: 1, backgroundColor: Colors.surface, borderRadius: Radii.xl, alignItems: 'center', justifyContent: 'center', overflow: 'hidden', ...Shadow.card },
  scanInner:{ alignItems: 'center', gap: 10, padding: Spacing.lg, zIndex: 5 },
  scanPulse:{ width: 52, height: 52, borderRadius: 26, backgroundColor: Colors.goldPale, borderWidth: 3, marginBottom: 6 },
  scanTitle:{ fontSize: 18, fontWeight: '800', color: Colors.textPrimary, textAlign: 'center' },
  scanSub:  { fontSize: 13, color: Colors.textMuted, textAlign: 'center' },
  manualEntry: { gap: Spacing.sm },
  manualLabel: { fontSize: 12, color: Colors.textMuted, fontWeight: '600', textAlign: 'center' },
  manualRow:   { flexDirection: 'row', gap: Spacing.sm },
  manualInput: {
    flex: 1, height: 46,
    borderWidth: 1.5, borderColor: Colors.border,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    fontSize: 13, color: Colors.textPrimary,
    backgroundColor: Colors.surface,
    fontFamily: 'Courier New',
  },
  emptyState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10, paddingVertical: 60 },
  emptyIcon:  { fontSize: 48 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: Colors.textPrimary },
  emptySub:   { fontSize: 13, color: Colors.textMuted, textAlign: 'center' },
});
