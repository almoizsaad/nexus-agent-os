import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  RefreshControl,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radii, Shadow } from '../theme';
import { Divider } from '../components/UI'; // تمت إزالة المكونات غير الموجودة من هنا لضمان الاستقرار
import { getTransactionHistory, processRefund } from '../services/api';

// 💡 مكون محلي يعوض المكون المفقود لضمان معالجة وعرض حالة المعاملات بدقة وأداء عالٍ
const StatusBadge = ({ status }) => {
  const getStatusDetails = (stat) => {
    switch (stat) {
      case 'completed': 
        return { text: 'مكتملة', color: Colors.leaf || '#10B981', bg: '#E6F4EA' };
      case 'pending':   
        return { text: 'معلقة', color: Colors.amber || '#F59E0B', bg: '#FEF3C7' };
      case 'failed':    
        return { text: 'فاشلة', color: Colors.clay || '#EF4444', bg: '#FEE2E2' };
      default:          
        return { text: stat || 'غير معروف', color: Colors.textMuted || '#6B7280', bg: '#F3F4F6' };
    }
  };

  const details = getStatusDetails(status);

  return (
    <View style={[styles.badgeContainer, { backgroundColor: details.bg }]}>
      <Text style={[styles.badgeText, { color: details.color }]}>
        {details.text}
      </Text>
    </View>
  );
};

// 💡 دالة فحص وتنسيق التواريخ باللغة العربية دون أي مكتبات خارجية
const formatDateString = (dateInput) => {
  const d = new Date(dateInput);
  if (isNaN(d.getTime())) return 'تاريخ غير معروف';

  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(today.getDate() - 1);

  const timeString = d.toLocaleTimeString('ar-SD', { hour: '2-digit', minute: '2-digit' });

  if (d.toDateString() === today.toDateString()) {
    return `اليوم، ${timeString}`;
  }
  if (d.toDateString() === yesterday.toDateString()) {
    return `أمس، ${timeString}`;
  }
  return `${d.toLocaleDateString('ar-SD', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}، ${timeString}`;
};

const TYPE_LABELS = {
  payment: 'دفع',
  top_up: 'شحن',
  refund: 'استرجاع',
};

const TYPE_COLORS = {
  payment: Colors.clay,
  top_up: Colors.leaf,
  refund: Colors.amber,
};

export default function HistoryScreen() {
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [totalVolume, setTotalVolume] = useState(0);

  const load = useCallback(async (pageNum = 1, refresh = false) => {
    try {
      const data = await getTransactionHistory(pageNum, 20);
      const newItems = data.data || [];

      if (refresh || pageNum === 1) {
        setTransactions(newItems);
      } else {
        setTransactions((prev) => [...prev, ...newItems]);
      }

      setHasMore(pageNum < (data.pagination?.pages || 1));

      // حساب مبيعات اليوم باستخدام المقارنة المحلية الصرفة (Pure JS)
      const todayStr = new Date().toDateString();
      const todayVolume = newItems
        .filter((t) => t.type === 'payment' && t.status === 'completed' && new Date(t.processedAt).toDateString() === todayStr)
        .reduce((sum, t) => sum + t.amountSDG, 0);
      setTotalVolume(todayVolume);
    } catch (err) {
      // Keep existing data on error
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    const fetchData = async () => {
      await load(1);
    };
    fetchData();
  }, [load]); // إضافة الدالة كاعتمادية لمنع تحذير الـ hooks

  const handleRefresh = () => {
    setRefreshing(true);
    setPage(1);
    load(1, true);
  };

  const handleLoadMore = () => {
    if (!hasMore || loading) return;
    const next = page + 1;
    setPage(next);
    load(next);
  };

  const handleRefundRequest = (txn) => {
    if (txn.type !== 'payment' || txn.status !== 'completed') return;

    Alert.alert(
      'استرجاع المبلغ',
      `هل تريد استرجاع ${txn.amountSDG.toFixed(2)} SDG؟`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'استرجاع',
          style: 'destructive',
          onPress: async () => {
            try {
              await processRefund(txn.ref);
              Alert.alert('تم', 'تم استرجاع المبلغ بنجاح');
              handleRefresh();
            } catch (err) {
              Alert.alert('خطأ', err.response?.data?.error || 'فشل الاسترجاع');
            }
          },
        },
      ]
    );
  };

  const renderItem = ({ item }) => (
    <TouchableOpacity
      onPress={() => handleRefundRequest(item)}
      activeOpacity={item.type === 'payment' && item.status === 'completed' ? 0.75 : 1}
      style={styles.txnItem}
    >
      <View style={[styles.typeBar, { backgroundColor: TYPE_COLORS[item.type] || Colors.textMuted }]} />

      <View style={styles.txnMain}>
        <View style={styles.txnTop}>
          <Text style={styles.txnType}>{TYPE_LABELS[item.type] || item.type}</Text>
          <Text style={[styles.txnAmount, { color: TYPE_COLORS[item.type] || Colors.textPrimary }]}>
            {item.type === 'payment' ? '-' : '+'}{item.amountSDG?.toFixed(2)}
            <Text style={styles.txnCurrency}> SDG</Text>
          </Text>
        </View>
        <View style={styles.txnBottom}>
          <Text style={styles.txnDate}>{formatDateString(item.processedAt)}</Text>
          <StatusBadge status={item.status} />
        </View>
        {item.ref && (
          <Text style={styles.txnRef}>{item.ref.slice(-12)}</Text>
        )}
      </View>
    </TouchableOpacity>
  );

  const renderHeader = () => (
    <View style={styles.summaryCard}>
      <Text style={styles.summaryLabel}>مبيعات اليوم</Text>
      <Text style={styles.summaryAmount}>{totalVolume.toFixed(2)}</Text>
      <Text style={styles.summaryCurrency}>SDG</Text>
    </View>
  );

  const renderEmpty = () => (
    <View style={styles.emptyState}>
      <Text style={styles.emptyEmoji}>📋</Text>
      <Text style={styles.emptyTitle}>لا توجد معاملات</Text>
      <Text style={styles.emptySubtitle}>ستظهر هنا بعد أول عملية دفع</Text>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.screenTitle}>السجل</Text>
      </View>

      <FlatList
        data={transactions}
        keyExtractor={(item) => item.ref || item._id}
        renderItem={renderItem}
        ListHeaderComponent={renderHeader}
        ListEmptyComponent={!loading ? renderEmpty : null}
        contentContainerStyle={styles.list}
        ItemSeparatorComponent={() => <View style={{ height: 1, backgroundColor: Colors.borderLight, marginLeft: 60 }} />}
        onEndReached={handleLoadMore}
        onEndReachedThreshold={0.3}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={Colors.gold}
          />
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.canvas },
  header: {
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
  },
  screenTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  summaryCard: {
    backgroundColor: Colors.ink,
    borderRadius: Radii.xl,
    margin: Spacing.md,
    padding: Spacing.xl,
    alignItems: 'center',
    gap: 4,
  },
  summaryLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.5)',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
  },
  summaryAmount: {
    fontSize: 52,
    fontWeight: '200',
    color: Colors.textInvert,
    letterSpacing: -2,
    fontVariant: ['tabular-nums'],
  },
  summaryCurrency: {
    fontSize: 16,
    color: Colors.gold,
    fontWeight: '600',
  },
  list: { paddingBottom: Spacing.xxl },
  txnItem: {
    flexDirection: 'row',
    backgroundColor: Colors.surface,
    paddingVertical: Spacing.md,
    paddingRight: Spacing.md,
  },
  typeBar: {
    width: 4,
    marginRight: Spacing.md,
    borderRadius: 2,
    marginVertical: 2,
  },
  txnMain: { flex: 1, gap: 4 },
  txnTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  txnType: {
    fontSize: 15,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  txnAmount: {
    fontSize: 17,
    fontWeight: '700',
    fontVariant: ['tabular-nums'],
  },
  txnCurrency: {
    fontSize: 12,
    fontWeight: '500',
    color: Colors.textMuted,
  },
  txnBottom: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  txnDate: {
    fontSize: 12,
    color: Colors.textMuted,
  },
  txnRef: {
    fontSize: 11,
    color: Colors.textMuted,
    fontFamily: 'Courier New',
    letterSpacing: 0.3,
    marginTop: 2,
  },
  emptyState: {
    alignItems: 'center',
    paddingTop: 80,
    gap: 12,
  },
  emptyEmoji: { fontSize: 48 },
  emptyTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  emptySubtitle: {
    fontSize: 14,
    color: Colors.textMuted,
    textAlign: 'center',
  },
  // تنسيق الـ Badge الجديد
  badgeContainer: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: Radii.sm || 6,
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgeText: {
    fontSize: 12,
    fontWeight: '600',
  },
});