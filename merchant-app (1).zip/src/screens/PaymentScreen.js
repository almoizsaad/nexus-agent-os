import React, { useState, useCallback, useRef, useEffect } from 'react';
import { View, Text, StyleSheet, Animated,
  TouchableOpacity, Alert, KeyboardAvoidingView, ScrollView, Platform } from "react-native";
import { CameraView, useCameraPermissions } from 'expo-camera';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radii, Shadow } from '../theme';
import { Button, AmountDisplay, Numpad, Divider, OfflineBanner } from '../components/UI';
import { Logo } from '../components/Logo';
import { processPayment } from '../services/api';
import { useVoiceFeedback } from '../hooks/useVoiceFeedback';
import { useNetworkStatus } from '../hooks/useNetworkStatus';
import { useAuth } from '../context/AuthContext';

const STATE = {
  AMOUNT:     'amount',
  SCAN:       'scan',
  CONFIRM:    'confirm',
  PROCESSING: 'processing',
  SUCCESS:    'success',
  ERROR:      'error',
};

const STEP_CONFIG = {
  [STATE.AMOUNT]:     { label: 'أدخل المبلغ',    dot: Colors.gold },
  [STATE.SCAN]:       { label: 'انتظار البطاقة', dot: Colors.leaf },
  [STATE.CONFIRM]:    { label: 'تأكيد الدفع',    dot: Colors.amber },
  [STATE.PROCESSING]: { label: 'جاري المعالجة',  dot: Colors.textMuted },
  [STATE.SUCCESS]:    { label: 'تمّت',            dot: Colors.leaf },
  [STATE.ERROR]:      { label: 'فشلت',           dot: Colors.clay },
};

export default function PaymentScreen() {
  const [flowState, setFlowState] = useState(STATE.AMOUNT);
  const [amountSDG, setAmountSDG] = useState('');
  const [scannedPayload, setScannedPayload] = useState(null);
  const [transaction, setTransaction] = useState(null);
  const [apiError, setApiError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [scanLocked, setScanLocked] = useState(false); // إضافة متغير القفل المفقود لتأمين الكاميرا

  const [permission, requestPermission] = useCameraPermissions();
  const isOnline = useNetworkStatus();
  const { speak } = useVoiceFeedback();
  
  // إصلاح استدعاء الصلاحيات إذا كنت بحاجة لبيانات مستخدم مستقبلاً
  const auth = useAuth(); 

  const fadeAnim = useRef(new Animated.Value(1));

  // دالة آمنة وبديلة لتنسيق الأرقام بفاصلة آلاف بدون استخدام Intl المتسببة في الانهيار
  const formatCurrency = (value) => {
    if (!value) return '0';
    const num = parseFloat(value);
    if (isNaN(num)) return value;
    return num.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  };

  const transitionTo = useCallback((nextState) => {
    Animated.timing(fadeAnim.current, { toValue: 0, duration: 120, useNativeDriver: true }).start(() => {
      setFlowState(nextState);
      Animated.timing(fadeAnim.current, { toValue: 1, duration: 150, useNativeDriver: true }).start();
    });
  }, [fadeAnim]);

  useEffect(() => {
    if (flowState === STATE.AMOUNT) speak('أدخل المبلغ المطلوب');
    if (flowState === STATE.SCAN) speak('وجه الكاميرا نحو الرمز الشريطي للبطاقة');
  }, [flowState, speak]);

  const handleNumpad = useCallback((key) => {
    if (key === 'back') {
      setAmountSDG(prev => prev.slice(0, -1));
    } else if (key === '00') {
      if (amountSDG !== '' && amountSDG.length < 8) setAmountSDG(prev => prev + '00');
    } else {
      if (amountSDG.length < 9) setAmountSDG(prev => prev + key);
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  }, [amountSDG]);

  const handleAmountReady = () => {
    const numeric = parseFloat(amountSDG);
    if (!numeric || numeric <= 0) return;
    
    if (!permission) {
      requestPermission();
      return;
    }
    
    if (!permission.granted) {
      if (!permission.canAskAgain) {
        Alert.alert('صلاحية الكاميرا معطلة', 'يرجى تفعيل صلاحية الكاميرا لتطبيق danpay من إعدادات الهاتف لتتمكن من مسح البطاقات.');
        return;
      }
      requestPermission().then(res => {
        if (res.granted) {
          setScanLocked(false);
          transitionTo(STATE.SCAN);
        } else {
          Alert.alert('خطأ', 'يجب السماح بصلاحية الكاميرا لمسح بطاقات الزبائن');
        }
      });
      return;
    }
    setScanLocked(false);
    transitionTo(STATE.SCAN);
  };

  const handleBarCodeScanned = useCallback(async ({ data }) => {
    if (scanLocked) return;
    setScanLocked(true);
    
    if (Platform.OS !== 'web') {
      await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }

    setTimeout(() => {
      try {
        // فحص وتأمين الحمولة القادمة من المتصفح/الهاتف وعمل Parse للـ JSON
        const parsedObject = typeof data === 'string' ? JSON.parse(data) : data;
        
        // التحقق من الهيكل الأمني المشفر المتوافق مع سكريبت الاختبار الخاص بالباكيند
        if (parsedObject.qrPayload || (parsedObject.payload && parsedObject.signature)) {
          setScannedPayload(parsedObject.qrPayload ? parsedObject.qrPayload : parsedObject);
        } else {
          setScannedPayload({ cardId: data });
        }
      } catch (err) {
        // Fallback في حال كانت البيانات نصاً خاماً أو رقماً تسلسلياً عادياً
        setScannedPayload({ cardId: data });
      }
      transitionTo(STATE.CONFIRM);
    }, 150);
  }, [scanLocked, transitionTo]);

  const handleConfirmPayment = async () => {
    setLoading(true);
    setApiError(null);
    transitionTo(STATE.PROCESSING);
    speak('جاري معالجة الدفع، انتظر قليلاً');

    try {
      // تعديل: تأمين تغليف البنية وهيكل الكائن المرسل للسيرفر
      const payloadToSend = {
        qrPayload: scannedPayload,
        amountSDG: parseFloat(amountSDG)
      };
// تعديل: إرسال الكائن المغلف بالكامل مع قيمة المبلغ بصيغة رقمية Float متوافقة مع الباكيند
      // تعديل: إرسال الكائن المغلف بالكامل مع قيمة المبلغ بصيغة رقمية Float متوافقة مع الباكيند
      const res = await processPayment(payloadToSend, parseFloat(amountSDG));
      
      // الإصلاح: تغيير setTxResult إلى setTransaction لإنهاء الخطأ الأول
      setTransaction(res.data.transaction); 
      
      transitionTo(STATE.SUCCESS);
      
      // الإصلاح: تغيير triggerVoice إلى speak لإنهاء الخطأ الثاني
      speak('تمت العملية بنجاح'); 
    }catch (err) {
      const msg = err.response?.data?.message || err.message || 'فشلت معالجة الحركة';
      setApiError(msg);
      transitionTo(STATE.ERROR);
      speak('عذراً، فشلت عملية الدفع');
    } finally {
      setLoading(false);
    }
  };

  const resetFlow = () => {
    setAmountSDG('');
    setScannedPayload(null);
    setTransaction(null);
    setApiError(null);
    setScanLocked(false); // تصفير حالة قفل الكاميرا بنجاح هنا
    transitionTo(STATE.AMOUNT);
  };

  return (
    <SafeAreaView style={styles.container}>
      {!isOnline && <OfflineBanner />}
      
      <View style={styles.header}>
        <Logo size={32} />
        <View style={styles.stepIndicator}>
          <View style={[styles.stepDot, { backgroundColor: STEP_CONFIG[flowState].dot }]} />
          <Text style={styles.stepLabel}>{STEP_CONFIG[flowState].label}</Text>
        </View>
      </View>

      <Animated.View style={[styles.content, { opacity: fadeAnim instanceof Animated.Value ? fadeAnim : 1 }]}>
        
        {flowState === STATE.AMOUNT && (
          <KeyboardAvoidingView
            style={styles.flex}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 64 : 0}
          >
            <ScrollView
              contentContainerStyle={{ gap: Spacing.md, paddingBottom: 24 }}
              keyboardShouldPersistTaps="handled"
              showsVerticalScrollIndicator={false}
            >
              <View style={styles.amountCard}>
                <Text style={styles.amountLabel}>المبلغ المطلوب</Text>
                <AmountDisplay value={amountSDG} />
              </View>
              <Numpad onPress={handleNumpad} />
              <Button
                label="التالي — مسح البطاقة ←"
                onPress={handleAmountReady}
                disabled={parseFloat(amountSDG) <= 0 || !amountSDG}
                style={{ marginTop: Spacing.xs }}
              />
            </ScrollView>
          </KeyboardAvoidingView>
        )}

        {flowState === STATE.SCAN && (
          <View style={styles.scanContainer}>
            <CameraView
              style={StyleSheet.absoluteFillObject}
              onBarcodeScanned={scanLocked ? undefined : handleBarCodeScanned} // تم تعديل اسم الدالة للربط الصحيح وتطبيق الفحص
              barcodeSettings={{ barcodeTypes: ['qr', 'code128', 'pdf417'] }}
            />
            <View style={styles.overlay}>
              <View style={styles.reticle} />
              <Text style={styles.scanInstruction}>وجه الكاميرا نحو رمز QR الخاص بالزبون</Text>
              <TouchableOpacity style={styles.cancelBtn} onPress={() =>{setScanLocked(false); transitionTo(STATE.AMOUNT)}}>
                <Text style={styles.cancelText}>رجوع لتعديل المبلغ</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {flowState === STATE.CONFIRM && (
          <View style={styles.confirmCard}>
            <Text style={styles.confirmTitle}>تأكيد الفاتورة</Text>
            <Divider style={{ marginVertical: Spacing.md }} />
            <View style={styles.receipt}>
              <Text style={styles.receiptLabel}>إجمالي السعر:</Text>
              <Text style={styles.receiptAmount}>{formatCurrency(amountSDG)} SDG</Text>
            </View>
            <Text style={styles.confirmNote}>بإجراء التأكيد, سيتم خصم المبلغ فوراً من محفظة الزبون.</Text>
            <View style={styles.actions}>
              <Button label="إلغاء الحركة" variant="ghost" onPress={resetFlow} style={{ flex: 1 }} />
              <Button label="تأكيد الخصم الآن" variant="primary" onPress={handleConfirmPayment} loading={loading} style={{ flex: 1.5 }} />
            </View>
          </View>
        )}

        {flowState === STATE.PROCESSING && (
          <View style={styles.processingCard}>
            <Text style={styles.processingTitle}>جاري التنفيذ المالي...</Text>
            <Text style={styles.processingNote}>الرجاء عدم إغلاق التطبيق أو فصل الشبكة</Text>
          </View>
        )}

        {flowState === STATE.SUCCESS && (
          <View style={styles.successCard}>
            <View style={styles.successCircle}><Text style={styles.successCheck}>✓</Text></View>
            <Text style={styles.successTitle}>تم الخصم بنجاح</Text>
            <Text style={styles.successNote}>رقم العملية السحابية: {transaction?.id || 'LOCAL_RESERVE'}</Text>
            <Button label="عملية دفع جديدة" variant="outline" onPress={resetFlow} style={{ width: '100%', marginTop: Spacing.md }} />
          </View>
        )}

        {flowState === STATE.ERROR && (
          <View style={styles.errorCard}>
            <View style={styles.errorCircle}><Text style={styles.errorX}>✕</Text></View>
            <Text style={styles.errorTitle}>فشلت العملية</Text>
            <Text style={styles.errorNote}>{apiError}</Text>
            <View style={styles.actions}>
              <Button label="تعديل المبلغ" variant="ghost" onPress={() => {setScanLocked(false); transitionTo(STATE.AMOUNT);}} style={{ flex: 1 }} />
              <Button label="إعادة المحاولة" variant="danger" onPress={handleConfirmPayment} style={{ flex: 1.5 }} />
            </View>
          </View>
        )}

      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.ink, paddingHorizontal: Spacing.md },
  flex: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', height: 60, borderBottomWidth: 1, borderBottomColor: Colors.inkLight },
  stepIndicator: { flexDirection: 'row', alignItems: 'center', gap: Spacing.xs, backgroundColor: Colors.inkLight, paddingHorizontal: Spacing.sm, paddingVertical: 4, borderRadius: Radii.sm },
  stepDot: { width: 6, height: 6, borderRadius: 3 },
  stepLabel: { fontSize: 12, color: Colors.textSecondary, fontWeight: '600' },
  content: { flex: 1, justifyContent: 'center', paddingTop: Spacing.md },

  amountCard: { backgroundColor: Colors.surface, borderRadius: Radii.xl, paddingVertical: Spacing.xl, alignItems: 'center', gap: Spacing.xs, ...Shadow.card },
  amountLabel: { fontSize: 13, color: Colors.textSecondary, fontWeight: '600' },

  scanContainer: { flex: 1, borderRadius: Radii.xxl, overflow: 'hidden', backgroundColor: '#000', marginBottom: Spacing.md },
  overlay: { ...StyleSheet.absoluteFillObject, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.4)' },
  reticle: { width: 220, height: 220, borderWidth: 2, borderColor: Colors.gold, borderRadius: Radii.xl, backgroundColor: 'transparent' },
  scanInstruction: { color: '#fff', fontSize: 14, marginTop: Spacing.xl, fontWeight: '500', backgroundColor: 'rgba(0,0,0,0.6)', paddingHorizontal: Spacing.md, paddingVertical: 6, borderRadius: Radii.md },
  cancelBtn: { marginTop: Spacing.xxl },
  cancelText: { color: Colors.gold, fontWeight: '600', fontSize: 14 },

  confirmCard: { backgroundColor: Colors.surface, borderRadius: Radii.xl, padding: Spacing.xl, ...Shadow.elevated },
  confirmTitle: { fontSize: 18, fontWeight: '800', color: Colors.textPrimary },
  receipt: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginVertical: Spacing.sm },
  receiptLabel: { fontSize: 15, color: Colors.textSecondary },
  receiptAmount: { fontSize: 22, fontWeight: '800', color: Colors.textPrimary },
  confirmNote: { fontSize: 12, color: Colors.textMuted, textAlign: 'center', marginTop: Spacing.md, lineHeight: 18 },
  actions: { flexDirection: 'row', gap: Spacing.sm, marginTop: Spacing.xl, width: '100%' },

  processingCard: { backgroundColor: Colors.surface, borderRadius: Radii.xl, padding: Spacing.xxl, alignItems: 'center', gap: Spacing.md, width: '100%', ...Shadow.elevated },
  processingTitle: { fontSize: 18, fontWeight: '700', color: Colors.textPrimary },
  processingNote:  { fontSize: 13, color: Colors.textMuted },

  successCard:    { backgroundColor: Colors.surface, borderRadius: Radii.xl, padding: Spacing.xl, alignItems: 'center', gap: Spacing.sm, width: '100%', ...Shadow.elevated },
  successCircle:  { width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.leafBg, alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.xs },
  successCheck:   { fontSize: 38, color: Colors.leaf, fontWeight: '800' },
  successTitle:   { fontSize: 24, fontWeight: '800', color: Colors.leaf },
  successNote:    { fontSize: 11, color: Colors.textMuted, marginTop: Spacing.xs },

  errorCard:   { backgroundColor: Colors.surface, borderRadius: Radii.xl, padding: Spacing.xl, alignItems: 'center', gap: Spacing.sm, width: '100%', borderWidth: 1.5, borderColor: Colors.clayBg, ...Shadow.card },
  errorCircle: { width: 80, height: 80, borderRadius: 40, backgroundColor: Colors.clayBg, alignItems: 'center', justifyContent: 'center', marginBottom: Spacing.xs },
  errorX:      { fontSize: 32, color: Colors.clay, fontWeight: '800' },
  errorTitle:  { fontSize: 22, fontWeight: '800', color: Colors.clay },
  errorNote:   { fontSize: 13, color: Colors.textSecondary, textAlign: 'center', paddingHorizontal: Spacing.sm },
});