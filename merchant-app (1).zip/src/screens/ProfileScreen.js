import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  ScrollView,
  Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Colors, Spacing, Radii, Shadow } from '../theme';
import { Button, Divider, OfflineBanner } from '../components/UI';
import { useAuth } from '../context/AuthContext';
import { useNetworkStatus } from '../hooks/useNetworkStatus';
import { getOfflineQueue, syncOfflineQueue } from '../services/api';

export default function ProfileScreen() {
  const { merchant, logout } = useAuth();
  const isOnline = useNetworkStatus(); // هذا هو الاستدعاء الصحيح
  const [offlineCount, setOfflineCount] = useState(0);
  const [syncing, setSyncing] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(true);

  useEffect(() => {
    (async () => {
      const queue = await getOfflineQueue();
      setOfflineCount(queue.length);
    })();
  }, []);

  const handleSync = async () => {
    if (!isOnline) {
      Alert.alert('لا يوجد اتصال', 'تحقق من الاتصال بالإنترنت ثم حاول مجدداً');
      return;
    }

    setSyncing(true);
    try {
      const results = await syncOfflineQueue();
      const succeeded = results.filter((r) => r.success).length;
      const failed = results.filter((r) => !r.success).length;
      setOfflineCount(failed);
      Alert.alert('مزامنة المعاملات', `تمت: ${succeeded} | فشلت: ${failed}`);
    } catch {
      Alert.alert('خطأ', 'فشلت المزامنة');
    } finally {
      setSyncing(false);
    }
  };

  const handleLogout = () => {
    Alert.alert(
      'تسجيل الخروج',
      'هل أنت متأكد من رغبتك في تسجيل الخروج؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        { 
          text: 'خروج', 
          style: 'destructive', 
          onPress: () => {
            if (offlineCount > 0) {
              // تأخير بسيط لعرض التنبيه الآخر بعد إغلاق التنبيه الحالي تماماً
              setTimeout(() => {
                Alert.alert('تنبيه', 'لديك حركات معلقة بالأوفلاين، يرجى مزامنتها أولاً قبل الخروج');
              }, 100);
              return;
            }
            
            // الحل السحري: تأخير استدعاء logout حتى يغلق الأندرويد نافذة الـ Alert تماماً من الشاشة
            setTimeout(async () => {
              try {
                await logout();
              } catch (err) {
                Alert.alert('خطأ', 'فشل تسجيل الخروج، يرجى المحاولة مرة أخرى');
              }
            }, 150);
          } 
        }
      ]
    );
  };

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      {!isOnline && <OfflineBanner queueCount={offlineCount} />}

      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.screenTitle}>الحساب</Text>

        {/* Merchant info */}
        <View style={styles.merchantCard}>
          <View style={styles.avatarRing}>
            <Text style={styles.avatarText}>
              {merchant?.businessName?.charAt(0) || 'م'}
            </Text>
          </View>
          <View style={styles.merchantInfo}>
            <Text style={styles.merchantName}>{merchant?.businessName}</Text>
            <Text style={styles.merchantPhone}>{merchant?.phone}</Text>
          </View>
          <View style={styles.activeBadge}>
            <Text style={styles.activeBadgeText}>نشط</Text>
          </View>
        </View>

        <Divider />

        {/* Offline queue */}
        {offlineCount > 0 && (
          <>
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>معاملات معلقة</Text>
              <View style={styles.offlineCard}>
                <View>
                  <Text style={styles.offlineCount}>{offlineCount}</Text>
                  <Text style={styles.offlineLabel}>معاملة تنتظر المزامنة</Text>
                </View>
                <Button
                  label={syncing ? 'جاري المزامنة...' : 'مزامنة الآن'}
                  onPress={handleSync}
                  loading={syncing}
                  style={{ paddingHorizontal: Spacing.md }}
                />
              </View>
            </View>
            <Divider />
          </>
        )}

        {/* Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>الإعدادات</Text>

          <View style={styles.settingRow}>
            <View>
              <Text style={styles.settingLabel}>التأكيد الصوتي</Text>
              <Text style={styles.settingDesc}>نطق المبلغ بعد كل عملية دفع</Text>
            </View>
            <Switch
              value={voiceEnabled}
              onValueChange={setVoiceEnabled}
              trackColor={{ false: Colors.border, true: Colors.goldPale }}
              thumbColor={voiceEnabled ? Colors.gold : Colors.textMuted}
            />
          </View>
        </View>

        <Divider />

        {/* System info */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>عن النظام</Text>
          <InfoRow label="الإصدار" value="1.0.0" />
          <InfoRow label="حالة الاتصال" value={isOnline ? '🟢 متصل' : '🔴 غير متصل'} />
          <InfoRow label="المعرف" value={merchant?.id?.slice(-8) || '—'} mono />
        </View>

        <View style={styles.logoutArea}>
          <Button
            label="تسجيل الخروج"
            variant="danger"
            onPress={handleLogout}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function InfoRow({ label, value, mono }) {
  return (
    <View style={styles.infoRow}>
      <Text style={styles.infoLabel}>{label}</Text>
      <Text style={[styles.infoValue, mono && styles.infoValueMono]}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: Colors.canvas },
  scroll: { padding: Spacing.lg, gap: Spacing.md },
  screenTitle: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.textPrimary,
    marginBottom: Spacing.sm,
  },

  // Merchant card
  merchantCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    flexDirection: 'row',
    alignItems: 'center',
    gap: Spacing.md,
    ...Shadow.card,
  },
  avatarRing: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: Colors.goldPale,
    borderWidth: 2,
    borderColor: Colors.gold,
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarText: {
    fontSize: 22,
    fontWeight: '700',
    color: Colors.gold,
  },
  merchantInfo: { flex: 1 },
  merchantName: {
    fontSize: 16,
    fontWeight: '700',
    color: Colors.textPrimary,
  },
  merchantPhone: {
    fontSize: 13,
    color: Colors.textSecondary,
    marginTop: 2,
  },
  activeBadge: {
    backgroundColor: Colors.leafBg,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: Radii.full,
  },
  activeBadgeText: {
    fontSize: 12,
    fontWeight: '600',
    color: Colors.leaf,
  },

  // Section
  section: { gap: Spacing.sm },
  sectionTitle: {
    fontSize: 11,
    fontWeight: '700',
    color: Colors.textMuted,
    letterSpacing: 0.9,
    textTransform: 'uppercase',
    marginBottom: 4,
  },

  // Offline card
  offlineCard: {
    backgroundColor: Colors.amberBg,
    borderRadius: Radii.md,
    padding: Spacing.md,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: Colors.amber,
  },
  offlineCount: {
    fontSize: 28,
    fontWeight: '700',
    color: Colors.amber,
  },
  offlineLabel: {
    fontSize: 12,
    color: Colors.amber,
  },

  // Setting row
  settingRow: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.md,
    padding: Spacing.md,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    ...Shadow.card,
  },
  settingLabel: {
    fontSize: 15,
    fontWeight: '600',
    color: Colors.textPrimary,
  },
  settingDesc: {
    fontSize: 12,
    color: Colors.textMuted,
    marginTop: 2,
  },

  // Info rows
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
  },
  infoLabel: {
    fontSize: 14,
    color: Colors.textSecondary,
  },
  infoValue: {
    fontSize: 14,
    fontWeight: '500',
    color: Colors.textPrimary,
  },
  infoValueMono: {
    fontFamily: 'Courier New',
    fontSize: 12,
    color: Colors.textMuted,
  },

  logoutArea: { paddingTop: Spacing.md },
});
