import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

const BASE_URL = 'https://ebmsovereign.com/api/v1';
const OFFLINE_QUEUE_KEY = 'offline_payments_queue';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 20000,
  headers: { 'Content-Type': 'application/json' },
});

// إرفاق الـ JWT تلقائياً مع كل طلب بشكل آمن ومحمي
api.interceptors.request.use(async (config) => {
  try {
    let token = null;
    if (Platform.OS === 'web') {
      token = localStorage.getItem('auth_token');
    } else {
      try {
        token = await SecureStore.getItemAsync('auth_token');
      } catch (e) {
        token = await AsyncStorage.getItem('auth_token');
      }
    }
    if (token) config.headers.Authorization = `Bearer ${token}`;
  } catch (err) {
    console.log('Interceptor storage fallback error');
  }
  return config;
});

// معالجة الخطأ 401 عالمياً لتنظيف جلسة العمل دون انهيار النظام
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    if (error.response?.status === 401) {
      if (Platform.OS === 'web') {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('merchant_data');
      } else {
        try {
          await SecureStore.deleteItemAsync('auth_token');
          await SecureStore.deleteItemAsync('merchant_data');
        } catch (e) {
          await AsyncStorage.removeItem('auth_token');
          await AsyncStorage.removeItem('merchant_data');
        }
      }
    }
    return Promise.reject(error);
  }
);

/* ── Auth ────────────────────────────────────────────────────────── */

export async function login(phone, password) {
  try {
    let cleanPhone = phone ? phone.trim() : '';
    
    // تطهير رقم الهاتف من أي تكرار لرمز الدولة لمنع أخطاء الـ 404
    if (cleanPhone.startsWith('+249')) {
      const remaining = cleanPhone.slice(4);
      if (remaining.startsWith('+249') || remaining.startsWith('249')) {
        cleanPhone = remaining.startsWith('+249') ? remaining : '+' + remaining;
      }
    } else if (cleanPhone.startsWith('249')) {
      const remaining = cleanPhone.slice(3);
      if (remaining.startsWith('+249') || remaining.startsWith('249')) {
        cleanPhone = remaining.startsWith('+249') ? remaining : '+249' + remaining;
      } else {
        cleanPhone = '+' + cleanPhone;
      }
    }

    const res = await api.post('/auth/login', { phone: cleanPhone, password });
    const { token, merchant } = res.data;
    
    if (Platform.OS === 'web') {
      localStorage.setItem('auth_token', token);
      localStorage.setItem('merchant_data', JSON.stringify(merchant));
    } else {
      try {
        await AsyncStorage.setItem('auth_token', token);
        await AsyncStorage.setItem('merchant_data', JSON.stringify(merchant));
        await SecureStore.setItemAsync('auth_token', token);
        await SecureStore.setItemAsync('merchant_data', JSON.stringify(merchant));
      } catch (storeErr) {
        console.warn('SecureStore safe bypass applied:', storeErr.message);
      }
    }
    
    return merchant;
  } catch (err) {
    throw err;
  }
}

export async function logout() {
  if (Platform.OS === 'web') {
    localStorage.removeItem('auth_token');
    localStorage.removeItem('merchant_data');
  } else {
    try { await SecureStore.deleteItemAsync('auth_token'); } catch(e){}
    try { await SecureStore.deleteItemAsync('merchant_data'); } catch(e){}
    try { await AsyncStorage.removeItem('auth_token'); } catch(e){}
    try { await AsyncStorage.removeItem('merchant_data'); } catch(e){}
  }
}

/* ── Storage Helpers ────────────────────────────────────────────── */
export async function getStoredMerchant() {
  try {
    if (Platform.OS === 'web') {
      const raw = localStorage.getItem('merchant_data');
      return raw ? JSON.parse(raw) : null;
    } else {
      let raw = null;
      try {
        raw = await SecureStore.getItemAsync('merchant_data');
      } catch (e) {
        raw = await AsyncStorage.getItem('merchant_data');
      }
      return raw ? JSON.parse(raw) : null;
    }
  } catch (err) {
    return null;
  }
}

async function getCardsKey() {
  const merchant = await getStoredMerchant();
  return merchant ? `linked_cards_${merchant.merchantId || merchant.id}` : 'linked_cards_anonymous';
}

/* ── عمليات الدفع والشحن المحدثة بالكامل طبقاً للسيرفر ────────────────── */

export async function processTopUp(cardId, amountSDG) {
  const res = await api.post('/payments/top-up', {
    cardId: String(cardId),
    amountSDG: parseFloat(amountSDG)
  });
  return res.data; 
}

export async function processPayment(qrPayload, amountSDG) {
  const stringifiedPayload = typeof qrPayload === 'object' ? JSON.stringify(qrPayload) : qrPayload;
  const res = await api.post('/payments/pay', {
    qrPayload: stringifiedPayload,
    amountSDG: parseFloat(amountSDG)
  });
  return res.data;
}

export async function verifyCard(cardId) {
  const cleanId = typeof cardId === 'object' ? (cardId.cardId || cardId.cid) : cardId;
  const res = await api.get(`/cards/${cleanId}`);
  return res.data.card; 
}

/* ── إدارة ربط البطاقات محلياً في ذاكرة الهاتف لتجنب أخطاء 404 ── */

export async function getLinkedCards() {
  try {
    const key = await getCardsKey();
    const raw = await AsyncStorage.getItem(key);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error('Error fetching linked cards:', err);
    return [];
  }
}

export async function addLinkedCard(card) {
  const key = await getCardsKey();
  const cards = await getLinkedCards();
  if (cards.some(c => c.cardId === card.cardId)) return cards;
  const updated = [...cards, { ...card, linkedAt: new Date().toISOString() }];
  await AsyncStorage.setItem(key, JSON.stringify(updated));
  return updated;
}

export async function removeLinkedCard(cardId) {
  const key = await getCardsKey();
  const cards = await getLinkedCards();
  const updated = cards.filter(c => c.cardId !== cardId);
  await AsyncStorage.setItem(key, JSON.stringify(updated));
  return updated;
}

/* ── طابور عمليات الأوفلاين ──────────────────────────────────────── */
export async function getOfflineQueue() {
  try {
    const raw = await AsyncStorage.getItem(OFFLINE_QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    return [];
  }
}

export async function queueOfflinePayment(payment) {
  const queue = await getOfflineQueue();
  const newPayment = {
    ...payment,
    id: Date.now().toString(),
    queuedAt: new Date().toISOString(),
  };
  queue.push(newPayment);
  await AsyncStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(queue));
  return queue;
}

export async function syncOfflineQueue(onProgress) {
  const queue = await getOfflineQueue();
  const results = [];
  if (queue.length === 0) return results;

  for (let i = 0; i < queue.length; i++) {
    const payment = queue[i];
    try {
      const res = await processPayment(payment.qrPayload, payment.amountSDG);
      results.push({ success: true, payment, data: res });
    } catch (err) {
      results.push({ success: false, payment, error: err.message });
    }
    if (onProgress) onProgress(results.length, queue.length);
  }

  const failedPayments = queue.filter((_, idx) => !results[idx].success);
  await AsyncStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(failedPayments));
  return results;
}
