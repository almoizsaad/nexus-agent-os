# دليل البناء والنشر الكامل
# Sudan Payment System — Full Stack Guide

---

## هيكل المشروع بالكامل

```
sudan-payment-system/        ← النظام المركزي (Backend)
├── src/
│   ├── config/
│   │   ├── index.js         ← تحميل وتحقق متغيرات البيئة
│   │   ├── database.js      ← اتصال MongoDB
│   │   └── logger.js        ← Winston logger
│   ├── models/
│   │   ├── Card.js          ← نموذج البطاقة (رصيد، حالة، توقيع)
│   │   ├── Transaction.js   ← سجل المعاملات (immutable ledger)
│   │   └── Merchant.js      ← نموذج التاجر (auth، إحصائيات)
│   ├── services/
│   │   ├── transactionEngine.js  ← محرك المعاملات (atomic)
│   │   ├── cardService.js        ← إصدار البطاقات، QR، lifecycle
│   │   ├── cryptoService.js      ← HMAC signing، تحقق QR
│   │   └── fraudService.js       ← كشف الاحتيال
│   ├── routes/
│   │   ├── auth.js          ← تسجيل دخول التاجر
│   │   ├── payments.js      ← دفع، شحن، استرجاع، سجل
│   │   ├── cards.js         ← تحقق QR، lifecycle البطاقة
│   │   ├── analytics.js     ← تقارير (admin)
│   │   └── admin.js         ← إدارة التجار (admin)
│   ├── middleware/
│   │   ├── auth.js          ← JWT، مفتاح Admin
│   │   ├── validate.js      ← Joi schema validation
│   │   └── errorHandler.js  ← معالجة موحدة للأخطاء
│   ├── app.js               ← Express app factory
│   └── server.js            ← نقطة البداية
├── tests/                   ← 25 اختبار (جميعها تنجح)
├── scripts/seed.js          ← بيانات تجريبية
└── .env.example

merchant-app/               ← تطبيق التاجر (React Native / Expo)
├── App.js                  ← نقطة البداية
├── src/
│   ├── screens/
│   │   ├── PaymentScreen.js  ← شاشة الدفع الرئيسية (QR خلفي)
│   │   ├── HistoryScreen.js  ← سجل المعاملات
│   │   ├── TopUpScreen.js    ← شحن البطاقات
│   │   └── LoginScreen.js    ← تسجيل الدخول
│   ├── services/api.js       ← HTTP client + offline queue
│   ├── hooks/
│   │   ├── useQRScanner.js   ← كاميرا خلفية بلا واجهة
│   │   ├── useVoiceFeedback.js ← نطق المبلغ بالعربية
│   │   └── useNetworkStatus.js ← مراقبة الاتصال
│   ├── context/AuthContext.js ← إدارة حالة تسجيل الدخول
│   ├── components/UI.js      ← مكونات مشتركة
│   ├── navigation/AppNavigator.js ← التنقل
│   └── theme/index.js        ← ألوان، خطوط، spacing
└── COLAB_SETUP.ipynb        ← دفتر التشغيل الكامل
```

---

## تقنية الكاميرا الخلفية (المزة الأساسية)

### المشكلة التقليدية
في أغلب تطبيقات الدفع:
1. التاجر يضغط "مسح"
2. تنفتح واجهة الكاميرا
3. يوجّه الكاميرا نحو البطاقة
4. يتم المسح

**هذا بطيء ويُضيّع وقت العملاء.**

### الحل المُطبّق (Apple Pay style)

```
PaymentScreen.js يستخدم:
┌─────────────────────────────────────────┐
│  hiddenCamera — View بدون opacity       │
│  position: absolute, zIndex: 0          │
│  opacity: 0  ← لا يُرى                  │
│  pointerEvents: 'none' ← لا يُلمس       │
│                                         │
│  Camera مُشغّلة دائماً خلف الواجهة       │
│  onBarCodeScanned تعمل في الخلفية        │
└─────────────────────────────────────────┘
```

**النتيجة:** عندما يقرّب التاجر البطاقة من الهاتف، يُمسح QR فوراً وتبدأ العملية. لا ضغط، لا فتح كاميرا.

---

## تدفق الدفع الكامل (End-to-End)

```
التاجر يفتح شاشة الدفع
         ↓
الكاميرا تبدأ في الخلفية (opacity: 0)
         ↓
التاجر يقرّب بطاقة العميل من الهاتف
         ↓
Camera.onBarCodeScanned ← يستقبل البيانات
         ↓
التحقق من JSON structure { cid, sig }
         ↓
HMAC verify ← تحقق من صحة التوقيع
         ↓
GET /cards/verify ← التحقق من الرصيد والحالة
         ↓
يظهر: رصيد البطاقة + لوحة أرقام
         ↓
التاجر يدخل المبلغ
         ↓
POST /payments/pay { qrPayload, amountSDG, idempotencyKey }
         ↓
Backend: fraud check → MongoDB transaction → balance debit → ledger entry
         ↓
صوت: "تم استلام X جنيه" + اهتزاز + شاشة نجاح
```

---

## تشغيل على Google Colab

### خطوة 1: افتح الـ Notebook
- ارفع `COLAB_SETUP.ipynb` على Google Colab
- شغّل الخلايا بالترتيب (Shift+Enter)

### خطوة 2: ارفع ملفات المشروع
```python
# في Colab:
from google.colab import files
files.upload()  # ارفع sudan-payment-system.zip
```

### خطوة 3: احصل على رابط ngrok
بعد تشغيل Cell 9، ستحصل على رابط مثل:
```
🌐 Public API URL: https://abc123.ngrok.io/api/v1
```

### خطوة 4: ضبط التطبيق
في ملف `merchant-app/src/services/api.js`:
```javascript
const BASE_URL = 'https://abc123.ngrok.io/api/v1';
```

### خطوة 5: تشغيل التطبيق
```bash
cd merchant-app
npm install
npx expo start --tunnel
```
- امسح QR Expo بتطبيق **Expo Go** من هاتفك

---

## تشغيل على Google Cloud Shell

```bash
# 1. افتح Cloud Shell من console.cloud.google.com

# 2. ثبّت Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt-get install -y nodejs

# 3. ثبّت MongoDB
wget -qO - https://www.mongodb.org/static/pgp/server-7.0.asc | sudo apt-key add -
echo "deb [ arch=amd64,arm64 ] https://repo.mongodb.org/apt/ubuntu jammy/mongodb-org/7.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list
sudo apt-get update && sudo apt-get install -y mongodb-org

# 4. شغّل MongoDB مع Replica Set
sudo mkdir -p /data/db
sudo mongod --replSet rs0 --fork --logpath /var/log/mongod.log
sleep 3
mongosh --eval "rs.initiate()"

# 5. ارفع ملفاتك (أو انسخها)
# gcloud storage cp gs://your-bucket/sudan-payment-system.zip .
unzip sudan-payment-system.zip
cd sudan-payment-system

# 6. اضبط البيئة
cp .env.example .env
# عدّل .env بقيم حقيقية

# 7. ثبّت وشغّل
npm install
npm start

# 8. استخدم Web Preview على منفذ 3000
# في Cloud Shell اضغط Web Preview > Preview on port 3000
```

---

## اختبار End-to-End يدوياً

### أ. تسجيل تاجر جديد
```bash
curl -X POST http://localhost:3000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "businessName": "متجر الأمل",
    "ownerName": "أحمد علي",
    "phone": "+249123456789",
    "password": "mypassword123",
    "city": "الخرطوم"
  }'
```

### ب. تفعيل التاجر (admin)
```bash
# استبدل MERCHANT_ID بالـ ID من الخطوة السابقة
# استبدل ADMIN_KEY بمفتاحك من .env
curl -X PATCH http://localhost:3000/api/v1/admin/merchants/MERCHANT_ID/activate \
  -H "X-Admin-Api-Key: ADMIN_KEY"
```

### ج. تسجيل الدخول
```bash
curl -X POST http://localhost:3000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{"phone": "+249123456789", "password": "mypassword123"}'
# احفظ الـ token من الرد
```

### د. إصدار دفعة بطاقات
```bash
curl -X POST http://localhost:3000/api/v1/cards/batch \
  -H "X-Admin-Api-Key: ADMIN_KEY" \
  -H "Content-Type: application/json" \
  -d '{"count": 5, "batchId": "TEST-001"}'
```

### هـ. شحن بطاقة
```bash
curl -X POST http://localhost:3000/api/v1/payments/top-up \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"cardId": "CARD-...", "amountSDG": 500}'
```

### و. الدفع (يتطلب QR payload من التطبيق)
```bash
curl -X POST http://localhost:3000/api/v1/payments/pay \
  -H "Authorization: Bearer TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "qrPayload": "{\"cid\":\"CARD-...\",\"sig\":\"...\"}",
    "amountSDG": 100,
    "idempotencyKey": "550e8400-e29b-41d4-a716-446655440000"
  }'
```

---

## متطلبات الإنتاج

| الجزء | التوصية |
|-------|---------|
| MongoDB | Atlas M10 + Replica Set |
| Backend | Railway / Render / AWS EC2 |
| SSL/TLS | Cloudflare أو Let's Encrypt |
| Process Manager | PM2 أو Docker |
| Logs | Datadog / CloudWatch |
| App Distribution | Expo EAS Build (apk/ipa) |

---

## الأمان — ملاحظات مهمة للإنتاج

1. **CARD_SIGNING_SECRET** لا تشاركه أبداً — من يملكه يستطيع إنشاء بطاقات مزورة
2. **JWT_SECRET** غيّره إذا اعتقدت أنه تسرّب — كل الجلسات ستُلغى
3. **ADMIN_API_KEY** استخدم نظام أكثر تطوراً في الإنتاج (OAuth2 للمدراء)
4. **HTTPS** إلزامي — بدونه يمكن سرقة الـ JWT من الشبكة
5. **Rate Limiting** اضبط `RATE_LIMIT_MAX_REQUESTS` حسب حجم التجار
