# بناء تطبيق نقطة دفع عبر expo.dev و Cloud Shell
# NuqtaPay Merchant App — Build Guide

## نظرة عامة

الباكيند يعمل على: http://166.88.117.23:3000/api/v1

البناء يتم عبر خدمة **EAS Build** من Expo — لا تحتاج Android Studio ولا Mac.
النتيجة: ملف APK جاهز للتنزيل والتثبيت مباشرة على أي هاتف Android.

---

## الخطوة 1 — تجهيز Cloud Shell

```bash
# تثبيت Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo bash -
sudo apt-get install -y nodejs
node --version   # يجب: v20.x.x
```

```bash
# رفع الملف عبر Cloud Shell → More (⋮) → Upload
# ثم:
cd ~
unzip merchant-app-v1.1.zip
cd merchant-app
```

```bash
# تثبيت المكتبات
npm install
```

---

## الخطوة 2 — إنشاء حساب Expo

1. اذهب إلى https://expo.dev
2. اضغط **Sign Up** → أنشئ حساباً مجانياً
3. تذكّر: **username** و **email**

---

## الخطوة 3 — تسجيل الدخول في Cloud Shell

```bash
# تثبيت EAS CLI
npm install -g eas-cli

# تسجيل الدخول
eas login
# أدخل: username وكلمة المرور
```

---

## الخطوة 4 — ربط المشروع بـ Expo

```bash
cd ~/merchant-app

# ربط المشروع (مرة واحدة فقط)
eas init
# اختر: Create a new project
# اسم المشروع: nuqtapay-merchant
```

سيُنشئ هذا الأمر `projectId` في ملف `app.json` تلقائياً.

---

## الخطوة 5 — بناء ملف APK

```bash
cd ~/merchant-app

# بناء APK مباشر (الأسرع — لا يحتاج Google Play)
eas build --platform android --profile apk
```

**ستظهر الأسئلة التالية:**
- `Generate a new Android Keystore?` → اضغط **Y** (مرة واحدة فقط)

**وقت البناء:** 5-15 دقيقة على خوادم Expo.

---

## الخطوة 6 — تنزيل APK

بعد انتهاء البناء:
```bash
# سيظهر رابط مباشر مثل:
# https://expo.dev/artifacts/eas/XXXXXXXX.apk

# أو اذهب إلى:
# https://expo.dev/accounts/YOUR_USERNAME/projects/nuqtapay-merchant/builds
```

انسخ الرابط وافتحه من هاتفك مباشرة لتنزيل APK وتثبيته.

---

## بدائل البناء

### خيار أ — APK للاختبار الداخلي (الأسرع)
```bash
eas build --platform android --profile apk
```

### خيار ب — APK مع تتبع نشرات التحديث
```bash
eas build --platform android --profile preview
```

### خيار ج — App Bundle لـ Google Play (للنشر العام)
```bash
eas build --platform android --profile production
```

---

## اختبار الاتصال بالباكيند قبل البناء

```bash
curl http://166.88.117.23:3000/health
# يجب أن يُعيد: {"success":true,"status":"ok",...}
```

---

## هيكل ملفات التطبيق

```
merchant-app/
├── App.js                          ← نقطة الدخول
├── app.json                        ← إعدادات Expo
├── eas.json                        ← أوضاع البناء
├── package.json
├── babel.config.js
└── src/
    ├── screens/
    │   ├── LoginScreen.js          ← تسجيل الدخول + رابط التسجيل
    │   ├── RegisterScreen.js       ← إنشاء حساب تاجر جديد
    │   ├── PaymentScreen.js        ← الدفع (كاميرا خلفية)
    │   ├── TopUpScreen.js          ← شحن البطاقات
    │   ├── HistoryScreen.js        ← سجل المعاملات
    │   └── ProfileScreen.js        ← الحساب والإعدادات
    ├── components/
    │   ├── Logo.js                 ← شعار نقطة دفع
    │   └── UI.js                   ← مكونات مشتركة
    ├── services/api.js             ← HTTP client → 166.88.117.23
    ├── hooks/
    │   ├── useQRScanner.js         ← كاميرا خلفية بلا واجهة
    │   ├── useVoiceFeedback.js     ← نطق المبلغ بالعربية
    │   └── useNetworkStatus.js     ← مراقبة الاتصال
    ├── context/AuthContext.js      ← حالة تسجيل الدخول
    ├── navigation/AppNavigator.js  ← مسارات التنقل
    └── theme/index.js              ← ألوان وهوية نقطة دفع
```

---

## تدفق الدفع (ذاكرة سريعة)

```
[التاجر يدخل المبلغ]
        ↓
[اضغط "التالي — مسح البطاقة"]
        ↓
[الكاميرا تعمل في الخلفية بصمت]
        ↓
[العميل يقرّب البطاقة من الهاتف]
        ↓
[اهتزاز + ورقة تأكيد تظهر تلقائياً]
        ↓
[التاجر يضغط "استلام ✓"]
        ↓
[صوت عربي: "تم استلام X جنيه" + شاشة نجاح]
```

---

## الشحن اليدوي (Top-Up)

```
[أدخل الرقم التسلسلي المطبوع على البطاقة]
مثال: CLOUD-SHELL-001-000001
أو:   CARD-6F93FADD-141C-4A0C-9FF1-798BF3D4ABC7
        ↓
[أدخل المبلغ بلوحة الأرقام]
        ↓
[اضغط "شحن X SDG"]
        ↓
[شاشة نجاح مع الرصيد الجديد]
```

---

## ملاحظات أمنية

- الـ JWT يُخزَّن في `SecureStore` (مُشفَّر بمفتاح الجهاز)
- عند انتهاء الجلسة، يُعاد التوجيه لشاشة الدخول تلقائياً
- المعاملات المُخزَّنة أوفلاين تُرسَل بـ idempotency key لمنع التكرار
- رمز QR يُتحقق منه بـ HMAC-SHA256 على الخادم — لا يمكن تزويره
