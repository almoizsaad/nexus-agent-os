import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors, Radii } from '../theme';

/**
 * شعار نقطة دفع
 * رمز هندسي: نقطة ذهبية داخل دائرة — يُجسّد "نقطة" البيع
 * بسيط، قابل للطباعة، يعمل على خلفيات داكنة وفاتحة
 */
export function Logo({ size = 48, variant = 'dark' }) {
  const isLight = variant === 'light';
  const dotSize = size * 0.28;

  return (
    <View style={[styles.wrap, {
      width: size,
      height: size,
      borderRadius: size * 0.26,
      backgroundColor: isLight ? Colors.surface : Colors.gold,
    }]}>
      {/* النقطة المركزية */}
      <View style={[styles.dot, {
        width: dotSize,
        height: dotSize,
        borderRadius: dotSize / 2,
        backgroundColor: isLight ? Colors.gold : Colors.ink,
      }]} />
      {/* حلقة خارجية */}
      <View style={[styles.ring, {
        width: size * 0.58,
        height: size * 0.58,
        borderRadius: size * 0.29,
        borderColor: isLight ? Colors.gold : Colors.ink,
        borderWidth: size * 0.04,
      }]} />
    </View>
  );
}

export function LogoWithText({ size = 40, variant = 'dark' }) {
  const isLight = variant === 'light';
  return (
    <View style={styles.logoRow}>
      <Logo size={size} variant={variant} />
      <View style={styles.textBlock}>
        <Text style={[styles.name, {
          color: isLight ? Colors.textInvert : Colors.textPrimary,
          fontSize: size * 0.42,
        }]}>
          نقطة دفع
        </Text>
        <Text style={[styles.tagline, {
          color: isLight ? 'rgba(255,255,255,0.6)' : Colors.textMuted,
          fontSize: size * 0.26,
        }]}>
          NuqtaPay
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  dot: {
    position: 'absolute',
    zIndex: 2,
  },
  ring: {
    position: 'absolute',
    backgroundColor: 'transparent',
  },
  logoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  textBlock: { gap: 1 },
  name: {
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  tagline: {
    fontWeight: '500',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
});
