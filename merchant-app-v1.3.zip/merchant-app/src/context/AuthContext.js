import React, { createContext, useContext, useState, useEffect } from 'react';
import { getStoredMerchant, logout as apiLogout } from '../services/api';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [merchant, setMerchant] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const stored = await getStoredMerchant();
      setMerchant(stored);
      setLoading(false);
    })();
  }, []);

  const login = (merchantData) => setMerchant(merchantData);

  const logout = async () => {
    await apiLogout();
    setMerchant(null);
  };

  return (
    <AuthContext.Provider value={{ merchant, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
