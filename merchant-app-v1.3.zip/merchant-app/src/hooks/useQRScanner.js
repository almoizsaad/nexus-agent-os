import { useState, useRef, useCallback, useEffect } from 'react';
import { useCameraPermissions } from 'expo-camera';
import * as Haptics from 'expo-haptics';

/**
 * Manages background QR scanning using expo-camera v14+ (CameraView).
 *
 * The hook provides:
 *  - permission state and request function
 *  - a stable onBarcodeScanned handler with deduplication and cooldown
 *  - a reset function to allow re-scanning
 *
 * The CameraView itself should be rendered invisible (opacity:0) by the
 * consuming screen so the camera runs silently without showing a viewfinder.
 */
export function useQRScanner({ onScan, enabled = true }) {
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned]           = useState(false);
  const lastDataRef  = useRef(null);
  const cooldownRef  = useRef(null);

  useEffect(() => {
    return () => { if (cooldownRef.current) clearTimeout(cooldownRef.current); };
  }, []);

  const resetScanner = useCallback((delayMs = 3000) => {
    if (cooldownRef.current) clearTimeout(cooldownRef.current);
    cooldownRef.current = setTimeout(() => {
      setScanned(false);
      lastDataRef.current = null;
    }, delayMs);
  }, []);

  // expo-camera v14+ calls this as onBarcodeScanned({ type, data, ... })
  const handleBarcodeScanned = useCallback(({ data }) => {
    if (!enabled || scanned) return;
    if (data === lastDataRef.current) return; // same payload within cooldown

    // Validate it's our payment QR before firing
    try {
      const parsed = JSON.parse(data);
      if (!parsed.cid || !parsed.sig) return;
    } catch { return; }

    lastDataRef.current = data;
    setScanned(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    onScan(data);
  }, [enabled, scanned, onScan]);

  return {
    hasPermission:       permission?.granted ?? false,
    permissionStatus:    permission?.status,
    requestPermission,
    scanned,
    handleBarcodeScanned,
    resetScanner,
  };
}
