import { useCallback } from 'react';
import { Audio } from 'expo-av';
import * as Speech from 'expo-speech';

/**
 * Speaks the payment amount aloud in Arabic after a successful transaction.
 * Falls back to a beep tone if speech is unavailable.
 *
 * In production, swap Speech.speak() with a pre-recorded WAV file for
 * consistent pronunciation in Sudanese Arabic dialect.
 */
export function useVoiceFeedback() {
  const announceSuccess = useCallback(async (amountSDG) => {
    const formatted = formatAmountArabic(amountSDG);
    const text = `تم استلام ${formatted}`;

    try {
      await Speech.speak(text, {
        language: 'ar-SA',
        rate: 0.9,
        pitch: 1.0,
      });
    } catch {
      // Speech unavailable — silent fail, haptics already fired
    }
  }, []);

  const announceError = useCallback(async (reason) => {
    try {
      await Speech.speak(reason || 'فشلت العملية', {
        language: 'ar-SA',
        rate: 0.9,
      });
    } catch {
      // silent
    }
  }, []);

  return { announceSuccess, announceError };
}

// Converts 1500 → "ألف وخمسمائة جنيه"
// Simplified version — extend with full Arabic numeral rules for production
function formatAmountArabic(amount) {
  const sdg = Math.floor(amount);
  const qirsh = Math.round((amount - sdg) * 100);

  let text = '';
  if (sdg > 0) text += `${sdg} جنيه`;
  if (qirsh > 0) text += ` و${qirsh} قرش`;
  return text || 'صفر';
}
