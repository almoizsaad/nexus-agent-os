import { MaterialCommunityIcons } from "@expo/vector-icons";
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Colors, Shadow } from '../theme';

import LoginScreen    from '../screens/LoginScreen';
import RegisterScreen from '../screens/RegisterScreen';
import PaymentScreen  from '../screens/PaymentScreen';
import WalletScreen   from '../screens/WalletScreen';
import CardsScreen    from '../screens/CardsScreen';
import TopUpScreen    from '../screens/TopUpScreen';
import HistoryScreen  from '../screens/HistoryScreen';
import ProfileScreen  from '../screens/ProfileScreen';
import { useAuth }    from '../context/AuthContext';

const Stack = createNativeStackNavigator();
const Tab   = createBottomTabNavigator();

/**
 * Tab definition.
 * WalletScreen replaces the old standalone profile-wallet approach —
 * it is its own first-class tab so the merchant always has their balance
 * one tap away.
 */
const TABS = [
  { name: 'Payment', component: PaymentScreen, icon: 'qrcode-scan',            label: 'دفع'      },
  { name: 'Wallet',  component: WalletScreen,  icon: 'wallet',                  label: 'محفظتي'   },
  { name: 'Cards',   component: CardsScreen,   icon: 'credit-card-multiple',    label: 'بطاقاتي'  },
  { name: 'TopUp',   component: TopUpScreen,   icon: 'cash-plus',               label: 'شحن'      },
  { name: 'History', component: HistoryScreen,  icon: 'history',                 label: 'السجل'    },
  { name: 'Profile', component: ProfileScreen,  icon: 'account-circle-outline',  label: 'الحساب'   },
];

function TabIcon({ icon, label, focused }) {
  return (
    <View style={tab.item}>
      <MaterialCommunityIcons
        name={icon}
        size={23}
        color={focused ? Colors.gold : Colors.textMuted}
      />
      <Text style={[tab.label, focused && tab.labelActive]}>{label}</Text>
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={{
        headerShown:        false,
        tabBarStyle:        tab.bar,
        tabBarShowLabel:    false,
        tabBarHideOnKeyboard: true,
      }}
    >
      {TABS.map(({ name, component, icon, label }) => (
        <Tab.Screen
          key={name}
          name={name}
          component={component}
          options={{
            tabBarIcon: ({ focused }) => (
              <TabIcon icon={icon} label={label} focused={focused} />
            ),
          }}
        />
      ))}
    </Tab.Navigator>
  );
}

function AuthStack() {
  return (
    <Stack.Navigator
      screenOptions={{ headerShown: false, animation: 'slide_from_left' }}
    >
      <Stack.Screen name="Login"    component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
}

export default function AppNavigator() {
  const { merchant, loading } = useAuth();
  if (loading) return null;

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false, animation: 'fade' }}>
        {merchant
          ? <Stack.Screen name="Main"     component={MainTabs} />
          : <Stack.Screen name="AuthFlow" component={AuthStack} />
        }
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const tab = StyleSheet.create({
  bar: {
    backgroundColor: Colors.surface,
    borderTopWidth:  1,
    borderTopColor:  Colors.borderLight,
    height:          66,
    paddingBottom:   4,
    ...Shadow.xs,
  },
  item:        { alignItems: 'center', gap: 1, paddingTop: 4 },
  label:       { fontSize: 9,  fontWeight: '500', color: Colors.textMuted },
  labelActive: { fontSize: 9,  fontWeight: '800', color: Colors.gold },
});
