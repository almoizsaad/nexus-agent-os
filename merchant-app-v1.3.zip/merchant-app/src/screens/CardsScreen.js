import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList,
  TouchableOpacity, Alert, TextInput,
  RefreshControl, StatusBar, ActivityIndicator,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radii, Shadow } from '../theme';
import { Button, Divider, AmountDisplay } from '../components/UI';
import {
  fetchLinkedCards,
  linkCardToAccount,
  unlinkCardFromAccount,
  updateCardLabel,
  processTopUp,
  verifyCard,
} from '../services/api';

const VIEW = {
  LIST:   'list',
  SCAN:   'scan',
  DETAIL: 'detail',
  LABEL:  'label',   // rename card
};

export default function CardsScreen() {
  const [view, setView]           = useState(VIEW.LIST);
  const [cards, setCards]         = useState([]);
  const [selected, setSelected]   = useState(null);
  const [refreshing, setRefreshing] = useState(false);
  const [listLoading, setListLoading] = useState(true);

  // Scanner
  const [permission, requestPermission] = useCameraPermissions();
  const [scanReady, setScanReady]       = useState(false);
  const [scanLocked, setScanLocked]     = useState(false);

  // Manual link
  const [manualId, setManualId]     = useState('');
  const [linkLoading, setLinkLoading] = useState(false);

  // Top-up
  const [topUpAmount, setTopUpAmount]   = useState('');
  const [topUpLoading, setTopUpLoading] = useState(false);

  // Label edit
  const [labelDraft, setLabelDraft] = useState('');

  // ── Load cards from server ──────────────────────────────────
  const loadCards = useCallback(async (silent = false) => {
    if (!silent) setListLoading(true);
    try {
      const data = await fetchLinkedCards();
      setCards(data);
    } catch {
      // keep existing data — network may be slow
    } finally {
      setListLoading(false);
      setRefreshing(false);
    }
  }, []);

  // Auto-refresh whenever the tab comes into focus
  useFocusEffect(
    useCallback(() => {
      loadCards();
    }, [loadCards])
  );

  const handleRefresh = () => {
    setRefreshing(true);
    loadCards(true);
  };

  // ── Link by QR scan ─────────────────────────────────────────
  const openScanner = async () => {
    if (!permission?.granted) {
      const res = await requestPermission();
      if (!res.granted) {
        Alert.alert('إذن الكاميرا مطلوب', 'يُرجى السماح بالوصول من إعدادات الهاتف');
        return;
      }
    }
    setScanLocked(false);
    setScanReady(false);
    setView(VIEW.SCAN);
  };

  const handleCardScanned = useCallback(async ({ data }) => {
    if (scanLocked) return;
    // Validate our QR format: {"cid":"...","sig":"..."}
    let cardId;
    try {
      const p = JSON.parse(data);
      if (!p.cid || !p.sig) return;
      cardId = p.cid;
    } catch { return; }

    setScanLocked(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      // Verify card exists and get its info
      const card = await verifyCard(data);
      // Link it server-side so it persists across devices
      const linked = await linkCardToAccount(card.cardId, card.serialNumber || cardId, '');
      await loadCards(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert(
        '✓ تم ربط البطاقة',
        `البطاقة ${linked.serial} مضافة\nالرصيد: ${Number(linked.balanceSDG || 0).toFixed(2)} SDG`,
        [{ text: 'حسناً', onPress: () => setView(VIEW.LIST) }]
      );
    } catch (err) {
      const msg = err.response?.data?.error || err.message || 'فشل ربط البطاقة';
      Alert.alert('خطأ', msg);
      setScanLocked(false);
    }
  }, [scanLocked, loadCards]);

  // ── Link by manual input ────────────────────────────────────
  const handleManualLink = async () => {
    const id = manualId.trim();
    if (!id) return;
    setLinkLoading(true);
    try {
      const linked = await linkCardToAccount(id, id, '');
      await loadCards(true);
      setManualId('');
      setView(VIEW.LIST);
      Alert.alert('✓ تم الربط', `البطاقة ${linked.serial} مضافة`);
    } catch (err) {
      Alert.alert('خطأ', err.response?.data?.error || 'البطاقة غير موجودة في النظام');
    } finally {
      setLinkLoading(false);
    }
  };

  // ── Unlink card ─────────────────────────────────────────────
  const handleUnlink = (card) => {
    Alert.alert(
      'إزالة البطاقة',
      `إزالة "${card.label || card.serial}" من حسابك؟\n(البطاقة لن تُلغى، فقط ستُزال من قائمتك)`,
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: 'إزالة',
          style: 'destructive',
          onPress: async () => {
            try {
              await unlinkCardFromAccount(card.cardId);
              await loadCards(true);
              if (view === VIEW.DETAIL) setView(VIEW.LIST);
            } catch (err) {
              Alert.alert('خطأ', err.response?.data?.error || 'فشلت العملية');
            }
          },
        },
      ]
    );
  };

  // ── Top-up ──────────────────────────────────────────────────
  const handleTopUp = async () => {
    const amount = parseFloat(topUpAmount);
    if (!amount || amount <= 0) { Alert.alert('خطأ', 'أدخل مبلغاً صحيحاً'); return; }
    setTopUpLoading(true);
    try {
      const txn = await processTopUp(selected.cardId, amount);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTopUpAmount('');
      // Refresh card list to get updated balance
      await loadCards(true);
      // Update selected card balance locally for immediate feedback
      const updated = { ...selected, balanceSDG: txn.balanceAfterSDG };
      setSelected(updated);
      Alert.alert('✓ تم الشحن', `الرصيد الجديد: ${Number(txn.balanceAfterSDG).toFixed(2)} SDG`);
    } catch (err) {
      Alert.alert('خطأ في الشحن', err.response?.data?.error || 'فشلت العملية');
    } finally {
      setTopUpLoading(false);
    }
  };

  // ── Save label ──────────────────────────────────────────────
  const handleSaveLabel = async () => {
    try {
      await updateCardLabel(selected.cardId, labelDraft);
      await loadCards(true);
      setView(VIEW.DETAIL);
      Alert.alert('✓ تم التحديث');
    } catch {
      Alert.alert('خطأ', 'فشل تحديث التسمية');
    }
  };

  // ── SCAN view ───────────────────────────────────────────────
  if (view === VIEW.SCAN) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <StatusBar barStyle="dark-content" />
        <View style={styles.topBar}>
          <Text style={styles.topBarTitle}>ربط بطاقة جديدة</Text>
          <TouchableOpacity onPress={() => setView(VIEW.LIST)} style={styles.closeBtn}>
            <Text style={styles.closeBtnText}>✕</Text>
          </TouchableOpacity>
        </View>

        {/* Invisible camera */}
        {permission?.granted && (
          <View style={styles.hiddenCam} pointerEvents="none">
            <CameraView
              style={{ flex: 1 }}
              facing="back"
              onCameraReady={() => setScanReady(true)}
              onBarcodeScanned={scanReady && !scanLocked ? handleCardScanned : undefined}
              barcodeScannerSettings={{ barcodeTypes: ['qr'] }}
            />
          </View>
        )}

        <View style={styles.scanBox}>
          <Corner pos="TL" /><Corner pos="TR" />
          <Corner pos="BL" /><Corner pos="BR" />
          <View style={styles.scanInner}>
            {!permission?.granted ? (
              <>
                <Text style={styles.scanTitle}>إذن الكاميرا مطلوب</Text>
                <Button label="منح الإذن" onPress={requestPermission} style={{ marginTop: Spacing.md }} />
              </>
            ) : !scanReady ? (
              <ActivityIndicator color={Colors.gold} size="large" />
            ) : (
              <>
                <View style={styles.scanPulse} />
                <Text style={styles.scanTitle}>امسح رمز QR على البطاقة</Text>
                <Text style={styles.scanSub}>ستُضاف البطاقة وتُحفظ في حسابك</Text>
              </>
            )}
          </View>
        </View>

        {/* Manual entry fallback */}
        <View style={styles.manualBox}>
          <Text style={styles.manualLabel}>أو أدخل الرقم يدوياً</Text>
          <View style={styles.manualRow}>
            <TextInput
              style={[styles.input, { flex: 1 }]}
              value={manualId}
              onChangeText={setManualId}
              placeholder="BATCH-001-000001 أو CARD-XXXX"
              placeholderTextColor={Colors.textMuted}
              autoCapitalize="characters"
              autoCorrect={false}
            />
            <Button
              label={linkLoading ? '...' : 'إضافة'}
              onPress={handleManualLink}
              loading={linkLoading}
              disabled={!manualId.trim()}
              style={{ minWidth: 88 }}
            />
          </View>
        </View>
      </SafeAreaView>
    );
  }

  // ── LABEL view ──────────────────────────────────────────────
  if (view === VIEW.LABEL) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <View style={styles.topBar}>
          <TouchableOpacity onPress={() => setView(VIEW.DETAIL)}>
            <Text style={styles.backText}>← رجوع</Text>
          </TouchableOpacity>
          <Text style={styles.topBarTitle}>تسمية البطاقة</Text>
          <View style={{ width: 60 }} />
        </View>
        <View style={styles.labelForm}>
          <Text style={styles.fieldLabel}>اسم مخصص للبطاقة</Text>
          <TextInput
            style={styles.input}
            value={labelDraft}
            onChangeText={setLabelDraft}
            placeholder="مثال: بطاقة الشراء اليومي"
            placeholderTextColor={Colors.textMuted}
            textAlign="right"
            autoFocus
            maxLength={40}
          />
          <Button label="حفظ التسمية" onPress={handleSaveLabel} style={{ marginTop: Spacing.md }} />
        </View>
      </SafeAreaView>
    );
  }

  // ── DETAIL view ─────────────────────────────────────────────
  if (view === VIEW.DETAIL && selected) {
    const statusColor = selected.status === 'active' ? Colors.leaf : Colors.amber;
    const statusLabel = selected.status === 'active' ? 'نشطة' : selected.status === 'virgin' ? 'جديدة' : selected.status;

    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <StatusBar barStyle="light-content" backgroundColor={Colors.ink} />
        <View style={[styles.topBar, { backgroundColor: Colors.ink, borderBottomColor: Colors.inkLight }]}>
          <TouchableOpacity onPress={() => setView(VIEW.LIST)}>
            <Text style={[styles.backText, { color: Colors.gold }]}>← رجوع</Text>
          </TouchableOpacity>
          <Text style={[styles.topBarTitle, { color: Colors.textInvert }]}>تفاصيل البطاقة</Text>
          <TouchableOpacity onPress={() => handleUnlink(selected)}>
            <Text style={styles.unlinkText}>إزالة</Text>
          </TouchableOpacity>
        </View>

        <FlatList
          data={[]}
          renderItem={null}
          ListHeaderComponent={() => (
            <View>
              {/* Card visual */}
              <View style={styles.cardVisual}>
                <View style={styles.cardVisualTop}>
                  <View style={styles.cardChip} />
                  <View style={[styles.cardStatusPill, { backgroundColor: `${statusColor}25` }]}>
                    <Text style={[styles.cardStatusText, { color: statusColor }]}>{statusLabel}</Text>
                  </View>
                </View>
                {(selected.label) ? (
                  <Text style={styles.cardLabel}>{selected.label}</Text>
                ) : null}
                <Text style={styles.cardSerial}>{selected.serial}</Text>
                <View style={styles.cardBalanceRow}>
                  <Text style={styles.cardBalanceLabel}>الرصيد</Text>
                  <AmountDisplay
                    value={selected.balanceSDG ?? 0}
                    size="medium"
                    color={Colors.textInvert}
                  />
                </View>
              </View>

              {/* Actions row */}
              <View style={styles.actionRow}>
                <ActionBtn
                  icon="✏️"
                  label="تسمية"
                  onPress={() => {
                    setLabelDraft(selected.label || '');
                    setView(VIEW.LABEL);
                  }}
                />
                <ActionBtn icon="🔄" label="تحديث" onPress={() => loadCards()} />
                <ActionBtn icon="🗑️" label="إزالة" onPress={() => handleUnlink(selected)} danger />
              </View>

              {/* Top-up */}
              <View style={styles.topUpCard}>
                <Text style={styles.sectionTitle}>شحن الرصيد</Text>
                <View style={styles.topUpRow}>
                  <TextInput
                    style={[styles.input, { flex: 1 }]}
                    value={topUpAmount}
                    onChangeText={setTopUpAmount}
                    placeholder="المبلغ SDG"
                    placeholderTextColor={Colors.textMuted}
                    keyboardType="decimal-pad"
                    textAlign="right"
                  />
                  <Button
                    label={topUpLoading ? '...' : 'شحن'}
                    onPress={handleTopUp}
                    loading={topUpLoading}
                    disabled={!topUpAmount}
                    style={{ minWidth: 90 }}
                  />
                </View>
              </View>

              {/* Card info */}
              <View style={styles.infoCard}>
                <InfoLine label="معرّف البطاقة" value={selected.cardId} mono />
                {selected.lastTransactionAt && (
                  <InfoLine
                    label="آخر معاملة"
                    value={new Date(selected.lastTransactionAt).toLocaleDateString('ar-SD')}
                  />
                )}
                <InfoLine
                  label="تاريخ الربط"
                  value={new Date(selected.linkedAt).toLocaleDateString('ar-SD')}
                  last
                />
              </View>
            </View>
          )}
          showsVerticalScrollIndicator={false}
        />
      </SafeAreaView>
    );
  }

  // ── LIST view (default) ─────────────────────────────────────
  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar barStyle="dark-content" />
      <View style={styles.topBar}>
        <View>
          <Text style={styles.pageTitle}>بطاقاتي</Text>
          <Text style={styles.pageSubtitle}>{cards.length} بطاقة مرتبطة بحسابك</Text>
        </View>
        <Button
          label="+ ربط بطاقة"
          variant="outline"
          onPress={openScanner}
          style={{ paddingHorizontal: Spacing.md }}
        />
      </View>

      {listLoading && cards.length === 0 ? (
        <View style={styles.loadingState}>
          <ActivityIndicator color={Colors.gold} size="large" />
          <Text style={styles.loadingText}>جاري تحميل بطاقاتك...</Text>
        </View>
      ) : (
        <FlatList
          data={cards}
          keyExtractor={c => c.cardId}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.cardRow}
              onPress={() => { setSelected(item); setView(VIEW.DETAIL); }}
              activeOpacity={0.75}
            >
              {/* Card mini visual */}
              <View style={styles.cardMini}>
                <View style={styles.cardMiniChip} />
              </View>

              {/* Info */}
              <View style={styles.cardRowInfo}>
                <Text style={styles.cardRowLabel}>
                  {item.label || item.serial}
                </Text>
                {item.label && (
                  <Text style={styles.cardRowSerial}>{item.serial}</Text>
                )}
                <View style={styles.cardRowStatusRow}>
                  <View style={[
                    styles.statusDot,
                    { backgroundColor: item.status === 'active' ? Colors.leaf : Colors.amber },
                  ]} />
                  <Text style={styles.cardRowStatus}>
                    {item.status === 'active' ? 'نشطة' : item.status === 'virgin' ? 'جديدة' : item.status}
                  </Text>
                </View>
              </View>

              {/* Balance */}
              <View style={styles.cardRowBalance}>
                {item.balanceSDG !== null ? (
                  <>
                    <Text style={styles.cardRowBalanceNum}>
                      {Number(item.balanceSDG).toFixed(2)}
                    </Text>
                    <Text style={styles.cardRowBalanceCur}>SDG</Text>
                  </>
                ) : (
                  <Text style={styles.cardRowBalanceUnknown}>—</Text>
                )}
              </View>

              <Text style={styles.cardRowChevron}>›</Text>
            </TouchableOpacity>
          )}
          ItemSeparatorComponent={() => (
            <View style={{ height: 1, backgroundColor: Colors.borderLight, marginLeft: 76 }} />
          )}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Text style={styles.emptyIcon}>💳</Text>
              <Text style={styles.emptyTitle}>لا توجد بطاقات مرتبطة</Text>
              <Text style={styles.emptySub}>
                اضغط "+ ربط بطاقة" لإضافة بطاقة دفع ورقية
              </Text>
              <Button
                label="ربط بطاقة الآن"
                onPress={openScanner}
                style={{ marginTop: Spacing.md }}
              />
            </View>
          }
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={handleRefresh}
              tintColor={Colors.gold}
              colors={[Colors.gold]}
            />
          }
          contentContainerStyle={{ flexGrow: 1 }}
          showsVerticalScrollIndicator={false}
        />
      )}
    </SafeAreaView>
  );
}

// ── Helper components ──────────────────────────────────────────────

function Corner({ pos }) {
  const s = {
    TL: { top: 20, left: 20, borderRightWidth: 0, borderBottomWidth: 0, borderTopLeftRadius: 6 },
    TR: { top: 20, right: 20, borderLeftWidth: 0, borderBottomWidth: 0, borderTopRightRadius: 6 },
    BL: { bottom: 20, left: 20, borderRightWidth: 0, borderTopWidth: 0, borderBottomLeftRadius: 6 },
    BR: { bottom: 20, right: 20, borderLeftWidth: 0, borderTopWidth: 0, borderBottomRightRadius: 6 },
  }[pos];
  return <View style={[cst.corner, s]} />;
}

function ActionBtn({ icon, label, onPress, danger }) {
  return (
    <TouchableOpacity
      style={[cst.actionBtn, danger && cst.actionBtnDanger]}
      onPress={onPress}
      activeOpacity={0.7}
    >
      <Text style={cst.actionBtnIcon}>{icon}</Text>
      <Text style={[cst.actionBtnLabel, danger && { color: Colors.clay }]}>{label}</Text>
    </TouchableOpacity>
  );
}

function InfoLine({ label, value, mono, last }) {
  return (
    <View style={[cst.infoLine, !last && cst.infoLineBorder]}>
      <Text style={cst.infoLabel}>{label}</Text>
      <Text style={[cst.infoValue, mono && cst.infoMono]} numberOfLines={1}>{value}</Text>
    </View>
  );
}

const cst = StyleSheet.create({
  corner:           { position: 'absolute', width: 26, height: 26, borderColor: Colors.gold, borderWidth: 2.5 },
  actionBtn:        { flex: 1, alignItems: 'center', gap: 4, backgroundColor: Colors.surface, borderRadius: Radii.md, paddingVertical: Spacing.sm, ...Shadow.xs },
  actionBtnDanger:  { backgroundColor: Colors.clayBg },
  actionBtnIcon:    { fontSize: 20 },
  actionBtnLabel:   { fontSize: 11, fontWeight: '700', color: Colors.textSecondary },
  infoLine:         { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10 },
  infoLineBorder:   { borderBottomWidth: 1, borderBottomColor: Colors.borderLight },
  infoLabel:        { fontSize: 13, color: Colors.textMuted },
  infoValue:        { fontSize: 13, fontWeight: '600', color: Colors.textPrimary, maxWidth: '60%' },
  infoMono:         { fontFamily: 'Courier New', fontSize: 11 },
});

const styles = StyleSheet.create({
  safe:    { flex: 1, backgroundColor: Colors.canvas },
  hiddenCam: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, opacity: 0, zIndex: 0 },

  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm + 2,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
    backgroundColor: Colors.canvas,
    zIndex: 1,
  },
  topBarTitle:  { fontSize: 16, fontWeight: '700', color: Colors.textPrimary },
  backText:     { fontSize: 14, color: Colors.gold, fontWeight: '700' },
  unlinkText:   { fontSize: 13, color: Colors.clay, fontWeight: '700' },
  closeBtn:     { width: 32, height: 32, borderRadius: 16, backgroundColor: Colors.borderLight, alignItems: 'center', justifyContent: 'center' },
  closeBtnText: { fontSize: 14, color: Colors.textSecondary, fontWeight: '700' },

  pageTitle:    { fontSize: 20, fontWeight: '800', color: Colors.textPrimary },
  pageSubtitle: { fontSize: 11, color: Colors.textMuted, marginTop: 2 },

  // Card list row
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: Colors.surface,
    paddingVertical: Spacing.md,
    paddingHorizontal: Spacing.md,
    gap: Spacing.sm,
  },
  cardMini:        { width: 48, height: 32, borderRadius: 6, backgroundColor: Colors.ink, justifyContent: 'flex-end', padding: 5 },
  cardMiniChip:    { width: 16, height: 11, borderRadius: 3, backgroundColor: Colors.gold },
  cardRowInfo:     { flex: 1, gap: 2 },
  cardRowLabel:    { fontSize: 15, fontWeight: '700', color: Colors.textPrimary },
  cardRowSerial:   { fontSize: 11, color: Colors.textMuted, fontFamily: 'Courier New' },
  cardRowStatusRow:{ flexDirection: 'row', alignItems: 'center', gap: 5 },
  statusDot:       { width: 6, height: 6, borderRadius: 3 },
  cardRowStatus:   { fontSize: 11, color: Colors.textMuted },
  cardRowBalance:  { alignItems: 'flex-end' },
  cardRowBalanceNum: { fontSize: 18, fontWeight: '800', color: Colors.textPrimary, fontVariant: ['tabular-nums'] },
  cardRowBalanceCur: { fontSize: 10, color: Colors.textMuted },
  cardRowBalanceUnknown: { fontSize: 16, color: Colors.textMuted },
  cardRowChevron:  { fontSize: 20, color: Colors.textMuted, marginLeft: 4 },

  // Scanner
  scanBox:   { flex: 1, backgroundColor: Colors.surface, margin: Spacing.md, borderRadius: Radii.xl, alignItems: 'center', justifyContent: 'center', ...Shadow.card },
  scanInner: { alignItems: 'center', gap: 12, padding: Spacing.lg },
  scanPulse: { width: 56, height: 56, borderRadius: 28, backgroundColor: Colors.goldPale, borderWidth: 3, borderColor: Colors.gold, marginBottom: 8 },
  scanTitle: { fontSize: 18, fontWeight: '800', color: Colors.textPrimary, textAlign: 'center' },
  scanSub:   { fontSize: 13, color: Colors.textMuted, textAlign: 'center' },

  manualBox: { padding: Spacing.md, gap: Spacing.sm },
  manualLabel: { fontSize: 12, color: Colors.textMuted, fontWeight: '600', textAlign: 'center' },
  manualRow:   { flexDirection: 'row', gap: Spacing.sm },

  // Detail view — card visual
  cardVisual: {
    backgroundColor: Colors.ink,
    margin: Spacing.md,
    borderRadius: Radii.xl,
    padding: Spacing.xl,
    gap: Spacing.sm,
    ...Shadow.elevated,
  },
  cardVisualTop:   { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardChip:        { width: 38, height: 28, borderRadius: 5, backgroundColor: Colors.gold },
  cardStatusPill:  { paddingHorizontal: 10, paddingVertical: 4, borderRadius: Radii.full },
  cardStatusText:  { fontSize: 12, fontWeight: '700' },
  cardLabel:       { fontSize: 16, fontWeight: '700', color: 'rgba(255,255,255,0.9)' },
  cardSerial:      { fontFamily: 'Courier New', fontSize: 13, color: 'rgba(255,255,255,0.5)', letterSpacing: 1 },
  cardBalanceRow:  { gap: 4 },
  cardBalanceLabel:{ fontSize: 10, color: 'rgba(255,255,255,0.4)', textTransform: 'uppercase', letterSpacing: 0.8 },

  actionRow:  { flexDirection: 'row', gap: Spacing.sm, marginHorizontal: Spacing.md, marginBottom: Spacing.sm },

  topUpCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
    gap: Spacing.sm,
    ...Shadow.xs,
  },
  sectionTitle: { fontSize: 13, fontWeight: '700', color: Colors.textPrimary },
  topUpRow:     { flexDirection: 'row', gap: Spacing.sm, alignItems: 'center' },

  infoCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    marginHorizontal: Spacing.md,
    ...Shadow.xs,
  },

  input: {
    height: 48,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    fontSize: 15,
    color: Colors.textPrimary,
    backgroundColor: Colors.canvas,
  },

  labelForm: { padding: Spacing.lg, gap: Spacing.sm },
  fieldLabel: { fontSize: 12, fontWeight: '700', color: Colors.textSecondary },

  // Loading & empty
  loadingState: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: Spacing.md },
  loadingText:  { fontSize: 14, color: Colors.textMuted },
  emptyState:   { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10, paddingVertical: 60, paddingHorizontal: Spacing.xl },
  emptyIcon:    { fontSize: 48 },
  emptyTitle:   { fontSize: 18, fontWeight: '700', color: Colors.textPrimary },
  emptySub:     { fontSize: 13, color: Colors.textMuted, textAlign: 'center', lineHeight: 20 },
});
