import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, StyleSheet,
  TouchableOpacity, Alert, StatusBar,
  ScrollView, Platform,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Colors, Spacing, Radii, Shadow, Brand } from '../theme';
import { Button } from '../components/UI';
import { LogoWithText } from '../components/Logo';
import api from '../services/api';

export default function RegisterScreen({ navigation }) {
  const [form, setForm] = useState({
    businessName: '',
    ownerName: '',
    phone: '',
    password: '',
    confirmPassword: '',
    city: '',
  });
  const [loading, setLoading]   = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [focused, setFocused]   = useState(null);

  // Refs for sequential TextInput focus (Return key moves to next field)
  const refs = {
    businessName:    useRef(null),
    ownerName:       useRef(null),
    phone:           useRef(null),
    city:            useRef(null),
    password:        useRef(null),
    confirmPassword: useRef(null),
  };

  const set = (key) => (val) => setForm(p => ({ ...p, [key]: val }));

  const handleRegister = async () => {
    const { businessName, ownerName, phone, password, confirmPassword, city } = form;

    if (!businessName.trim() || !ownerName.trim() || !phone.trim() || !password) {
      Alert.alert('بيانات ناقصة', 'يرجى ملء جميع الحقول المطلوبة');
      return;
    }
    if (password.length < 8) {
      Alert.alert('كلمة مرور ضعيفة', 'يجب أن تكون كلمة المرور 8 أحرف على الأقل');
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert('خطأ', 'كلمتا المرور غير متطابقتين');
      return;
    }

    setLoading(true);
    try {
      await api.post('/auth/register', {
        businessName: businessName.trim(),
        ownerName:    ownerName.trim(),
        phone:        phone.trim(),
        password,
        city:         city.trim(),
      });
      Alert.alert(
        '✓ تم التسجيل',
        'سيتم مراجعة حسابك وتفعيله خلال 24 ساعة. يمكنك تسجيل الدخول بعد التفعيل.',
        [{ text: 'حسناً', onPress: () => navigation.goBack() }]
      );
    } catch (err) {
      const msg = err.response?.data?.error || 'فشل التسجيل — تحقق من الاتصال بالإنترنت';
      Alert.alert('فشل التسجيل', msg);
    } finally {
      setLoading(false);
    }
  };

  // Shared props for each TextInput
  const fieldProps = (key, opts = {}) => ({
    ref: refs[key],
    value: form[key],
    onChangeText: set(key),
    style: [styles.input, focused === key && styles.inputFocused],
    placeholderTextColor: Colors.textMuted,
    textAlign: 'right',
    onFocus: () => setFocused(key),
    onBlur:  () => setFocused(null),
    returnKeyType: opts.last ? 'done' : 'next',
    onSubmitEditing: opts.last
      ? handleRegister
      : () => refs[opts.next]?.current?.focus(),
    blurOnSubmit: !!opts.last,
    ...opts,
  });

  return (
    <SafeAreaView style={styles.safe} edges={['top', 'bottom']}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.ink} />

      {/*
        We use ScrollView with keyboardShouldPersistTaps="handled" instead of
        KeyboardAvoidingView, which causes the keyboard to flash on Android.
        The ScrollView scrolls the content up naturally when a field is focused.
      */}
      <ScrollView
        contentContainerStyle={styles.scroll}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        keyboardDismissMode="interactive"
      >
        <View style={styles.header}>
          <LogoWithText size={38} variant="light" />
          <Text style={styles.headerSub}>تسجيل حساب تاجر جديد</Text>
        </View>

        <View style={styles.infoBanner}>
          <Text style={styles.infoBannerText}>
            📋 بعد التسجيل، ستتم مراجعة بياناتك وتفعيل الحساب خلال 24 ساعة
          </Text>
        </View>

        <View style={styles.card}>

          <Text style={styles.sectionHead}>بيانات المنشأة</Text>

          <View style={styles.field}>
            <Text style={styles.fieldLabel}>اسم المنشأة / المتجر *</Text>
            <TextInput
              {...fieldProps('businessName', { next: 'ownerName' })}
              placeholder="مثال: متجر الأمل"
              autoCapitalize="words"
            />
          </View>

          <View style={styles.field}>
            <Text style={styles.fieldLabel}>اسم صاحب الحساب *</Text>
            <TextInput
              {...fieldProps('ownerName', { next: 'phone' })}
              placeholder="الاسم الكامل"
              autoCapitalize="words"
            />
          </View>

          <View style={styles.field}>
            <Text style={styles.fieldLabel}>المدينة</Text>
            <TextInput
              {...fieldProps('city', { next: 'password' })}
              placeholder="مثال: الخرطوم"
              autoCapitalize="words"
            />
            <Text style={styles.fieldOptional}>اختياري</Text>
          </View>

          <View style={styles.divider} />
          <Text style={styles.sectionHead}>بيانات تسجيل الدخول</Text>

          <View style={styles.field}>
            <Text style={styles.fieldLabel}>رقم الهاتف *</Text>
            <TextInput
              {...fieldProps('phone', { next: 'city' })}
              placeholder="+249 ..."
              keyboardType="phone-pad"
              autoCapitalize="none"
              textContentType="telephoneNumber"
            />
          </View>

          <View style={styles.field}>
            <Text style={styles.fieldLabel}>كلمة المرور * (8 أحرف على الأقل)</Text>
            <View style={styles.passRow}>
              <TextInput
                {...fieldProps('password', { next: 'confirmPassword' })}
                placeholder="••••••••"
                secureTextEntry={!showPass}
                textContentType="newPassword"
                style={[styles.input, styles.inputFlex, focused === 'password' && styles.inputFocused]}
              />
              <TouchableOpacity onPress={() => setShowPass(p => !p)} style={styles.showBtn}>
                <Text style={styles.showBtnText}>{showPass ? 'إخفاء' : 'إظهار'}</Text>
              </TouchableOpacity>
            </View>
          </View>

          <View style={styles.field}>
            <Text style={styles.fieldLabel}>تأكيد كلمة المرور *</Text>
            <TextInput
              {...fieldProps('confirmPassword', { last: true })}
              placeholder="أعد كتابة كلمة المرور"
              secureTextEntry={!showPass}
              textContentType="newPassword"
            />
          </View>

          <Button
            label="إرسال طلب التسجيل"
            onPress={handleRegister}
            loading={loading}
            style={{ marginTop: Spacing.xs }}
          />

          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <Text style={styles.backBtnText}>← العودة لتسجيل الدخول</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.footer}>{Brand.nameEn} · {Brand.serverUrl.split('/')[2]}</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:   { flex: 1, backgroundColor: Colors.ink },
  scroll: { flexGrow: 1, padding: Spacing.lg, paddingTop: Spacing.xl, gap: Spacing.md, paddingBottom: 40 },

  header:    { alignItems: 'center', gap: 10 },
  headerSub: { fontSize: 13, color: 'rgba(255,255,255,0.4)', fontWeight: '500' },

  infoBanner: {
    backgroundColor: 'rgba(200,146,42,0.15)',
    borderRadius: Radii.md,
    padding: Spacing.md,
    borderLeftWidth: 3,
    borderLeftColor: Colors.gold,
  },
  infoBannerText: { fontSize: 13, color: Colors.goldPale, lineHeight: 20 },

  card: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.lg,
    gap: Spacing.md,
    ...Shadow.elevated,
  },

  sectionHead: {
    fontSize: 10, fontWeight: '800', letterSpacing: 1.2,
    color: Colors.textMuted, textTransform: 'uppercase', marginBottom: -Spacing.xs,
  },
  divider: { height: 1, backgroundColor: Colors.borderLight },

  field:         { gap: 5 },
  fieldLabel:    { fontSize: 12, fontWeight: '700', color: Colors.textSecondary, textAlign: 'right', letterSpacing: 0.3 },
  fieldOptional: { fontSize: 10, color: Colors.textMuted, textAlign: 'right' },

  input: {
    height: 50,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    fontSize: 15,
    color: Colors.textPrimary,
    backgroundColor: Colors.canvas,
  },
  inputFocused: { borderColor: Colors.gold, backgroundColor: Colors.surface },
  inputFlex:    { flex: 1 },

  passRow:     { flexDirection: 'row', alignItems: 'center', gap: 8 },
  showBtn:     { paddingHorizontal: 4, height: 50, justifyContent: 'center' },
  showBtnText: { fontSize: 12, fontWeight: '700', color: Colors.gold },

  backBtn:     { alignItems: 'center', paddingTop: Spacing.xs },
  backBtnText: { fontSize: 13, color: Colors.textMuted, fontWeight: '500' },

  footer: { textAlign: 'center', fontSize: 11, color: 'rgba(255,255,255,0.2)', paddingVertical: Spacing.md },
});
