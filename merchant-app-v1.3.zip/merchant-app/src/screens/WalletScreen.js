import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView,
  TouchableOpacity, Alert, TextInput,
  RefreshControl, StatusBar, FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import * as Haptics from 'expo-haptics';
import { Colors, Spacing, Radii, Shadow } from '../theme';
import { Button, Divider, AmountDisplay } from '../components/UI';
import {
  getWalletSummary,
  getWalletHistory,
  lookupMerchantByPhone,
  transferToMerchant,
} from '../services/api';

// Sub-views within the Wallet tab
const VIEW = {
  MAIN:     'main',       // Balance + recent txns
  HISTORY:  'history',    // Full transaction list
  TRANSFER: 'transfer',   // Send money flow
  CONFIRM:  'confirm',    // Confirm transfer before sending
};

const TXN_TYPE_META = {
  credit:       { label: 'وارد',       color: '#2E7D5A', sign: '+' },
  debit:        { label: 'صادر',       color: '#C0392B', sign: '-' },
  transfer_in:  { label: 'تحويل وارد', color: '#2E7D5A', sign: '+' },
  transfer_out: { label: 'تحويل صادر', color: '#C0392B', sign: '-' },
};

export default function WalletScreen() {
  const [view, setView]           = useState(VIEW.MAIN);
  const [summary, setSummary]     = useState(null);
  const [history, setHistory]     = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [loading, setLoading]     = useState(false);

  // Transfer state
  const [recipientPhone, setRecipientPhone] = useState('');
  const [amountStr, setAmountStr]           = useState('');
  const [note, setNote]                     = useState('');
  const [recipientInfo, setRecipientInfo]   = useState(null);
  const [lookupLoading, setLookupLoading]   = useState(false);

  const loadSummary = useCallback(async () => {
    try {
      const data = await getWalletSummary();
      setSummary(data);
    } catch {
      // keep existing data
    } finally {
      setRefreshing(false);
    }
  }, []);

  // Refresh every time the tab is focused
  useFocusEffect(
    useCallback(() => {
      loadSummary();
    }, [loadSummary])
  );

  const handleRefresh = () => {
    setRefreshing(true);
    loadSummary();
  };

  const loadHistory = async () => {
    try {
      const data = await getWalletHistory(1, 30);
      setHistory(data.data || []);
    } catch {
      Alert.alert('خطأ', 'تعذّر تحميل السجل');
    }
    setView(VIEW.HISTORY);
  };

  // ── Transfer flow ─────────────────────────────────────────────

  const handleLookup = async () => {
    const phone = recipientPhone.trim();
    if (!phone) return;
    setLookupLoading(true);
    try {
      const info = await lookupMerchantByPhone(phone);
      setRecipientInfo(info);
    } catch (err) {
      const msg = err.response?.data?.error || 'الرقم غير مسجل في النظام';
      setRecipientInfo(null);
      Alert.alert('لم يُعثر على الحساب', msg);
    } finally {
      setLookupLoading(false);
    }
  };

  const handleTransferConfirm = async () => {
    const amount = parseFloat(amountStr);
    if (!amount || amount <= 0) { Alert.alert('خطأ', 'أدخل مبلغاً صحيحاً'); return; }
    if (!recipientInfo) { Alert.alert('خطأ', 'ابحث عن المستلم أولاً'); return; }
    if (summary && amount > summary.balanceSDG) {
      Alert.alert('رصيد غير كافٍ', `رصيدك: ${summary.balanceSDG.toFixed(2)} SDG`);
      return;
    }
    setView(VIEW.CONFIRM);
  };

  const handleTransferSend = async () => {
    setLoading(true);
    try {
      const result = await transferToMerchant({
        recipientPhone: recipientPhone.trim(),
        amountSDG:      parseFloat(amountStr),
        note:           note.trim(),
      });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      Alert.alert(
        '✓ تم التحويل',
        `تم تحويل ${result.amountSDG.toFixed(2)} SDG إلى ${result.recipient.businessName}\n` +
        `رصيدك الحالي: ${result.senderBalanceAfterSDG.toFixed(2)} SDG`,
        [{ text: 'حسناً', onPress: resetTransfer }]
      );
      loadSummary();
    } catch (err) {
      const msg = err.response?.data?.error || 'فشل التحويل';
      Alert.alert('فشل التحويل', msg);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    } finally {
      setLoading(false);
    }
  };

  const resetTransfer = () => {
    setView(VIEW.MAIN);
    setRecipientPhone('');
    setAmountStr('');
    setNote('');
    setRecipientInfo(null);
  };

  // ── Renders ───────────────────────────────────────────────────

  // HISTORY view
  if (view === VIEW.HISTORY) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <StatusBar barStyle="dark-content" />
        <View style={styles.topBar}>
          <TouchableOpacity onPress={() => setView(VIEW.MAIN)} style={styles.backBtn}>
            <Text style={styles.backText}>← رجوع</Text>
          </TouchableOpacity>
          <Text style={styles.topBarTitle}>سجل المحفظة</Text>
          <View style={{ width: 60 }} />
        </View>
        <FlatList
          data={history}
          keyExtractor={t => t.ref}
          renderItem={({ item }) => <WalletTxnRow txn={item} />}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          contentContainerStyle={{ paddingBottom: 32 }}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={
            <View style={styles.emptyState}>
              <Text style={styles.emptyIcon}>📂</Text>
              <Text style={styles.emptyText}>لا توجد معاملات في المحفظة</Text>
            </View>
          }
        />
      </SafeAreaView>
    );
  }

  // CONFIRM view
  if (view === VIEW.CONFIRM) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <StatusBar barStyle="dark-content" />
        <ScrollView contentContainerStyle={styles.scroll}>
          <View style={styles.topBar}>
            <TouchableOpacity onPress={() => setView(VIEW.TRANSFER)} style={styles.backBtn}>
              <Text style={styles.backText}>← تعديل</Text>
            </TouchableOpacity>
            <Text style={styles.topBarTitle}>تأكيد التحويل</Text>
            <View style={{ width: 60 }} />
          </View>

          <View style={styles.confirmCard}>
            <View style={styles.confirmRow}>
              <Text style={styles.confirmLabel}>المستلم</Text>
              <View style={styles.confirmRight}>
                <Text style={styles.confirmBusiness}>{recipientInfo?.businessName}</Text>
                <Text style={styles.confirmPhone}>{recipientPhone}</Text>
              </View>
            </View>
            <Divider />
            <View style={styles.confirmRow}>
              <Text style={styles.confirmLabel}>المبلغ</Text>
              <Text style={styles.confirmAmount}>{parseFloat(amountStr).toFixed(2)} SDG</Text>
            </View>
            {note ? (
              <>
                <Divider />
                <View style={styles.confirmRow}>
                  <Text style={styles.confirmLabel}>ملاحظة</Text>
                  <Text style={styles.confirmNote}>{note}</Text>
                </View>
              </>
            ) : null}
            <Divider />
            <View style={styles.confirmRow}>
              <Text style={styles.confirmLabel}>رصيدك بعد التحويل</Text>
              <Text style={[styles.confirmAmount, { color: Colors.clay }]}>
                {((summary?.balanceSDG || 0) - parseFloat(amountStr)).toFixed(2)} SDG
              </Text>
            </View>
          </View>

          <View style={styles.confirmActions}>
            <Button label="إلغاء" variant="ghost" onPress={resetTransfer} style={{ flex: 1 }} />
            <Button
              label="تأكيد التحويل"
              variant="primary"
              onPress={handleTransferSend}
              loading={loading}
              style={{ flex: 2 }}
            />
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // TRANSFER view
  if (view === VIEW.TRANSFER) {
    return (
      <SafeAreaView style={styles.safe} edges={['top']}>
        <StatusBar barStyle="dark-content" />
        <ScrollView
          contentContainerStyle={styles.scroll}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.topBar}>
            <TouchableOpacity onPress={() => setView(VIEW.MAIN)} style={styles.backBtn}>
              <Text style={styles.backText}>← رجوع</Text>
            </TouchableOpacity>
            <Text style={styles.topBarTitle}>تحويل رصيد</Text>
            <View style={{ width: 60 }} />
          </View>

          {/* Balance reminder */}
          <View style={styles.balancePill}>
            <Text style={styles.balancePillLabel}>رصيدك المتاح</Text>
            <Text style={styles.balancePillValue}>
              {(summary?.balanceSDG || 0).toFixed(2)}{' '}
              <Text style={styles.balancePillCur}>SDG</Text>
            </Text>
          </View>

          {/* Recipient */}
          <View style={styles.fieldCard}>
            <Text style={styles.fieldLabel}>رقم هاتف التاجر المستلم</Text>
            <View style={styles.lookupRow}>
              <TextInput
                style={[styles.input, { flex: 1 }]}
                value={recipientPhone}
                onChangeText={(t) => { setRecipientPhone(t); setRecipientInfo(null); }}
                placeholder="+249 ..."
                placeholderTextColor={Colors.textMuted}
                keyboardType="phone-pad"
                textAlign="right"
              />
              <Button
                label={lookupLoading ? '...' : 'بحث'}
                onPress={handleLookup}
                loading={lookupLoading}
                disabled={!recipientPhone.trim()}
                style={{ minWidth: 80 }}
              />
            </View>
            {recipientInfo && (
              <View style={styles.recipientFound}>
                <Text style={styles.recipientFoundIcon}>✓</Text>
                <View>
                  <Text style={styles.recipientName}>{recipientInfo.businessName}</Text>
                  {recipientInfo.city ? <Text style={styles.recipientCity}>{recipientInfo.city}</Text> : null}
                </View>
              </View>
            )}
          </View>

          {/* Amount */}
          <View style={styles.fieldCard}>
            <Text style={styles.fieldLabel}>المبلغ (SDG)</Text>
            <TextInput
              style={styles.amountInput}
              value={amountStr}
              onChangeText={setAmountStr}
              placeholder="0.00"
              placeholderTextColor={Colors.textMuted}
              keyboardType="decimal-pad"
              textAlign="center"
            />
          </View>

          {/* Note */}
          <View style={styles.fieldCard}>
            <Text style={styles.fieldLabel}>ملاحظة (اختياري)</Text>
            <TextInput
              style={styles.input}
              value={note}
              onChangeText={setNote}
              placeholder="سبب التحويل..."
              placeholderTextColor={Colors.textMuted}
              textAlign="right"
              maxLength={100}
            />
          </View>

          <Button
            label="مراجعة التحويل ←"
            onPress={handleTransferConfirm}
            disabled={!recipientInfo || !amountStr || parseFloat(amountStr) <= 0}
            style={{ marginTop: Spacing.xs }}
          />
        </ScrollView>
      </SafeAreaView>
    );
  }

  // MAIN view (default)
  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={Colors.ink} />
      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={Colors.gold} />
        }
      >
        {/* Balance card */}
        <View style={styles.balanceCard}>
          <Text style={styles.balanceCardLabel}>رصيد المحفظة</Text>
          <AmountDisplay
            value={summary?.balanceSDG || 0}
            size="large"
            color={Colors.textInvert}
          />
          <Text style={styles.balanceCardSub}>جنيه سوداني · محفظتك الشخصية</Text>

          {/* Quick actions */}
          <View style={styles.quickActions}>
            <QuickAction icon="↑" label="تحويل" onPress={() => setView(VIEW.TRANSFER)} />
            <QuickAction icon="≡" label="السجل" onPress={loadHistory} />
          </View>
        </View>

        {/* Recent wallet transactions */}
        {summary?.recentTransactions?.length > 0 && (
          <View style={styles.recentSection}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>آخر المعاملات</Text>
              <TouchableOpacity onPress={loadHistory}>
                <Text style={styles.sectionAction}>عرض الكل</Text>
              </TouchableOpacity>
            </View>
            {summary.recentTransactions.map(txn => (
              <WalletTxnRow key={txn.ref} txn={txn} />
            ))}
          </View>
        )}

        {/* Empty state */}
        {!summary?.recentTransactions?.length && !refreshing && (
          <View style={styles.emptyWallet}>
            <Text style={styles.emptyWalletIcon}>💰</Text>
            <Text style={styles.emptyWalletTitle}>محفظتك فارغة</Text>
            <Text style={styles.emptyWalletSub}>
              يُضاف الرصيد تلقائياً عند استلام مدفوعات من العملاء
            </Text>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

// ── Sub-components ─────────────────────────────────────────────────

function QuickAction({ icon, label, onPress }) {
  return (
    <TouchableOpacity style={styles.quickBtn} onPress={onPress} activeOpacity={0.75}>
      <Text style={styles.quickBtnIcon}>{icon}</Text>
      <Text style={styles.quickBtnLabel}>{label}</Text>
    </TouchableOpacity>
  );
}

function WalletTxnRow({ txn }) {
  const meta = TXN_TYPE_META[txn.type] || { label: txn.type, color: Colors.textMuted, sign: '' };
  const dateStr = new Date(txn.createdAt).toLocaleDateString('ar-SD', {
    day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit',
  });

  return (
    <View style={styles.txnRow}>
      <View style={[styles.txnDot, { backgroundColor: `${meta.color}20` }]}>
        <Text style={[styles.txnDotText, { color: meta.color }]}>
          {meta.sign}
        </Text>
      </View>
      <View style={styles.txnInfo}>
        <Text style={styles.txnLabel}>{meta.label}</Text>
        {txn.counterpart && (
          <Text style={styles.txnCounterpart}>{txn.counterpart}</Text>
        )}
        {txn.note && !txn.counterpart && (
          <Text style={styles.txnNote}>{txn.note}</Text>
        )}
        <Text style={styles.txnDate}>{dateStr}</Text>
      </View>
      <View style={styles.txnAmountCol}>
        <Text style={[styles.txnAmount, { color: meta.color }]}>
          {meta.sign}{Number(txn.amountSDG).toFixed(2)}
        </Text>
        <Text style={styles.txnBalance}>{Number(txn.balanceAfterSDG).toFixed(2)} SDG</Text>
      </View>
    </View>
  );
}

// ── Styles ─────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  safe:  { flex: 1, backgroundColor: Colors.canvas },
  scroll:{ flexGrow: 1, paddingBottom: 32 },

  topBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: Spacing.md,
    paddingVertical: Spacing.sm,
    borderBottomWidth: 1,
    borderBottomColor: Colors.borderLight,
  },
  topBarTitle: { fontSize: 16, fontWeight: '700', color: Colors.textPrimary },
  backBtn:     { paddingVertical: 4 },
  backText:    { fontSize: 14, color: Colors.gold, fontWeight: '700' },
  separator:   { height: 1, backgroundColor: Colors.borderLight, marginLeft: 60 },

  // Balance card
  balanceCard: {
    backgroundColor: Colors.ink,
    margin: Spacing.md,
    borderRadius: Radii.xl,
    padding: Spacing.xl,
    alignItems: 'center',
    gap: Spacing.sm,
    ...Shadow.elevated,
  },
  balanceCardLabel: {
    fontSize: 11, fontWeight: '700',
    color: 'rgba(255,255,255,0.4)',
    letterSpacing: 1, textTransform: 'uppercase',
  },
  balanceCardSub: { fontSize: 12, color: 'rgba(255,255,255,0.35)' },

  quickActions: {
    flexDirection: 'row',
    gap: Spacing.md,
    marginTop: Spacing.sm,
  },
  quickBtn: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.xl,
    paddingVertical: Spacing.sm,
    alignItems: 'center',
    gap: 4,
  },
  quickBtnIcon:  { fontSize: 20, color: Colors.gold },
  quickBtnLabel: { fontSize: 11, color: 'rgba(255,255,255,0.6)', fontWeight: '600' },

  // Recent section
  recentSection: { paddingHorizontal: Spacing.md, marginTop: Spacing.sm },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  sectionTitle:  { fontSize: 13, fontWeight: '700', color: Colors.textSecondary },
  sectionAction: { fontSize: 12, fontWeight: '700', color: Colors.gold },

  // Transaction row
  txnRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: Spacing.sm,
    backgroundColor: Colors.surface,
    paddingHorizontal: Spacing.md,
  },
  txnDot:       { width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  txnDotText:   { fontSize: 16, fontWeight: '800' },
  txnInfo:      { flex: 1, gap: 2 },
  txnLabel:     { fontSize: 14, fontWeight: '700', color: Colors.textPrimary },
  txnCounterpart:{ fontSize: 12, color: Colors.textSecondary },
  txnNote:      { fontSize: 11, color: Colors.textMuted },
  txnDate:      { fontSize: 11, color: Colors.textMuted },
  txnAmountCol: { alignItems: 'flex-end', gap: 2 },
  txnAmount:    { fontSize: 15, fontWeight: '800', fontVariant: ['tabular-nums'] },
  txnBalance:   { fontSize: 10, color: Colors.textMuted, fontVariant: ['tabular-nums'] },

  // Transfer form
  balancePill: {
    backgroundColor: Colors.ink,
    marginHorizontal: Spacing.md,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.lg,
    paddingVertical: Spacing.sm + 2,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: Spacing.sm,
  },
  balancePillLabel: { fontSize: 12, color: 'rgba(255,255,255,0.4)' },
  balancePillValue: {
    fontSize: 22, fontWeight: '800', color: Colors.textInvert,
    fontVariant: ['tabular-nums'],
  },
  balancePillCur: { fontSize: 13, color: Colors.gold, fontWeight: '500' },

  fieldCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.lg,
    padding: Spacing.md,
    marginHorizontal: Spacing.md,
    marginBottom: Spacing.sm,
    gap: Spacing.sm,
    ...Shadow.xs,
  },
  fieldLabel: {
    fontSize: 10, fontWeight: '800',
    color: Colors.textMuted, textTransform: 'uppercase', letterSpacing: 0.8,
  },
  input: {
    height: 48,
    borderWidth: 1.5,
    borderColor: Colors.border,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    fontSize: 15,
    color: Colors.textPrimary,
    backgroundColor: Colors.canvas,
  },
  amountInput: {
    height: 64,
    borderWidth: 1.5,
    borderColor: Colors.borderFocus,
    borderRadius: Radii.md,
    paddingHorizontal: Spacing.md,
    fontSize: 32,
    fontWeight: '300',
    color: Colors.textPrimary,
    backgroundColor: Colors.canvas,
    textAlign: 'center',
    letterSpacing: -1,
  },
  lookupRow:       { flexDirection: 'row', gap: Spacing.sm, alignItems: 'center' },
  recipientFound:  { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: Colors.leafBg, borderRadius: Radii.sm, padding: Spacing.sm },
  recipientFoundIcon: { fontSize: 16, color: Colors.leaf, fontWeight: '800' },
  recipientName:   { fontSize: 14, fontWeight: '700', color: Colors.leaf },
  recipientCity:   { fontSize: 11, color: Colors.textMuted },

  // Confirm
  confirmCard: {
    backgroundColor: Colors.surface,
    borderRadius: Radii.xl,
    padding: Spacing.lg,
    marginHorizontal: Spacing.md,
    marginTop: Spacing.sm,
    ...Shadow.card,
  },
  confirmRow:     { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: Spacing.sm },
  confirmLabel:   { fontSize: 13, color: Colors.textMuted },
  confirmRight:   { alignItems: 'flex-end' },
  confirmBusiness:{ fontSize: 15, fontWeight: '700', color: Colors.textPrimary },
  confirmPhone:   { fontSize: 12, color: Colors.textSecondary },
  confirmAmount:  { fontSize: 20, fontWeight: '800', color: Colors.textPrimary, fontVariant: ['tabular-nums'] },
  confirmNote:    { fontSize: 13, color: Colors.textSecondary, maxWidth: '60%', textAlign: 'right' },
  confirmActions: { flexDirection: 'row', gap: Spacing.sm, marginHorizontal: Spacing.md, marginTop: Spacing.md },

  // Empty
  emptyWallet: { alignItems: 'center', paddingTop: 60, gap: 12, paddingHorizontal: Spacing.xl },
  emptyWalletIcon: { fontSize: 48 },
  emptyWalletTitle: { fontSize: 18, fontWeight: '700', color: Colors.textPrimary },
  emptyWalletSub: { fontSize: 13, color: Colors.textMuted, textAlign: 'center', lineHeight: 20 },
  emptyState: { alignItems: 'center', paddingTop: 80, gap: 12 },
  emptyIcon:  { fontSize: 40 },
  emptyText:  { fontSize: 15, color: Colors.textMuted },
});
