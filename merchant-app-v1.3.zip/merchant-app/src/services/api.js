import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { v4 as uuidv4 } from 'uuid';

const BASE_URL = 'http://166.88.117.23:3000/api/v1';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 20000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach JWT to every request
api.interceptors.request.use(async (config) => {
  const token = await SecureStore.getItemAsync('auth_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Handle 401 globally
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    if (error.response?.status === 401) {
      await SecureStore.deleteItemAsync('auth_token');
      await SecureStore.deleteItemAsync('merchant_data');
    }
    return Promise.reject(error);
  }
);

// ── Auth ──────────────────────────────────────────────────────────

export async function login(phone, password) {
  const res = await api.post('/auth/login', { phone, password });
  const { token, merchant } = res.data;
  await SecureStore.setItemAsync('auth_token', token);
  await SecureStore.setItemAsync('merchant_data', JSON.stringify(merchant));
  return merchant;
}

export async function logout() {
  await SecureStore.deleteItemAsync('auth_token');
  await SecureStore.deleteItemAsync('merchant_data');
}

export async function getStoredMerchant() {
  const raw = await SecureStore.getItemAsync('merchant_data');
  return raw ? JSON.parse(raw) : null;
}

// ── Cards ─────────────────────────────────────────────────────────

/**
 * Verify a QR payload — returns card status & balance.
 * Called immediately after scanning, before showing amount confirmation.
 */
export async function verifyCard(qrPayload) {
  const encoded = encodeURIComponent(qrPayload);
  const res = await api.get(`/cards/verify?qrPayload=${encoded}`);
  return res.data.card;
}

/**
 * Get full card details by cardId or serialNumber (admin key required).
 * Used in merchant card management — fetches via token, not admin key.
 * We look up via transactions to find cards the merchant has interacted with.
 */
export async function getCardTransactionHistory(cardId, limit = 10) {
  const res = await api.get(`/cards/${cardId}/transactions?limit=${limit}`);
  return res.data.transactions || [];
}

/**
 * Link a phone number to a card for balance recovery.
 */
export async function linkPhoneToCard(cardId, phone) {
  const res = await api.post(`/cards/${cardId}/link-phone`, { phone });
  return res.data;
}

// ── Payments ──────────────────────────────────────────────────────

export async function processPayment(qrPayload, amountSDG) {
  const idempotencyKey = uuidv4();
  await queueOfflinePayment({ qrPayload, amountSDG, idempotencyKey });

  const res = await api.post('/payments/pay', { qrPayload, amountSDG, idempotencyKey });
  await removeFromOfflineQueue(idempotencyKey);
  return res.data.transaction;
}

export async function processTopUp(cardIdentifier, amountSDG) {
  const idempotencyKey = uuidv4();
  const res = await api.post('/payments/top-up', {
    cardId: cardIdentifier,
    amountSDG,
    idempotencyKey,
  });
  return res.data.transaction;
}

export async function processRefund(originalTransactionRef) {
  const res = await api.post('/payments/refund', { originalTransactionRef });
  return res.data.transaction;
}

export async function getTransactionHistory(page = 1, limit = 25) {
  const res = await api.get(`/payments/history?page=${page}&limit=${limit}`);
  return res.data;
}

// ── Offline Queue ─────────────────────────────────────────────────

const QUEUE_KEY = 'offline_payment_queue';

async function queueOfflinePayment(payment) {
  const raw   = await AsyncStorage.getItem(QUEUE_KEY);
  const queue = raw ? JSON.parse(raw) : [];
  queue.push({ ...payment, queuedAt: new Date().toISOString() });
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
}

async function removeFromOfflineQueue(idempotencyKey) {
  const raw = await AsyncStorage.getItem(QUEUE_KEY);
  if (!raw) return;
  const queue = JSON.parse(raw).filter(p => p.idempotencyKey !== idempotencyKey);
  await AsyncStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
}

export async function getOfflineQueue() {
  const raw = await AsyncStorage.getItem(QUEUE_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function syncOfflineQueue(onProgress) {
  const queue   = await getOfflineQueue();
  const results = [];

  for (const payment of queue) {
    try {
      const res = await api.post('/payments/pay', {
        qrPayload:      payment.qrPayload,
        amountSDG:      payment.amountSDG,
        idempotencyKey: payment.idempotencyKey,
      });
      await removeFromOfflineQueue(payment.idempotencyKey);
      results.push({ success: true, payment, transaction: res.data.transaction });
    } catch (err) {
      results.push({ success: false, payment, error: err.message });
    }
    if (onProgress) onProgress(results.length, queue.length);
  }
  return results;
}

// ── Linked Cards (local storage) ──────────────────────────────────
// The backend doesn't have a "merchant's linked cards" endpoint yet,
// so we maintain the list locally in AsyncStorage on the device.

const LINKED_CARDS_KEY = 'linked_cards';

export async function getLinkedCards() {
  const raw = await AsyncStorage.getItem(LINKED_CARDS_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function addLinkedCard(card) {
  const cards    = await getLinkedCards();
  const existing = cards.find(c => c.cardId === card.cardId);
  if (existing) return cards;
  const updated = [...cards, { ...card, linkedAt: new Date().toISOString() }];
  await AsyncStorage.setItem(LINKED_CARDS_KEY, JSON.stringify(updated));
  return updated;
}

export async function removeLinkedCard(cardId) {
  const cards   = await getLinkedCards();
  const updated = cards.filter(c => c.cardId !== cardId);
  await AsyncStorage.setItem(LINKED_CARDS_KEY, JSON.stringify(updated));
  return updated;
}

export default api;

// ── Wallet ────────────────────────────────────────────────────────

/**
 * Get merchant wallet balance + last 5 transactions.
 * Call on every wallet screen open.
 */
export async function getWalletSummary() {
  const res = await api.get('/wallet/summary');
  return res.data;
}

/**
 * Get full wallet transaction history (paginated).
 */
export async function getWalletHistory(page = 1, limit = 20) {
  const res = await api.get(`/wallet/history?page=${page}&limit=${limit}`);
  return res.data;
}

/**
 * Look up a merchant by phone before initiating transfer.
 * Returns { businessName, phone, city } or throws RECIPIENT_NOT_FOUND.
 */
export async function lookupMerchantByPhone(phone) {
  const encoded = encodeURIComponent(phone);
  const res = await api.get(`/wallet/lookup/${encoded}`);
  return res.data.merchant;
}

/**
 * Transfer funds from this merchant's wallet to another merchant.
 */
export async function transferToMerchant({ recipientPhone, amountSDG, note }) {
  const res = await api.post('/wallet/transfer', { recipientPhone, amountSDG, note });
  return res.data.transfer;
}

// ── Linked Cards (server-side, persists across devices) ───────────

/**
 * Fetch all linked cards with live balances from server.
 * Call on every CardsScreen open — replaces AsyncStorage approach.
 */
export async function fetchLinkedCards() {
  const res = await api.get('/linked-cards');
  return res.data.cards || [];
}

/**
 * Link a card to this merchant account (stored in MongoDB).
 * Accepts cardId (UUID) or serialNumber (printed on card).
 */
export async function linkCardToAccount(cardId, serial, label) {
  const res = await api.post('/linked-cards', { cardId, serial, label });
  return res.data.card;
}

/**
 * Unlink a card from this merchant account.
 */
export async function unlinkCardFromAccount(cardId) {
  await api.delete(`/linked-cards/${cardId}`);
}

/**
 * Update the display label of a linked card.
 */
export async function updateCardLabel(cardId, label) {
  await api.patch(`/linked-cards/${cardId}`, { label });
}
