/**
 * نظام الدفع الرقمي الورقي — السودان
 * Design System v1.1
 *
 * الهوية البصرية: مستوحاة من ألوان الذهب السوداني، الرمل، والليل الصحراوي.
 * ليست نسخة من تطبيقات الدفع الغربية — شخصية مستقلة للسوق السوداني.
 */

export const Brand = {
  name: 'نقطة دفع',
  nameEn: 'NuqtaPay',
  tagline: 'الدفع الذكي للجميع',
  serverUrl: 'http://166.88.117.23:3000/api/v1',
};

export const Colors = {
  // ── الهوية الأساسية ──────────────────────────────────────────
  // أزرق ليلي عميق — يوحي بالموثوقية والرسمية
  ink:      '#1A1F36',
  inkLight: '#252B45',
  inkMid:   '#2E3555',

  // ذهبي دافئ — يُمثّل العملة والثروة والثقة
  gold:      '#C8922A',
  goldLight: '#D9A83C',
  goldPale:  '#F5E6C8',
  goldDark:  '#A87420',

  // ── حالات العمليات ───────────────────────────────────────────
  // نجاح — أخضر طبيعي هادئ (ليس النيون)
  leaf:   '#2E7D5A',
  leafBg: '#E6F4EE',

  // خطأ — طيني دافئ
  clay:   '#C0392B',
  clayBg: '#FDECEA',

  // تحذير — عنبري
  amber:   '#D4890A',
  amberBg: '#FEF3E2',

  // ── الخلفيات والأسطح ─────────────────────────────────────────
  // خلفية رئيسية: بيج رملي دافئ — ليست بيضاء باردة
  canvas:      '#F5F2EC',
  surface:     '#FFFFFF',
  surfaceWarm: '#FDFAF4',
  surfaceCard: '#FAFAF8',

  // ── الحدود ───────────────────────────────────────────────────
  border:      '#E2D9CC',
  borderLight: '#EDE8DF',
  borderFocus: '#C8922A',

  // ── النصوص ───────────────────────────────────────────────────
  textPrimary:   '#1A1F36',
  textSecondary: '#5C5850',
  textMuted:     '#9E968A',
  textInvert:    '#FFFFFF',
  textGold:      '#A87420',
};

export const Spacing = {
  xs:  4,
  sm:  8,
  md:  16,
  lg:  24,
  xl:  32,
  xxl: 48,
};

export const Radii = {
  sm:   6,
  md:   12,
  lg:   18,
  xl:   24,
  xxl:  32,
  full: 999,
};

export const Shadow = {
  xs: {
    shadowColor: '#1A1F36',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 1,
  },
  card: {
    shadowColor: '#1A1F36',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 10,
    elevation: 3,
  },
  elevated: {
    shadowColor: '#1A1F36',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.13,
    shadowRadius: 20,
    elevation: 7,
  },
  gold: {
    shadowColor: '#C8922A',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 5,
  },
};
